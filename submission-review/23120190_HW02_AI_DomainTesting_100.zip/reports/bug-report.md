# Bug report — HW02 EShop

**SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`
**Nguồn expected:** SRS/API specification theo từng feature; không lấy code SUT làm oracle.
**Trạng thái kiểm tra GitHub:** 17/10/2026 UTC+07; Issues #1–#14 đang OPEN.

## Issues đã đăng

| Issue | Finding | TC/requirement | Evidence trên GitHub |
|---:|---|---|---|
| [#1](https://github.com/tzin1401/testing-hw02/issues/1) | Login counter tăng 2 thay vì 1 | A-FR02, A-R04 | Có ảnh UI |
| [#2](https://github.com/tzin1401/testing-hw02/issues/2) | Tài khoản vẫn khóa quá 30 giây | A-FR02, A-R06 | Có ảnh UI; đã bổ sung clock fixture toán tử, không thay phép đo khóa tự nhiên |
| [#3](https://github.com/tzin1401/testing-hw02/issues/3) | Email sai format vẫn được gửi từ form login Web | A-FR02, A-R10 | Có ảnh UI |
| [#4](https://github.com/tzin1401/testing-hw02/issues/4) | Thêm sản phẩm hợp lệ không cập nhật giỏ | B-DT-002 | Có ảnh UI |
| [#5](https://github.com/tzin1401/testing-hw02/issues/5) | Empty cart thiếu hình minh họa | B-DT-001 | Có ảnh UI |
| [#6](https://github.com/tzin1401/testing-hw02/issues/6) | Tạo danh mục với tên rỗng | C-DT-003, C-BV-001 | Có ảnh UI trước/sau |
| [#7](https://github.com/tzin1401/testing-hw02/issues/7) | JWT role user vẫn POST/DELETE categories | C-DT-014, C-DT-018 | Có ảnh trích xuất từ log JSON API; JSON gốc được dẫn trong issue |
| [#8](https://github.com/tzin1401/testing-hw02/issues/8) | API cho tạo account thứ hai cùng email | D-R04 | Có ảnh trích xuất từ log JSON API; JSON gốc được dẫn trong issue |
| [#9](https://github.com/tzin1401/testing-hw02/issues/9) | Thêm lại cùng sản phẩm tạo dòng trùng | B-DT-004-SUP | Có ảnh UI giỏ hàng |
| [#10](https://github.com/tzin1401/testing-hw02/issues/10) | Giỏ hàng thiếu nút tăng/giảm quantity | B-DT-006–010-SUP | Có ảnh UI giỏ hàng |
| [#11](https://github.com/tzin1401/testing-hw02/issues/11) | Xóa hàng không hiện dialog xác nhận | B-DT-011–013-SUP | Có ảnh UI trước/sau |
| [#12](https://github.com/tzin1401/testing-hw02/issues/12) | Nhãn tổng tiền sai (“Tổng tạm tính”) | B-DT-015-SUP | Có ảnh UI giỏ hàng |
| [#13](https://github.com/tzin1401/testing-hw02/issues/13) | Form Mobile thiếu trường xác nhận mật khẩu | D-DT-001, D-R07 | Có ảnh UI form đăng ký |
| [#14](https://github.com/tzin1401/testing-hw02/issues/14) | Mobile chấp nhận họ tên/email rỗng hoặc email sai format | D-DT-003/004/005 variants; D-R01/02/03 | Có ảnh UI before/response cho từng probe |

Tất cả issue mới #9–#14 dùng title `[BUG][Module]`, có môi trường, steps, expected/actual, TC ID, severity/priority có lý do và labels `type: bug`, `status: new`, severity, priority, module. Nội dung và ảnh của #7/#8 đã được cập nhật; bằng chứng API được ghi rõ là trích xuất từ run log JSON, không mô tả thành screenshot UI.

## Giới hạn verdict liên quan

- Issue #4 và các run bổ sung khác nhau về đường setup; không dùng một biến thể để xóa verdict của TC gốc.
- Issue #10 chỉ kết luận thiếu control `+/-`; các thao tác cần control đó vẫn Blocked.
- Issue #11 chỉ kết luận dialog xác nhận vắng mặt; nhánh Hủy không thực hiện được.
- Issue #13/#14: form thiếu confirmation khiến các full TC bốn trường chưa hoàn tất. #14 ghi rõ các probe trên ba trường là biến thể; không đổi partial thành verdict full TC.
- Issue #8 là hai POST tuần tự, không phải kiểm thử race condition. Mobile duplicate là observation trên form thiếu confirmation, tách biệt với bằng chứng API.
- Các oracle chưa rõ như whitespace/trim, max length, persistence, race condition và thời điểm clock server không được báo thành bug.

## AI gaps có bằng chứng

Chi tiết từng lỗi/giới hạn của AI ở [A](../features/A-FR02/07-bugs-and-ai-gaps.md), [B](../features/B-FR07/07-bugs-and-ai-gaps.md), [C](../features/C-FR14/07-bugs-and-ai-gaps.md), [D](../features/D-MREG/07-bugs-and-ai-gaps.md). Chỉ các sai lệch đã đối chiếu với log/evidence được nêu là AI gap; blocker công cụ không tự động được coi là bug AI.


## Findings bổ sung chưa có issue riêng

B-DT-016–019/B-BV-001: quantity 0, âm, thập phân và trường rỗng tạo cart quantity/amount không hợp lệ theo execution. Đã có ảnh/event run 20261016T074533896Z-supp. Bộ 14 issue hiện tại chưa có issue riêng cho nhóm quantity; lần cập nhật hồ sơ này không tự đăng thêm. Khi báo, cần phân biệt input bị ép thành rỗng với literal `abc` và không khẳng định nguyên nhân chung khi chưa xác minh.

## Nội dung issue và ảnh để đọc offline

Snapshot GitHub ngày 2026-10-17T10:44:13+07:00. Đã tải thành công 23/23 ảnh từ body của 14 issue. Trạng thái OPEN phản ánh thời điểm kiểm tra. Nội dung dưới đây là nội dung đã đăng; các giới hạn và run mới ở báo cáo execution được ưu tiên khi đọc kết quả hiện tại.

### Issue #1 — [BUG][Login] Counter increases by 2 after one failed login

URL: https://github.com/tzin1401/testing-hw02/issues/1

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: login, module: api

##### Mô tả lỗi
Sau một lần đăng nhập sai, bộ đếm lỗi tăng 2 thay vì 1. Điều này khiến ngưỡng khóa bị chạm sớm hơn yêu cầu.

##### Môi trường
- Web: http://localhost:5173/login; API: http://localhost:3000/api/login
- Ubuntu 26.04.1; Chrome 154.0.8037.57
- SUT baseline/runtime: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Run: `20261014T183925Z-fa22ee4e`; tài khoản test mới, state đầu counter=0, chưa khóa

##### Steps to reproduce
1. Tạo tài khoản test mới và đảm bảo counter ban đầu bằng 0, chưa khóa.
2. Mở trang đăng nhập, nhập email tài khoản đó và một mật khẩu sai.
3. Bấm **Sign In** một lần.
4. Quan sát response và state counter sau request.

##### Actual result
Web hiển thị từ chối đăng nhập (HTTP 401). State chỉ đọc cho thấy counter `0→2`, `locked_until` vẫn rỗng. Các chuỗi độc lập ghi nhận khóa từ lần sai thứ hai.

##### Expected result
Theo FR-02/A-R04, mỗi lần đăng nhập sai tăng bộ đếm đúng 1: sau lần đầu counter phải là 1. Theo A-R05, tài khoản chưa bị khóa trước lần sai thứ ba.

##### Severity / Priority
- Severity: Major — khóa sớm làm người dùng mất cơ hội thử lại theo số lần được yêu cầu.
- Priority: P1 — cần sửa sớm vì ảnh hưởng trực tiếp luồng đăng nhập và có thể khóa tài khoản sau ít lần sai hơn dự kiến.

##### Phân loại
A-DT-002, A-DT-011, A-DT-014, A-DT-020; A-BV-002–005. Một nguyên nhân được gộp trong một issue.

##### Evidence
Ảnh giao diện sau lần nhập sai; log của Run ID trên lưu HTTP 401 và counter=2 sau đúng một request sai.

![UI từ chối đăng nhập sau một lần sai](github-evidence/issue-01-01.png)


### Issue #2 — [BUG][Login] Account remains locked more than 30 seconds

URL: https://github.com/tzin1401/testing-hw02/issues/2

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: login, module: api

##### Mô tả lỗi
Tài khoản vẫn bị khóa sau thời gian khóa 30 giây; đăng nhập bằng mật khẩu đúng sau hơn 30 giây vẫn bị từ chối.

##### Môi trường
- Web: http://localhost:5173/login; API: http://localhost:3000/api/login
- Ubuntu 26.04.1; Chrome 154.0.8037.57
- SUT baseline/runtime: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Run chụp UI: `20261014T183925Z-fa22ee4e`; tài khoản test riêng

##### Steps to reproduce
1. Tạo tài khoản test mới chưa khóa.
2. Gửi hai lần đăng nhập với mật khẩu sai để tạo trạng thái khóa theo hành vi hiện tại.
3. Chờ hơn 40 giây, không gửi request login khác trong lúc chờ.
4. Trên Web nhập đúng email và mật khẩu của tài khoản rồi bấm **Sign In**.

##### Actual result
Đăng nhập đúng vẫn bị từ chối; request UI trả HTTP 403. Các phép đo API độc lập ở Run `20261014T180523Z-fa50f52b` trả 403 ở khoảng 31.0707–31.0814 giây và 40.0726–40.0822 giây sau response kích hoạt khóa. `locked_until` runtime xấp xỉ 180 giây sau khi khóa được đặt.

**Lưu ý setup:** baseline còn có lỗi riêng về bộ đếm/ngưỡng, nên khóa được kích hoạt sau hai lần sai thay vì ba. Issue này ghi nhận thời lượng khóa quan sát được sau khi khóa đã phát sinh; không dùng nó để thay thế lỗi ngưỡng.

##### Expected result
Theo FR-02/A-R06, khóa tạm thời kéo dài 30 giây. Sau khi hết thời gian, hệ thống phải xét credentials; với mật khẩu đúng, đăng nhập được chấp nhận.

##### Severity / Priority
- Severity: Major — người có credentials đúng bị từ chối lâu hơn thời gian khóa yêu cầu.
- Priority: P1 — kéo dài trực tiếp việc không thể đăng nhập.

##### Phân loại
A-DT-013, A-DT-021, A-DT-022; A-BV-008, A-BV-010. A-BV-006/009 là quan sát trước 30 giây.

##### Evidence
Ảnh giao diện cho thấy lần thử mật khẩu đúng sau thời gian chờ vẫn bị từ chối. Timing bounds và response của từng request được ghi trong Run API nêu trên và báo cáo `features/A-FR02/timing-analysis.md`.

![UI từ chối đăng nhập đúng sau khi chờ hơn 40 giây](github-evidence/issue-02-01.png)


### Issue #3 — [BUG][Login] Malformed email is submitted from Web login form

URL: https://github.com/tzin1401/testing-hw02/issues/3

Trạng thái: OPEN. Labels: type: bug, status: new, severity: minor, priority: P2, module: login, module: ui

##### Mô tả lỗi
Form đăng nhập Web không bật HTML5 email validation: chuỗi sai định dạng vẫn được gửi tới API.

##### Môi trường
- Web: http://localhost:5173/login; API: http://localhost:3000/api/login
- Ubuntu 26.04.1; Chrome 154.0.8037.57
- SUT baseline/runtime: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Run: `20261014T183925Z-fa22ee4e`

##### Steps to reproduce
1. Mở trang `/login`.
2. Nhập `not-an-email` vào trường email và một mật khẩu bất kỳ.
3. Bấm **Sign In**.
4. Quan sát form và request mạng.

##### Actual result
Input email có `type=text`; trình duyệt báo `checkValidity() = true` cho `not-an-email` và gửi POST `/api/login`, nhận HTTP 401.

##### Expected result
Theo FR-02/A-R10, trường email dùng HTML5 validation. Giá trị sai định dạng bị trình duyệt chặn khi submit và không phát sinh request login.

##### Severity / Priority
- Severity: Minor — API vẫn từ chối đăng nhập, nhưng validation phía Web được yêu cầu không hoạt động.
- Priority: P2 — lỗi validation UX cần sửa, mức khẩn cấp thấp hơn việc khóa tài khoản sai.

##### Phân loại
A-DT-004, A-DT-020; module Login/UI.

##### Evidence
Ảnh giữ lại giá trị sai định dạng và thông báo từ chối; log Run ID xác nhận `type=text`, validity=true và POST 401.

![Email sai định dạng vẫn được gửi từ form](github-evidence/issue-03-01.png)


### Issue #4 — [BUG][Cart] Valid product addition does not update the Web cart

URL: https://github.com/tzin1401/testing-hw02/issues/4

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: cart

##### Mô tả lỗi
Thêm sản phẩm hợp lệ từ trang chi tiết không tạo sản phẩm trong giỏ Web và không hiển thị phản hồi trực quan.

##### Môi trường
- Browser: Chrome 154.0.8037.57, Linux
- URL: `http://127.0.0.1:5173`
- SUT commit: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Account: tài khoản test đã đăng nhập (không ghi thông tin xác thực)
- Run: `20261014T191645Z-BFR07-UI`
- Test case: `B-DT-002` (B-R03, B-R13)

##### Steps to reproduce
1. Đảm bảo giỏ hàng đang rỗng.
2. Mở chi tiết P1: iPhone 15 Pro Max (ID 1, giá 30.000.000 VND).
3. Để số lượng là `1` — giá trị hợp lệ theo FR-06.
4. Bấm **Thêm vào giỏ hàng** một lần.
5. Mở **Giỏ hàng**.

##### Actual result
- Click được thực hiện; trang vẫn ở chi tiết sản phẩm.
- Giỏ hàng báo rỗng, không có dòng sản phẩm.
- Run này không quan sát thấy request `POST /api/cart` từ thao tác Web.

##### Expected result
- SRS FR-06 yêu cầu phản hồi trực quan sau khi bấm Thêm (toast hoặc badge cập nhật).
- SRS FR-07 mô tả danh sách sản phẩm trong giỏ và hành vi thêm sản phẩm; với ca này P1 phải xuất hiện trong giỏ với quantity `1`.

##### Severity
**Major** — thao tác thêm hàng là luồng cốt lõi; với sản phẩm/giá trị hợp lệ đã thử, người dùng không thể thấy sản phẩm trong giỏ để tiếp tục thao tác. Đã tái hiện trong run ghi bên trên; phạm vi trên browser khác chưa kiểm tra.

##### Evidence
Ảnh input, trạng thái ngay sau click và giỏ sau click được đính kèm bên dưới.

![Valid quantity input for P1](github-evidence/issue-04-01.png)

![Web after clicking Add to cart](github-evidence/issue-04-02.png)

![Cart remains empty](github-evidence/issue-04-03.png)

### Issue #5 — [BUG][Cart] Empty cart state is missing its illustration

URL: https://github.com/tzin1401/testing-hw02/issues/5

Trạng thái: OPEN. Labels: type: bug, status: new, severity: minor, priority: P2, module: cart

##### Mô tả lỗi
Empty state của giỏ hàng không hiển thị hình minh họa.

##### Môi trường
- Browser: Chrome 154.0.8037.57, Linux
- URL: `http://127.0.0.1:5173/cart`
- SUT commit: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Account: tài khoản test đã đăng nhập (không ghi thông tin xác thực)
- Run: `20261014T191645Z-BFR07-UI`
- Test case: `B-DT-001` (B-R01)

##### Steps to reproduce
1. Đảm bảo giỏ hàng đang rỗng.
2. Mở trang **Giỏ hàng**.

##### Actual result
- Thông báo “Giỏ hàng của bạn đang trống” hiển thị.
- Không thấy hình minh họa trong vùng empty state.

##### Expected result
SRS FR-07 yêu cầu giỏ hàng trống có cả hình minh họa và thông báo rõ ràng.

##### Severity
**Minor** — thiếu phần minh họa của empty state, trong khi thông báo vẫn hiện và bằng chứng không cho thấy luồng chính bị chặn.

##### Evidence
Ảnh trạng thái giỏ rỗng được đính kèm bên dưới.

![Empty cart state without illustration](github-evidence/issue-05-01.png)

### Issue #6 — [BUG][Admin] Hệ thống cho phép tạo danh mục khi tên để trống

URL: https://github.com/tzin1401/testing-hw02/issues/6

Trạng thái: OPEN. Labels: type: bug, status: new, severity: minor, priority: P2, module: admin

##### Mô tả lỗi
Admin UI tạo được danh mục dù tên để trống. Điều này trái với SRS FR-14: tên danh mục bắt buộc và không được để trống.

##### Môi trường
- Linux x86_64
- Chrome Headless 154.0.8037.57
- Admin: `http://127.0.0.1:5174`
- Backend: `http://127.0.0.1:3000`
- SUT commit: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Tài khoản có role `admin`

##### Steps to reproduce
1. Đăng nhập Admin và mở **Danh mục**.
2. Để trống trường tên danh mục.
3. Bấm **Thêm mới** một lần.
4. Quan sát dòng mới trong danh sách.

##### Expected result
Danh mục không được tạo nếu tên để trống (SRS FR-14). SRS không quy định wording hoặc HTTP status cụ thể.

##### Actual result
Danh mục rỗng được tạo. Lần tái hiện bổ sung ghi nhận ID `26`; chỉ category test này được dọn sau khi lưu bằng chứng.

##### Test cases
- `C-DT-003`
- `C-BV-001`

##### Severity / Priority
- **Severity:** Minor
- **Priority:** P2
- Lý do: cần phiên Admin và gây dữ liệu quản trị không hợp lệ; lần chạy không ảnh hưởng category mẫu hay gây mất dữ liệu khác.

##### Evidence
![Form tên rỗng trước khi thêm](github-evidence/issue-06-01.png)
![Category tên rỗng đã được tạo](github-evidence/issue-06-02.png)


### Issue #7 — [BUG][API] API categories cho phép user thường POST và DELETE

URL: https://github.com/tzin1401/testing-hw02/issues/7

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: api

##### Mô tả lỗi
API cho phép tài khoản `role=user` tạo và xóa danh mục. FR-12 yêu cầu thao tác ghi phải dùng JWT hợp lệ của Admin.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Backend Linux, Run `20261015T055119Z-CFR14`
- Fixture roles trong run: `admin` và `user`; Authorization token đã được che.

##### Steps to reproduce
1. Dùng fixture role `user` và JWT của fixture.
2. Gửi `POST /api/categories` với tên test `C14-C-DT-014-T055119-denied`.
3. Đọc snapshot danh mục sau request.
4. Dùng fixture role `user` gửi `DELETE /api/categories/10` cho target test `C14-C-DT-018-T055119-target`.
5. Đọc snapshot danh mục sau request.

##### Expected result
Theo FR-12, chỉ Admin được ghi dữ liệu quản trị; user thường không tạo được danh mục và không xóa được target. SRS không quy định status/body cụ thể cho phản hồi từ chối.

##### Actual result
`C-DT-014`: POST trả HTTP 200, `Category created`, ID 6; snapshot sau request có danh mục test. `C-DT-018`: DELETE ID 10 trả HTTP 200, `Category deleted`; snapshot sau request không còn target. Cả hai request dùng fixture role user.

##### Evidence
Ảnh đính kèm là bản trình bày trực quan trích từ JSON run log đã lưu, không phải screenshot UI hay một lần chạy mới. JSON gốc: `evidence/C-FR14/full-runs/20261015T055119Z-CFR14/api-evidence.json`, cases `C-DT-014` và `C-DT-018`. TC: `C-DT-014`, `C-DT-018`.

##### Severity / Priority
Major / P1: user thường có thể sửa hoặc xóa dữ liệu quản trị, vi phạm FR-12. Test chỉ dùng category riêng.

![Redacted API run-log evidence for user-role POST and DELETE](github-evidence/issue-07-01.png)

### Issue #8 — [BUG][API] Đăng ký tạo tài khoản mới dù email đã tồn tại

URL: https://github.com/tzin1401/testing-hw02/issues/8

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: api

##### Mô tả lỗi
`POST /api/register` tạo tài khoản thứ hai khi email đã có trong hệ thống, trái với FR-01 yêu cầu email duy nhất.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Run `20261015T1303Z-DMREG`, Linux, backend và database clone cô lập
- Endpoint: `POST /api/register`

##### Steps to reproduce
1. Trên DB clone, xác nhận email test `vinh.dmreg.api-fixture01@example.com` có count 0.
2. Gửi POST đăng ký hợp lệ với email đó; xác nhận response ID 3 và count 1.
3. Gửi lại POST tuần tự với cùng email; mật khẩu đã được che trong log.
4. Đọc count bằng truy vấn chỉ đọc.

##### Expected result
FR-01 yêu cầu email duy nhất, nên request thứ hai không được tạo thêm tài khoản cho email đã tồn tại. SRS không định nghĩa status/body lỗi cụ thể.

##### Actual result
Hai POST tuần tự đều trả HTTP 200; lần đầu tạo ID 3, lần sau tạo ID 4. DB count tăng 0 → 1 → 2. Chỉ tái hiện trên DB clone; chưa kiểm tra race condition.

##### Mobile UI observation — phạm vi giới hạn
Run `20261015T153620Z-57c022` còn có một probe Mobile dùng lại email vừa tạo, app báo thành công và count tăng 1 → 2. Đây là biến thể trên form chỉ có ba trường; trường confirmation bắt buộc theo FR-01 không tồn tại. Vì vậy đây là observation bổ sung, không phải Pass/Fail cho full TC `D-DT-006`.

##### Evidence
Ảnh đính kèm là bản trình bày trích từ API JSON log, không phải screenshot UI hay request mới. JSON gốc: `evidence/D-MREG/full-runs/20261015T1303Z-DMREG/api-registration-duplicate-isolated.json`; Mobile variant: `evidence/D-MREG/supplement-runs/20261015T153620Z-57c022/`.

##### Requirement / severity
FR-01, D-R04. Major / P1 vì email trùng tạo hai định danh tài khoản; chỉ dùng dữ liệu clone test.

![Redacted API run-log evidence for repeated email registration](github-evidence/issue-08-01.png)

### Issue #9 — [BUG][Cart] Thêm lại sản phẩm tạo dòng trùng thay vì tăng số lượng

URL: https://github.com/tzin1401/testing-hw02/issues/9

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: cart

##### Mô tả lỗi
Thêm lại sản phẩm đã có trong giỏ tạo dòng thứ hai, thay vì tăng số lượng trên dòng hiện có.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Chrome / Linux; run bổ sung `20261015T154202360Z-supp`
- Người dùng và sản phẩm đều là fixture test; không thay đổi catalog.

##### Tiền điều kiện
Giỏ có thể thao tác trên Web; P1 là iPhone 15 Pro Max, product ID 1.

##### Steps to reproduce
1. Thêm P1 vào giỏ.
2. Quay lại trang sản phẩm và thêm lại chính P1.
3. Mở giỏ hàng.

##### Expected result
FR-07: thêm cùng một sản phẩm làm tăng quantity, không tạo dòng mới.

##### Actual result
Giỏ hiển thị hai dòng iPhone 15 Pro Max riêng biệt, mỗi dòng quantity 1.

##### Evidence
Ảnh đính kèm `B-DT-004-SUP-duplicate-product.png`; TC variant `B-DT-004-SUP`, Run `20261015T154202360Z-supp`. Đây là run supplement, không đổi verdict của TC gốc bị setup block.

##### Severity / Priority
Major / P1: cùng sản phẩm được biểu diễn thành nhiều dòng thay vì quantity hợp nhất, làm sai hành vi giỏ cốt lõi.

![Same product shown as two cart rows after adding it twice](github-evidence/issue-09-01.png)

### Issue #10 — [BUG][Cart] Giỏ hàng thiếu nút tăng giảm số lượng

URL: https://github.com/tzin1401/testing-hw02/issues/10

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: cart

##### Mô tả lỗi
Dòng sản phẩm trong giỏ không có nút `+` và `−` để chỉnh quantity như FR-07 yêu cầu.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Chrome / Linux; run bổ sung `20261015T154202360Z-supp`

##### Steps to reproduce
1. Thêm P1 (iPhone 15 Pro Max) vào giỏ bằng Web.
2. Mở giỏ và quan sát cột Số lượng/Thao tác của dòng sản phẩm.

##### Expected result
FR-07 yêu cầu số lượng có nút `+/-` để điều chỉnh.

##### Actual result
Dòng chỉ hiển thị quantity và nút “Xóa”; không có `+` hoặc `−`. Vì control không tồn tại, các thao tác tương tác tăng/giảm bị blocked; issue chỉ báo lỗi hiện diện control.

##### Evidence
Ảnh đính kèm `B-DT-006-SUP-controls.png`, Run `20261015T154202360Z-supp`. TC variants `B-DT-006–010-SUP` và `B-BV-004–006-SUP`.

##### Severity / Priority
Major / P1: người dùng không thể điều chỉnh quantity trong giỏ bằng các control được yêu cầu.

![Cart item row has no plus or minus quantity controls](github-evidence/issue-10-01.png)

### Issue #11 — [BUG][Cart] Xóa sản phẩm không hiện dialog xác nhận

URL: https://github.com/tzin1401/testing-hw02/issues/11

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: cart

##### Mô tả lỗi
Bấm “Xóa” xóa dòng hàng ngay mà không hỏi xác nhận.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Chrome / Linux; run bổ sung `20261015T154202360Z-supp`
- Dòng sản phẩm là dữ liệu giỏ test do run tạo.

##### Steps to reproduce
1. Đưa một sản phẩm test vào giỏ.
2. Mở giỏ hàng.
3. Bấm “Xóa” trên dòng sản phẩm.

##### Expected result
FR-07 yêu cầu có dialog xác nhận trước khi xóa sản phẩm.

##### Actual result
Dòng biến mất ngay sau thao tác; run không ghi nhận dialog (`dialogs: []`). Không có nhánh hủy để thực hiện do dialog không xuất hiện.

##### Evidence
Ảnh before/after đính kèm: `B-DT-011-SUP-before-delete.png` và `B-DT-011-SUP-after-delete.png`; event log trong Run `20261015T154202360Z-supp`. Variants `B-DT-011–013-SUP`.

##### Severity / Priority
Major / P1: xóa nhầm có thể làm mất dòng sản phẩm mà không có bước xác nhận.

![Cart row immediately before pressing delete](github-evidence/issue-11-01.png)

![Cart row is removed without a confirmation dialog](github-evidence/issue-11-02.png)

### Issue #12 — [BUG][Cart] Nhãn tổng tiền không đúng yêu cầu FR-07

URL: https://github.com/tzin1401/testing-hw02/issues/12

Trạng thái: OPEN. Labels: type: bug, status: new, severity: minor, priority: P2, module: cart

##### Mô tả lỗi
Nhãn tổng tiền ở giỏ hàng hiển thị “Tổng tạm tính” thay vì đúng nhãn “Tổng cộng”.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Chrome / Linux; run bổ sung `20261015T154202360Z-supp`

##### Steps to reproduce
1. Thêm một sản phẩm test vào giỏ hàng Web.
2. Mở giỏ và đọc nhãn cạnh tổng tiền.

##### Expected result
FR-07 chỉ định nhãn chính xác “Tổng cộng”.

##### Actual result
Giao diện hiển thị “Tổng tạm tính”.

##### Evidence
Ảnh đính kèm `B-DT-015-SUP-total-label.png`; TC variant `B-DT-015-SUP`, Run `20261015T154202360Z-supp`.

##### Severity / Priority
Minor / P2: nhãn sai nhưng giá trị tổng vẫn hiển thị; bằng chứng không cho thấy chặn thao tác chính.

![Cart displays Tổng tạm tính where FR-07 specifies Tổng cộng](github-evidence/issue-12-01.png)

### Issue #13 — [BUG][Mobile] Form đăng ký thiếu trường xác nhận mật khẩu

URL: https://github.com/tzin1401/testing-hw02/issues/13

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: ui

##### Mô tả lỗi
Form đăng ký trên Mobile không có trường “Xác nhận mật khẩu”.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Pixel 9 Emulator, Android 15 / API 35, Expo Go SDK 54
- Run `20261015T153620Z-57c022`

##### Steps to reproduce
1. Mở ứng dụng EShop Mobile.
2. Vào màn hình Đăng ký.
3. Quan sát các trường nhập trước nút Đăng ký.

##### Expected result
FR-01 yêu cầu trường Xác nhận mật khẩu và từ chối nếu mật khẩu với xác nhận không khớp.

##### Actual result
Form chỉ có Họ tên, Email và Mật khẩu; không có trường xác nhận nên không thể nhập/xác minh giá trị khớp.

##### Evidence
Ảnh đính kèm `D-DT-001-register-form.png`; TC `D-DT-001`, Run `20261015T153620Z-57c022`.

##### Severity / Priority
Major / P1: một trường bắt buộc của luồng đăng ký không tồn tại, nên người dùng không thể thực hiện yêu cầu xác nhận.

![Mobile register form exposes name, email, and password but no confirmation field](github-evidence/issue-13-01.png)

### Issue #14 — [BUG][Mobile] Đăng ký chấp nhận họ tên hoặc email rỗng/sai định dạng

URL: https://github.com/tzin1401/testing-hw02/issues/14

Trạng thái: OPEN. Labels: type: bug, status: new, severity: major, priority: P1, module: ui

##### Mô tả lỗi
Form đăng ký Mobile chấp nhận các probe có họ tên rỗng, email rỗng hoặc email sai định dạng và vẫn báo đăng ký thành công.

##### Môi trường
- SUT baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`
- Pixel 9 Emulator, Android 15 / API 35, Expo Go SDK 54
- Run `20261015T153620Z-57c022`; dùng email fixture riêng và mật khẩu không được ghi vào issue.

##### Tiền điều kiện và giới hạn
Form thực tế chỉ có ba trường Họ tên, Email, Mật khẩu; thiếu trường xác nhận mật khẩu bắt buộc. Các trường hợp dưới đây là probe riêng trên form hiện có, không phải full TC bốn trường đã hoàn thành.

##### Steps to reproduce
Thực hiện từng probe độc lập, mỗi probe dùng dữ liệu mới và các trường khác hợp lệ:
1. Để Họ tên rỗng, nhập email test mới và mật khẩu hợp lệ, bấm Đăng ký.
2. Để Email rỗng, nhập họ tên và mật khẩu hợp lệ, bấm Đăng ký.
3. Nhập email `bad-20261015t153620z-57c022` (không có `@`) cùng họ tên và mật khẩu hợp lệ, bấm Đăng ký.

##### Expected result
FR-01 yêu cầu họ tên và email; email phải có định dạng hợp lệ. Những input này không được tạo tài khoản thành công. SRS không quy định câu chữ thông báo.

##### Actual result
Cả ba probe đều hiện alert đăng ký thành công, chuyển về Login và DB test count tăng 0 → 1 cho email tương ứng.

##### Evidence
Ảnh đính kèm before/response cho `D-DT-003`, `D-DT-004`, `D-DT-005` trong `evidence/D-MREG/supplement-runs/20261015T153620Z-57c022/`; event log ghi state count. TC variants `D-DT-003/004/005`. Không kết luận ca full flow thành công vì confirmation field thiếu.

##### Severity / Priority
Major / P1: tài khoản được tạo dù dữ liệu bắt buộc thiếu hoặc email sai format. Severity áp dụng cho các probe đã quan sát; root cause chưa xác định.

![Registration probe with required name left blank](github-evidence/issue-14-01.png)

![App reports registration success after blank-name probe](github-evidence/issue-14-02.png)

![Registration probe with required email left blank](github-evidence/issue-14-03.png)

![App reports registration success after blank-email probe](github-evidence/issue-14-04.png)

![Registration probe with malformed email format](github-evidence/issue-14-05.png)

![App reports registration success after malformed-email probe](github-evidence/issue-14-06.png)
