# Báo cáo chính HW02 — Domain Testing và Boundary Value Analysis

**Sinh viên:** Nguyễn Lê Thế Vinh  
**MSSV:** 23120190  
**Vai trò:** Thành viên 2  
**SUT:** EShop, baseline `85af3ba875c88283615e22cb108f13e2fccaf0e9`  
**Ngày cập nhật hồ sơ:** 17/10/2026 (UTC+07:00). Bộ chính 105 TC giữ trạng thái theo các run trước; lượt skill-demo A-FR02 mới được báo cáo riêng ở cuối tài liệu.

## Tóm tắt

Báo cáo này trình bày trực tiếp phạm vi yêu cầu, đầu vào/trạng thái/đầu ra, phân lớp tương đương, ca Domain, ca BVA, kết quả thực thi và giới hạn của bốn chức năng được giao: đăng nhập Web A-FR02, giỏ hàng Web B-FR07, quản lý danh mục Admin C-FR14 và đăng ký Mobile D-MREG. Các kết luận expected dựa trên SRS, API specification và phân công được ghi rõ; slide cung cấp phương pháp Domain Testing/BVA, không tự bổ sung quy tắc nghiệp vụ. Báo cáo không dùng mã nguồn có lỗi của SUT làm oracle.

**Bộ chính 105 ca thiết kế:** 36 Pass, 32 Fail, 24 Partial/Observation và 13 Blocked/Not run. Các trạng thái ở bộ chính không bị thay bởi lượt skill-demo chạy riêng. Partial/Observation và Blocked/Not run không được tính là verdict hoàn tất. Bảng dưới tóm tắt bộ chính:

| Chức năng | Kênh | Ca thiết kế | Pass | Fail | Partial/Observation | Blocked/Not run |
|---|---|---:|---:|---:|---:|---:|
| A-FR02 — Đăng nhập/khóa tài khoản | Web/API | 36 | 17 | 15 | 4 | 0 |
| B-FR07 — Giỏ hàng | Web | 26 | 4 | 12 | 2 | 8 |
| C-FR14 — Danh mục | Admin/API | 23 | 15 | 4 | 3 | 1 |
| D-MREG — Đăng ký | Mobile/API phụ trợ | 20 | 0 | 1 | 15 | 4 |
| **Tổng** |  | **105** | **36** | **32** | **24** | **13** |

Cách phân nhóm: mỗi TC thiết kế được đếm đúng một lần theo trạng thái mới nhất. Các probe/biến thể bổ sung không thay verdict TC thiết kế nếu setup hoặc kênh khác; chúng chỉ được dùng làm bằng chứng bổ trợ và được ghi rõ. Bằng chứng gồm ảnh giao diện, request/response đã che bí mật, event log có timestamp và trạng thái DB chỉ đọc khi có ích. Một số ca UI chưa hoàn tất; API không được dùng thay cho bằng chứng UI.

## Nguồn yêu cầu và phương pháp

- **SRS EShop tại baseline:** FR-02 cho A-FR02; FR-07 và phần quantity liên quan của FR-06 cho B-FR07; FR-14 và quyền Admin ở FR-12 cho C-FR14; FR-20 cùng quy tắc đăng ký FR-01 cho D-MREG.
- **API specification tại baseline:** login, cart, categories và register; chỉ dùng các response được contract nêu làm expected API.
- **Phân công nhóm Thành viên 2:** xác định phạm vi bốn chức năng và các nhấn mạnh kiểm thử (counter/thời gian khóa; quantity và tiền; tên danh mục/quyền; đăng ký Mobile).
- **Slide Domain Testing/BVA:** bắt đầu từ input/output, chia lớp tương đương có expected nhất quán, chọn điểm biên quanh giới hạn có căn cứ, theo dõi state và ghi bằng chứng có thể tái hiện.

Quy trình áp dụng: (1) trích yêu cầu và oracle; (2) xác định input, state và output; (3) phân lớp hợp lệ/không hợp lệ hoặc lớp cần hỏi thêm; (4) chọn đại diện và ca Domain; (5) chọn biên dưới/trên có nguồn; (6) review coverage; (7) chạy trên kênh phù hợp; (8) đối chiếu actual với expected. Với ca âm cơ bản, chỉ thay đổi một điều kiện. Khi SRS không nêu giới hạn hoặc chính sách, ghi câu hỏi/probe, không tự tạo expected.

## A-FR02 — Đăng nhập và khóa tài khoản Web

### Yêu cầu, input, state và output

Input chính là email, mật khẩu, submit Web/API, chuỗi đúng/sai và thời điểm gửi. State cần theo dõi gồm tài khoản có tồn tại không, số lần sai liên tiếp `n`, đang khóa hay không, mốc bắt đầu khóa `t0`, elapsed, kết quả trước và token phía client. Output gồm trạng thái đăng nhập, HTTP/token/user, thông báo lỗi, counter/lock, việc lưu/gửi Bearer token và validation email HTML5.

| ID | Yêu cầu và expected có căn cứ |
|---|---|
| A-R01 | Đăng nhập nhận email và mật khẩu; API là `POST /api/login` với hai trường. |
| A-R02 | Thông tin đúng khi không khóa cho đăng nhập thành công; API contract nêu HTTP 200, token và user. |
| A-R03 | Thông tin sai không đăng nhập thành công; không có token thành công mới. Mã lỗi cụ thể chưa được SRS/API chốt. |
| A-R04 | Mỗi lần sai được tính phải tăng bộ đếm đúng 1. |
| A-R05 | Ngưỡng khóa là lần sai liên tiếp thứ 3; hai lần đầu chưa đạt ngưỡng. |
| A-R06 | Khóa tạm thời 30 giây tính từ lúc kích hoạt; trong thời gian khóa thông tin đúng vẫn bị chặn. Thời điểm so sánh phải được đo phù hợp. |
| A-R07 | Sai/đang khóa phải có phản hồi lỗi phù hợp và không lộ chi tiết nhạy cảm; câu chữ cụ thể chưa bắt buộc. |
| A-R08 | Client lưu token sau đăng nhập đúng; vị trí lưu cụ thể không quy định. |
| A-R09 | Request cần xác thực gửi `Authorization: Bearer <token>`. |
| A-R10 | Ô email Web phải dùng validation HTML5; sai format bị chặn trước khi gửi login request. |
| A-R11 | Diễn giải “liên tiếp”: đăng nhập thành công ngắt chuỗi sai; sai tiếp theo bắt đầu chuỗi mới. |

Các oracle chưa chốt: tài khoản/email không tồn tại có được tính counter không; rỗng/sai format/request đang khóa có được tính; sau khi hết khóa counter reset hay giữ; request đang khóa có gia hạn thời gian không; cách chuẩn hóa email; status HTTP khi sai; thời hạn/vị trí lưu token.

### Phân lớp tương đương

| Nhóm EC | Đại diện/lớp | Expected hoặc giới hạn |
|---|---|---|
| A-EC-E01–E07 | Email đúng gắn tài khoản; đúng nhưng không tồn tại; sai format; rỗng; có whitespace/khác hoa thường; thiếu key; sai kiểu số | E01 + mật khẩu đúng + không khóa thành công. E02/E03 và payload cấu trúc sai không được đăng nhập. E04–E07 có chi tiết validation/counter/status chưa chốt. |
| A-EC-P01–P06 | Mật khẩu đúng; sai; rỗng; whitespace-only; thiếu key; null | P01 thành công chỉ khi state cho phép; P02 bị từ chối và nếu được tính thì counter +1. Các dạng rỗng/cấu trúc bị từ chối, cách tính counter cần làm rõ. |
| A-EC-G01–G03 | Submit Web hợp lệ; Web bị browser chặn; API trực tiếp | Tách browser validation khỏi xác thực server; UI và API là kênh khác nhau. |
| A-EC-N01–N05 | `n=0`, `n=1`, `n=2`, đang khóa, đã hết thời gian khóa | Expected theo ngưỡng lần 3; tác động counter sau hết khóa/request đang khóa là câu hỏi. |
| A-EC-L01–L04 | Không khóa; elapsed 10s; đúng 30s; 40s | Trong 30 giây chặn; sau 30s khóa cũ hết. Đúng mốc phải điều khiển/quan sát clock tại điểm server so sánh. |
| A-EC-H01–H05 | Sai liên tiếp; sai→đúng→sai; validation xen giữa; request khi khóa; sai sau khi hết khóa | Thành công ngắt chuỗi là diễn giải từ “liên tiếp”; counter/gia hạn cho các trường hợp còn lại chưa chốt. |
| A-EC-T01–T03 | Client chưa token; token hợp lệ cũ; token sai dạng | Login đúng cấp/lưu token và protected request gửi Bearer; token cũ không được nhầm là token mới. TTL/giữ token cũ sau fail chưa nêu. |
| A-EC-O01–O06 | Thành công; fail thường; kích hoạt khóa; đang khóa; browser validation; email không tồn tại | Phân lớp theo kết quả cần thấy; HTTP lỗi/câu chữ/counter chỉ chấm nếu có oracle. |

### Ca Domain được thiết kế

Có 24 ca A-DT. A-DT-001 login Web đúng, lưu token và gửi Bearer; 002 sai mật khẩu; 003 email chưa đăng ký; 004 format sai trên Web; 005 đúng qua API; 006 email không tồn tại qua API; 007 thiếu email; 008 email sai kiểu; 009 thiếu password; 010 password null; 011 chuỗi ba lần sai; 012 đúng trong lúc khóa; 013 đúng sau thời gian khóa; 014 sai→đúng→sai; 015 email rỗng; 016 password rỗng; 017 password whitespace-only; 018 email khác hoa/thường; 019 email có khoảng trắng; 020 email format sai xen giữa hai lần sai; 021 thử lại sau request trong lúc khóa; 022 password sai sau khi khóa cũ hết; 023 phân biệt token cũ với kết quả login sai; 024 login đúng khi client có token sai dạng.

Ca stateful dùng tài khoản riêng, chuỗi tuần tự và quan sát counter/lock. Với thời gian, không tái sử dụng một chuỗi khóa cho nhiều mốc; không dùng sleep hoặc đồng hồ desktop làm bằng chứng thời điểm server xử lý.

### BVA: biến đếm và thời gian khóa

Ngưỡng số lần sai `k=3`: kiểm tra các điểm 0, 1, 2, 3 và request thứ 4 trong trạng thái khóa. Ngưỡng thời gian `30s`: kiểm tra trong miền (10s/29s), sát mốc 29.999s, đúng 30.000s, sau mốc 30.001s/31s và 40s. `δ` gần mốc chỉ được tuyên bố nếu clock tại điểm server so sánh được kiểm soát; đo client chỉ cho khoảng thời gian.

| TC | Điểm | Expected | Kết quả mới nhất |
|---|---|---|---|
| A-BV-001 | `k=0`, login đúng | Thành công, không khóa | Pass |
| A-BV-002 | Lần sai thứ 1 | Counter 0→1, chưa khóa | Fail: 0→2 |
| A-BV-003 | Lần sai thứ 2, ngay dưới ngưỡng | Counter 2, chưa khóa; ca còn bước login đúng | Fail checkpoint state: counter 0→2→4 và bị khóa; full ca thiếu setup expected |
| A-BV-004 | Lần sai thứ 3, đúng ngưỡng | Khóa ở lần 3 | Fail: đã khóa từ lần 2 |
| A-BV-005 | Request sai thứ 4 khi đang khóa | Bị từ chối; không áp đặt counter sau request | Fail do setup khóa sớm; request bị từ chối |
| A-BV-006 | Mục tiêu 29s | Trong khóa thì chặn | Partial: clock fixture chặn đúng; chuỗi tự nhiên khóa ở sai lần 2 |
| A-BV-007 | Đúng 30.000s tại clock fixture | Hết khóa theo toán tử được kiểm tra | Pass checkpoint fixture; không chứng minh thời lượng khóa tự nhiên |
| A-BV-008 | Mục tiêu 31s | Sau 30s login đúng được xét | Fail: còn bị chặn; observed lock 180s |
| A-BV-009 | Mục tiêu 10s | Trong khóa thì chặn | Partial: checkpoint fixture đúng; setup tự nhiên sai ngưỡng |
| A-BV-010 | Mục tiêu 40s | Sau 30s khóa cũ hết | Fail: vẫn bị chặn, observed lock 180s |
| A-BV-011 | 29.999s, trước mốc | Bị chặn | Pass với clock fixture tại điểm so sánh |
| A-BV-012 | 30.001s, sau mốc | Login đúng được xét | Pass với clock fixture tại điểm so sánh |

Kết quả fixture xác nhận nhánh so sánh tại các mốc giả lập, nhưng không thay bằng chứng khóa tự nhiên 30 giây. Finding thực tế: counter tăng 2 mỗi lần và khóa sớm ở lần 2; khóa runtime dài khoảng 180 giây. Các lỗi này không bị xóa bởi ba checkpoint clock fixture.

## B-FR07 — Giỏ hàng Web

### Yêu cầu, input, state và output

Input gồm sản phẩm/ID, đơn giá, quantity, thao tác thêm/cộng/trừ/xóa/confirm/cancel/tiếp tục mua sắm. State gồm số dòng, sản phẩm và quantity mỗi dòng, giá, tổng, dialog và trang hiện tại. Output gồm empty state, năm cột Sản phẩm/Đơn giá/Số lượng/Thành tiền/Thao tác, gộp sản phẩm, tiền dòng/tổng, dialog, điều hướng và phản hồi thêm.

| ID | Yêu cầu và nguồn expected |
|---|---|
| B-R01 | Giỏ rỗng hiển thị hình minh họa và thông báo rõ giỏ rỗng (FR-07). |
| B-R02 | Giỏ có hàng hiển thị cột Sản phẩm, Đơn giá, Số lượng, Thành tiền, Thao tác. |
| B-R03 | Thêm sản phẩm tạo dòng có thông tin hàng; quantity lấy từ luồng thêm liên quan FR-06. |
| B-R04 | Thêm cùng sản phẩm lần nữa gộp vào một dòng và tăng quantity, không tạo dòng trùng. |
| B-R05 | Có nút `+` chỉnh quantity; bước tăng cụ thể chưa nêu tường minh trong SRS. |
| B-R06 | Có nút `−`; quantity tối thiểu 1 theo FR-06/phân công; kết quả giảm tại 1 chưa rõ. |
| B-R07 | Có thành tiền từng dòng; công thức đơn giá × quantity được phân công nhóm nêu. |
| B-R08 | Nhãn chính xác “Tổng cộng” và có giá trị tổng; công thức/rounding/phí chưa mô tả đầy đủ. |
| B-R09 | Bấm Xóa phải mở xác nhận trước khi xóa. |
| B-R10 | Xác nhận xóa bỏ đúng dòng đã chọn; expected suy ra từ thao tác xóa. |
| B-R11 | Hủy xác nhận không xóa; đây là giả định cần review do SRS không nói cụ thể nhánh Hủy. |
| B-R12 | “Tiếp tục mua sắm” điều hướng về trang chủ; persistence không được quy định. |
| B-R13 | Input quantity FR-06 là số nguyên dương tối thiểu 1; phản hồi thêm trực quan qua toast hoặc badge. |

SRS không cho UB/tồn kho; cũng chưa chốt persistence qua reload, giá đổi, xử lý input invalid ở API, giảm từ 1, câu chữ dialog/empty state, cách tính tổng và định danh cùng sản phẩm.

### Phân lớp tương đương

Các lớp B-EC-01–39 được chia theo nhóm sau. Mỗi đại diện chỉ được dùng với expected ở cột bên phải; các lớp “chưa kết luận” là probe, không phải pass/fail.

| EC | Phân hoạch và đại diện | Expected/giới hạn |
|---|---|---|
| B-EC-01–03 | Giỏ 0 dòng; 1 dòng P1; nhiều dòng P1/P2 | Empty state; đủ cột; các sản phẩm khác nhau có dòng tương ứng. |
| B-EC-04–05 | Thêm lại cùng ID P1; thêm ID P2 khác | Cùng sản phẩm gộp/tăng quantity; identity theo ID là đại diện cần xác nhận. |
| B-EC-06–09 | Sản phẩm tồn tại; ID không rõ; giá biết; giá thiếu/đổi | Sản phẩm/giá được hiển thị; xử lý product/price không tồn tại hoặc biến động là câu hỏi. |
| B-EC-10–16 | Quantity `1`, `2`; `0`, `-1`, `1.5`, `abc`; các payload API invalid | FR-06 chỉ ra số nguyên dương ≥1 cho trường nhập; API validation không có oracle. |
| B-EC-17–19 | `+`; `−` khi q>1; `−` tại q=1 | Có control và thay đổi theo hướng; giảm tại min chưa có expected cụ thể. |
| B-EC-20–23 | Bấm Xóa; confirm; cancel; tiếp tục mua sắm | Dialog trước xóa; xác nhận xóa; cancel là giả định; tiếp tục về Home. |
| B-EC-24–27 | Empty state đầy đủ/thiếu phần; dòng hàng; dòng trùng | Hình+thông báo; năm cột; không có duplicate khi thêm lại. |
| B-EC-28–30 | Đơn giá; thành tiền đúng/sai p×q | Thành tiền theo phân công `p×q`; format/rounding chưa rõ. |
| B-EC-31–33 | Nhãn Tổng cộng/nhãn khác; tổng số tiền | Nhãn phải đúng; tổng tiền quan sát được nhưng công thức chưa được đặc tả/review đủ. |
| B-EC-34–38 | Toast/badge; thiếu cả hai; xóa confirm/cancel; số badge | FR-06 cho toast hoặc badge; số badge và cancel chưa chốt. |
| B-EC-39 | Reload khi có hàng | Persistence chưa được SRS quy định, chỉ probe. |

### Ca Domain được thiết kế và kết quả

Có 20 ca Domain. B-DT-001 giỏ rỗng (**Fail**, thiếu hình minh họa); 002 một sản phẩm (**Fail**, đường thêm từ trang chi tiết không thêm hàng ở lần click hợp lệ); 003 hai sản phẩm khác nhau (**Pass**); 004 thêm lại cùng sản phẩm (**Fail**, tạo dòng trùng); 005 tính thành tiền/tổng (**Observation**, thành tiền dòng khớp, oracle tổng còn mở); 006/008 hiện diện nút `+`/`−` (**Fail**, control thiếu); 007 tăng, 009 giảm q>1, 010 giảm tại 1 (**Blocked**, phụ thuộc control thiếu); 011 dialog xác nhận xóa (**Fail**, dòng xóa ngay); 012 confirm xóa đúng dòng và 013 xóa dòng cuối (**Blocked**, dialog/nhánh confirm thiếu); 014 tiếp tục mua sắm (**Pass**); 015 nhãn tổng (**Fail**, thấy “Tổng tạm tính”); 016 quantity 0 (**Fail**); 017 âm (**Fail**); 018 thập phân (**Fail**, 1.5 hiển thị thành 1); 019 không phải số (**Fail**, input rỗng vẫn tạo NaN); 020 API quantity thập phân (**Observation**, API oracle chưa đủ). B-DT-003/014 Pass. Supplementary UI chạy lại quantity từ trang chi tiết với hai lần click; không thay bản ghi gốc thành ca khác.

### BVA: lower bound quantity

Quantity có lower bound 1 từ FR-06; `δ=1`. Không có upper bound (UB) được nêu. Giá trị 0/1/2 được thử tại ô nhập; thao tác `−` là state transition riêng, không nhận input số âm/thập phân giả lập.

| TC | Điểm/expected | Actual mới nhất |
|---|---|---|
| B-BV-001 | `q=0` (LB−δ): không chấp nhận quantity | Fail: dòng quantity 0, thành tiền 0 |
| B-BV-002 | `q=1` (LB): chấp nhận | Pass: quantity 1, thành tiền 30.000.000 VND |
| B-BV-003 | `q=2` (LB+δ): chấp nhận | Pass: quantity 2, thành tiền 60.000.000 VND |
| B-BV-004 | Bấm giảm từ q=2 về biên | Blocked vì không có nút `−` |
| B-BV-005 | Bấm giảm tại q=1 | Blocked; không có control/dialog để chạy nhánh |
| B-BV-006 | Bấm tăng tại q=1 | Blocked vì không có nút `+` |

Supplementary UI cũng xác nhận `-1` tạo quantity âm, `1.5` bị chuyển thành 1, và giá trị không phải số tạo dòng NaN. Không đặt expected về UB, tồn kho hay invalid API. Sản phẩm P1 giá 30.000.000 VND và P2 giá 28.000.000 VND; checkpoint hai dòng ghi thành tiền 60.000.000 + 28.000.000 = 88.000.000 VND. Tổng số học đúng nhưng TC tổng vẫn Observation vì oracle công thức tổng chưa được chốt/review.

## C-FR14 — Quản lý danh mục Admin

### Yêu cầu, input, state và output

Input là tên danh mục, JWT, role trong token, category ID; state là danh sách trước/sau và danh tính/role phiên Admin. Output là dòng danh mục trên Web, response API và việc state thay đổi.

| ID | Yêu cầu và expected |
|---|---|
| C-R01 | Chức năng danh mục thuộc phân hệ Admin; role user thường không được vào giao diện Admin. |
| C-R02 | Admin thêm danh mục và danh mục mới xuất hiện. |
| C-R03 | Có thể xem danh sách danh mục. Không suy rộng GET công khai thành lỗi quyền. |
| C-R04 | Admin xóa đúng danh mục đã chọn. |
| C-R05 | Tên là bắt buộc, không được để trống. |
| C-R06 | API ghi POST/DELETE cần JWT hợp lệ và role admin theo FR-12. Status/body lỗi chưa quy định. |

FR-14 không bắt buộc sửa danh mục dù tiêu đề chức năng ghi CRUD. Không tự thêm uniqueness, max length, trim, xóa category đang được product tham chiếu hoặc mã HTTP cụ thể. Whitespace-only và ID không tồn tại là probe.

### Phân lớp tương đương

| EC | Lớp/đại diện | Expected/giới hạn |
|---|---|---|
| C-EC-01–04 | Tên rỗng; tên thường; Unicode có dấu; ba dấu cách | Rỗng phải bị từ chối; tên có chữ được thêm; whitespace-only cần hỏi về trim. |
| C-EC-05–06 | Danh sách rỗng / có dữ liệu | Có thể xem state tương ứng; empty wording/order/schema không chốt. |
| C-EC-07–09 | ID test vừa tạo; ID đã tồn tại; ID không tồn tại | Xóa đúng ID test; không dùng dữ liệu mẫu để destructive test; phản hồi ID vắng mặt chưa chốt. |
| C-EC-10–14 | Admin JWT; user JWT; không token; token invalid; token hết hạn | POST/DELETE chỉ admin hợp lệ được ghi; các nhóm còn lại không được thay đổi state. |
| C-EC-15 | GET với admin/user/guest | Quan sát riêng; không đặt expected cấm GET khi SRS chưa nói. |

### Ca Domain được thiết kế và kết quả

Có 18 ca Domain: C-DT-001 thêm ASCII (**Pass**); 002 thêm Unicode (**Pass**); 003 tên rỗng (**Fail**); 004 whitespace-only (**Observation**); 005 xem danh sách có dữ liệu (**Pass**); 006 GET theo trạng thái xác thực (**Observation**); 007 xóa đúng category test (**Pass**); 008 dialog/Hủy (**Blocked**, UI không có dialog; FR-14 không yêu cầu dialog nên không kết luận bug); 009 POST admin (**Pass**); 010 DELETE admin (**Pass**); 011 POST thiếu token (**Pass**); 012 POST token sai (**Pass**); 013 POST token hết hạn (**Pass**); 014 POST JWT role user (**Fail**); 015 DELETE thiếu token (**Pass**); 016 DELETE token sai (**Pass**); 017 DELETE token hết hạn (**Pass**); 018 DELETE JWT role user (**Fail**). Các bản ghi test được dọn đúng ID; category mẫu ID 1–3 được giữ nguyên.

Lượt UI bổ sung với user fixture hợp lệ xác nhận không vào được Admin dashboard: giao diện báo “Bạn không phải là admin!” và không có admin token. API role-user được kiểm tra riêng trên bản sao cô lập: POST tạo danh mục và DELETE xóa target do test tạo, cả hai trả HTTP 200 và state đổi. Không dùng API để suy ra giao diện.

### BVA: tên và ID

Tên bắt buộc không rỗng: lower bound `LB=1 ký tự`, `δ=1`; do đó thử 0/1/2 ký tự. Không có UB được nêu. ID tồn tại/không tồn tại là domain probe, không phải biên số học.

| TC | Giá trị/expected | Kết quả mới nhất |
|---|---|---|
| C-BV-001 | 0 ký tự: từ chối, không tạo dòng | Fail: tên rỗng được tạo |
| C-BV-002 | 1 ký tự `Q`: được tạo và hiển thị | Pass |
| C-BV-003 | 2 ký tự `QZ`: được tạo và hiển thị | Pass |
| C-BV-004 | ID tồn tại do test tạo: xóa target, giữ đối chứng | Pass |
| C-BV-005 | ID vắng mặt: chỉ probe; status chưa có expected | Observation; DELETE trả 200 nhưng không gán đúng/sai theo status |

## D-MREG — Đăng ký Mobile

### Yêu cầu, input, state và output

Input gồm họ tên, email, password, password confirmation; trạng thái email đã tồn tại/chưa tồn tại; kết quả tạo account và màn hình app. Output cần quan sát trên Mobile là validation, phản hồi submit và điều hướng; API phụ trợ quan sát request/response và state account, nhưng không thay thế UI.

| ID | Yêu cầu và expected |
|---|---|
| D-R01 | Họ tên bắt buộc. |
| D-R02 | Email bắt buộc. |
| D-R03 | Email đúng định dạng. |
| D-R04 | Email duy nhất; không tạo tài khoản thứ hai cùng email. |
| D-R05 | Mật khẩu bắt buộc. |
| D-R06 | Password ít nhất 8 ký tự, có ít nhất một chữ hoa, một chữ thường, một chữ số và ít nhất một ký tự thuộc tập `@$!%*?&`. Đây là membership: không yêu cầu đủ mọi ký tự trong tập. |
| D-R07 | Confirmation bắt buộc và phải khớp với password. |
| D-R08 | Dữ liệu hợp lệ tạo account thành công; API spec nêu HTTP 200, message và ID. |
| D-R09 | Sau đăng ký thành công app chuyển về màn hình Login. |

Không có oracle cho trim họ tên/email, normalization/grammar chi tiết email, max length, cách đếm Unicode, câu chữ/status khi lỗi, mạng lỗi/retry, confirmation ở API, race condition uniqueness hoặc điều hướng khi đăng ký thất bại.

### Phân lớp tương đương

| EC | Lớp/đại diện | Expected/giới hạn |
|---|---|---|
| D-EC-01–02 | Họ tên rỗng / thông thường | Rỗng không tạo account; tên thường đạt riêng điều kiện này. |
| D-EC-03–06 | Email rỗng; sai format; hợp lệ mới; hợp lệ đã tồn tại | Bắt buộc/format/unique được tách riêng; email trùng bị từ chối; status lỗi chưa chốt. |
| D-EC-07–14 | Password rỗng; 7/8/9 ký tự hợp lệ về nhóm; thiếu riêng hoa/thường/số/ký tự thuộc tập | Dưới 8 hoặc thiếu nhóm bị từ chối; 8/9 đạt điều kiện độ dài, không có UB. |
| D-EC-15–17 | Confirmation khớp / không khớp / rỗng | Chỉ khớp mới đạt D-R07; API contract hiện tại không có confirmation field. |
| D-EC-18–21 | API success / validation failure / network success / network failure | Success theo contract; error details và network behavior chưa có expected. |
| D-EC-22–24 | App Register / Login sau success / màn hình sau thất bại | Form cần bốn trường; success về Login; điều hướng khi thất bại chưa chốt. |

### Ca Domain được thiết kế và kết quả

13 ca Domain: D-DT-001 đủ bốn trường (**Fail**, thực tế form chỉ có ba trường Họ tên/Email/Password); D-DT-002 success email mới; 003 tên rỗng; 004 email rỗng; 005 email sai format; 006 email trùng; 007 password rỗng; 008 thiếu hoa; 009 thiếu thường; 010 thiếu số; 011 thiếu ký tự thuộc tập; 012 confirmation sai; 013 confirmation rỗng. Trong D-DT-002–011, thao tác ba trường có evidence nhưng full TC là **Partial** do thiếu confirmation; D-DT-012/013 **Blocked**. Các probe trên form ba trường cho thấy tên rỗng/email rỗng/email sai format được chấp nhận và email duplicate tạo account thứ hai; các findings này được ghi rõ là biến thể, không đổi verdict full TC. Password rỗng/thiếu nhóm và length 7 bị từ chối trong các probe.

### BVA: độ dài password và robustness

LB password là 8 ký tự, `δ=1`. Mẫu hợp lệ về nhóm: 7 `Aa1!bbb`, 8 `Aa1!bbbb`, 9 `Aa1!bbbbb`. Robustness thiếu riêng một nhóm được ghi riêng, không gọi là biên độ dài.

| TC | Điểm/expected | Kết quả mới nhất |
|---|---|---|
| D-BV-001 | 7 ký tự (LB−δ), reject | Partial: UI báo lỗi, count 0→0; confirmation field thiếu nên full flow chưa đạt setup |
| D-BV-002 | 8 ký tự (LB), đủ các nhóm, accept nếu input khác hợp lệ | Partial: network request failed; không kết luận biên |
| D-BV-003 | 9 ký tự (LB+δ), không có UB; accept nếu input khác hợp lệ | Partial: UI success/count/điều hướng ở variant 3 trường; không phải full TC |
| D-BV-004 | 8 ký tự, chỉ thiếu chữ hoa | Partial: probe báo lỗi; full form thiếu confirmation |
| D-BV-005 | 8 ký tự, chỉ thiếu chữ thường | Partial: probe báo lỗi; full form thiếu confirmation |
| D-BV-006 | 8 ký tự, chỉ thiếu chữ số | Not run: thao tác automation không đạt dữ liệu/response hợp lệ |
| D-BV-007 | 8 ký tự, chỉ thiếu ký tự thuộc `@$!%*?&` | Not run: thao tác automation không đạt dữ liệu/response hợp lệ |

Đăng ký API bổ trợ chạy trên DB clone xác nhận hai POST tuần tự cùng email đều HTTP 200 và tạo hai account, count 0→1→2. Đây không phải test Mobile UI và không kiểm tra race. Lượt emulator 16/10 mở app được nhưng nút “Đăng nhập” bị vẽ chồng với status bar; thao tác không tới màn Register. Không restart backend hoặc sửa logic SUT.

## Kết quả tổng hợp, findings và giới hạn

### Findings có expected và bằng chứng

| Feature | Finding | Ca/requirement liên quan | Kết luận |
|---|---|---|---|
| A-FR02 | Counter tăng 2 sau mỗi lần sai; khóa từ lần sai thứ hai | A-DT-002/011/014/020; A-BV-002–005; A-R04/R05 | Fail đã tái hiện trên API và Web. |
| A-FR02 | Khóa thực tế kéo dài khoảng 180s, vượt yêu cầu 30s | A-DT-013/021/022; A-BV-008/010; A-R06 | Fail; client timing được ghi, fixture clock dùng riêng cho operator checkpoints. |
| A-FR02 | Email input Web là `type=text`; sai format được gửi thay vì HTML5 chặn | A-DT-004/020; A-R10 | Fail. |
| B-FR07 | Empty state thiếu hình minh họa | B-DT-001; B-R01 | Fail. |
| B-FR07 | Thêm từ trang chi tiết không thêm ở lần click đầu; thêm lại cùng P1 tạo dòng trùng | B-DT-002/004; B-R03/R04 | Fail. |
| B-FR07 | Không có `+/-`; xóa dòng ngay không có dialog; nhãn là “Tổng tạm tính” | B-DT-006–013/015; B-R05/R06/R09/R11/R08 | Presence/label behaviors fail; ca tương tác phụ thuộc nút/dialog blocked. |
| B-FR07 | Quantity 0, âm, thập phân và rỗng/không phải số tạo giá trị không hợp lệ | B-DT-016–019; B-BV-001; B-R13 | Fail theo FR-06. |
| C-FR14 | Tên rỗng được tạo; role user JWT có thể POST/DELETE danh mục | C-DT-003/014/018; C-BV-001; C-R05/R06 | Fail; API role checks trên clone đã củng cố. |
| D-MREG | Form thiếu confirmation; UI variant chấp nhận tên/email rỗng, sai format, duplicate | D-DT-001/003–006; D-R01–R04/R07 | Form presence Fail; các probes validation được ghi là variant vì full TC có 4 trường chưa hoàn tất. |
| D-MREG | API chấp nhận tạo account thứ hai cùng email | API supplementary; D-R04 | Fail API; không phải race test và không thay Mobile UI. |

Các vấn đề còn quan sát/probe nhưng không được kết luận bug: email normalize/trim A; công thức tổng B chưa được review/chốt; API GET categories và ID không tồn tại C; network failure/password length 8 D; whitespace/trim/max length/rounding/persistence/race nơi SRS im lặng. C-DT-008 không có dialog nhưng FR-14 không yêu cầu dialog; không báo là bug.

### Giới hạn và trạng thái completeness

- A-BV-006/009 là Partial: fixture kiểm tra elapsed được, nhưng setup khóa tự nhiên sai ngưỡng vì khóa từ lần sai thứ hai. A-BV-007/011/012 pass ở clock fixture, không chứng minh khóa tự nhiên được thiết lập đúng. A-BV-008/010 cho thấy khóa còn hiệu lực sau 31/40s trong baseline.
- B có 8 ca Blocked do control +/- hoặc dialog không tồn tại; ghi Fail riêng cho sự hiện diện. B-DT-005 và B-DT-020 là Observation do oracle chưa chốt.
- C có một ca Blocked (nhánh Hủy dialog không tồn tại) và ba Observation; GET không bị đánh giá theo chính sách chưa có.
- D chưa có bất kỳ full TC Pass nào. Một full TC Fail xác nhận form thiếu trường; 15 Partial là thao tác variant trên form 3 trường; 2 Blocked phụ thuộc confirmation; 2 Not run do không có submit/evidence hợp lệ. Không suy ra Mobile UI từ API.


### Cách đếm và hồ sơ nộp cập nhật 17/10/2026

92 TC ID có kết quả hoặc quan sát (36 Pass theo phạm vi checkpoint, 32 Fail, 17 Partial, 7 Observation); 11 Blocked và 2 Not run. 68 ID ghi Pass/Fail không đồng nghĩa 68 full-flow TC hoàn tất: ba điểm A-BV-007/011/012 chỉ Pass clock fixture; các giới hạn trong execution phải được giữ. Không tính các ID supplementary thành TC thiết kế mới.

GitHub hiện có 14 issue OPEN (#1–#14), đã kiểm tra ngày cập nhật; body có liên kết ảnh và bản sao ảnh được lưu trong hồ sơ. Các finding quantity B-DT-016–019/B-BV-001 đã có trong báo cáo, chưa có issue riêng. Ảnh #7/#8 được dựng từ log API và ghi rõ nguồn, không phải ảnh UI. AI Critique đã được sinh viên xác nhận nội dung. Skill và kịch bản có sẵn; video chưa quay. Điểm tự chấm vẫn để trống.

**Link YouTube demo:**

## Truy vết yêu cầu sang Domain và BVA

| Feature/requirement | Domain classes/cases | BVA cases |
|---|---|---|
| A-R01–R03 login input/outcome | A-EC-E01–E07, P01–P06, G01–G03, O01/O02/O06; A-DT-001–010, 015–019, 023–024 | A-BV-001 |
| A-R04–R05 counter/threshold | A-EC-N01–N05, H01–H05; A-DT-002, 011, 014, 020–022 | A-BV-002–005 |
| A-R06 lock time | A-EC-L01–L04/O03–O04; A-DT-012/013/021/022 | A-BV-006–012 |
| A-R07–R09 errors/token | A-EC-O01–O06, T01–T03; A-DT-001–003/023/024 | Liên quan checkpoints login đúng/sai ở BV-001/003/006–012 |
| A-R10 email HTML5; A-R11 liên tiếp | A-EC-E03/G02/H01–H03; A-DT-004/014/020 | Threshold cases kiểm tra chuỗi liên tiếp |
| B-R01–R02 empty/cột | B-EC-01–03, 24–28; B-DT-001–003 | Không có biên số dòng trong SRS; đại diện 0/1/nhiều |
| B-R03–R04 add/merge | B-EC-04–07/27; B-DT-002–004 | Quantity điểm 1/2 hỗ trợ add |
| B-R05–R06 +/- | B-EC-17–19; B-DT-006–010 | B-BV-004–006, blocked do control thiếu |
| B-R07–R08 amount/total | B-EC-28–33; B-DT-005/015 | Không có numeric boundary được nêu |
| B-R09–R12 delete/navigation | B-EC-20–23/36–37; B-DT-011–014 | B-BV state transitions 004/005 |
| B-R13 quantity min 1 | B-EC-10–16; B-DT-016–020 | B-BV-001–003: 0/1/2, δ=1 |
| C-R01/R06 role | C-EC-10–15; C-DT-006/011–018 | Không có BVA số học cho role/token |
| C-R02/R05 add/name | C-EC-01–04; C-DT-001–004 | C-BV-001–003: 0/1/2 ký tự |
| C-R03 list | C-EC-05/06/15; C-DT-005/006 | Không có biên số dòng được nêu |
| C-R04 delete/ID | C-EC-07–09; C-DT-007/008/010 | C-BV-004/005: ID tồn tại/vắng mặt là probe domain, không UB |
| D-R01–R04 name/email/unique | D-EC-01–06; D-DT-002–006 | Không có length limit cho name/email |
| D-R05–R06 password | D-EC-07–14; D-DT-007–011 | D-BV-001–003: 7/8/9; D-BV-004–007: robustness từng nhóm |
| D-R07 confirmation | D-EC-15–17; D-DT-001/012/013 | Không có biên độ dài được nêu |
| D-R08–R09 create/navigate | D-EC-18–24; D-DT-002/012/013 | D-BV success points chỉ kết luận khi setup bốn trường hợp lệ |

## Kết luận

Báo cáo bao phủ đầy đủ yêu cầu được giao, các lớp tương đương, thiết kế Domain/BVA, trạng thái thực thi mới nhất và các vấn đề chưa đủ oracle. Kết quả cho thấy các lỗi cụ thể ở counter/lock, validation, cart quantity/controls, category name/authorization và form đăng ký Mobile. Một phần test vẫn chưa hoàn tất vì SUT thiếu control/field hoặc vì oracle/setup chưa đủ; các phần đó được để Partial, Observation, Blocked hoặc Not run thay vì gán Pass. Đây là báo cáo kết quả kiểm thử, không tự chấm điểm rubric.


## Phụ lục — Nội dung đầy đủ của requirements, Domain Testing và BVA

Phần này đưa nguyên nội dung thiết kế chi tiết vào cùng báo cáo để bản Markdown/PDF tự chứa. Các tổng kết và verdict trong phần đầu báo cáo là kết quả thực thi mới nhất; các phụ lục bên dưới giữ dữ liệu, expected, bước thao tác, lớp EC và biên đã thiết kế. Đây là snapshot thiết kế: các câu “chưa chạy”, “chưa review” mô tả thời điểm soạn thiết kế, không phải trạng thái hiện tại. Trạng thái hiện tại nằm ở phần tổng hợp và phụ lục execution cập nhật cuối báo cáo.

### A-FR02 — thiết kế đầy đủ

#### 01-requirements — A-FR02

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.


##### 1. Hiểu chức năng bằng lời đơn giản

Người dùng nhập email và mật khẩu để đăng nhập. Nếu thông tin đúng và tài khoản không bị khóa, hệ thống cho đăng nhập và cấp JWT token — một chuỗi dùng để chứng minh người dùng đã đăng nhập khi gọi API cần xác thực.

Nếu nhập sai liên tiếp, hệ thống đếm số lần sai. Mỗi lần được tính là sai làm bộ đếm tăng đúng 1. Đến lần sai thứ 3, tài khoản bị khóa tạm thời 30 giây. Vì vậy, khi thiết kế kiểm thử, không chỉ nhìn email/password mà còn phải biết tài khoản đã sai mấy lần và đang ở thời điểm nào trong khoảng khóa.

“Expected result” là **kết quả hệ thống phải tạo ra theo yêu cầu**. Nó khác với kết quả thực tế khi chạy ứng dụng. Mã nguồn hiện tại không thay thế đặc tả để quyết định thế nào là đúng.

##### 2. Nguồn căn cứ

| Mã nguồn tài liệu | Tài liệu và phần sử dụng | Vai trò |
|---|---|---|
| S1 | SRS EShop, FR-02 | Nguồn chính cho hành vi đăng nhập, bộ đếm, khóa, token và email Web |
| S2 | API specification, mục 1.2 | `POST /api/login`, body `email`/`password`, thành công HTTP 200 và có `token`, `user` |
| S3 | [Slide VN](../slide/domain-testing-vn.pdf), trang 6–7 | Bước 1: xác định Input/Output dựa vào đặc tả |
| S4 | [Slide EN](../slide/domain-testing-en.pdf), trang 13–14 | Quy trình Domain Testing; xác định Input/Output trước khi chia lớp/chọn ca |
| S5 | Phân công nhóm, Thành viên 2 | Phạm vi FR-02 trên Web; chú ý số lần sai và thời gian khóa |
| S6 | [Đề HW02](../2026.HW02.Domain%20Testing_En.pdf), mục 6, 9, 12 | Giải thích từng bước, lưu AI Audit và commit theo bước |

Baseline SUT: `85af3ba875c88283615e22cb108f13e2fccaf0e9`. SRS cố định tại baseline. S3/S4 hướng dẫn cách phân tích, không cung cấp quy tắc nghiệp vụ đăng nhập EShop.

##### 3. Từng yêu cầu và kết quả mong đợi

**Trực tiếp:** tài liệu có nêu rõ. **Diễn giải:** suy ra ý nghĩa nghiệp vụ, cần giữ nhãn này khi thiết kế ca. Các chi tiết còn thiếu nằm ở mục 7.

| ID | Yêu cầu bằng lời đơn giản | Kết quả mong đợi để đối chiếu về sau | Nguồn và mức chắc chắn |
|---|---|---|---|
| A-R01 | Người dùng đăng nhập bằng email và mật khẩu | UI nhận hai giá trị; API login nhận `email`, `password` | S1 dòng đầu, S2 — trực tiếp |
| A-R02 | Đăng nhập đúng được cấp token | Khi thông tin đúng và không bị khóa: API thành công HTTP 200, trả JWT `token` và thông tin `user` | S1 phần đăng nhập thành công, S2 — trực tiếp về output; điều kiện đúng/không khóa là diễn giải nghiệp vụ |
| A-R03 | Thông tin sai không được đăng nhập thành công | Từ chối xác thực, không cấp token thành công mới cho lần đăng nhập sai | S1 nói về đăng nhập sai và thông báo lỗi — diễn giải; chưa quy định mã HTTP lỗi |
| A-R04 | Mỗi lần đăng nhập sai tăng bộ đếm đúng 1 | Với lần sai được tính vào chuỗi, `số_sai_sau = số_sai_trước + 1` | S1 dòng bộ đếm — trực tiếp; phạm vi những lỗi nào được tính cần làm rõ Q1/Q2 |
| A-R05 | Khóa khi sai liên tiếp từ lần thứ 3 | Lần sai thứ 3 kích hoạt khóa; 1–2 lần sai chưa đủ để kích hoạt khóa theo ngưỡng này | S1 ngưỡng ≥3 — trực tiếp; không suy ra request trong lúc khóa tiếp tục tăng bộ đếm |
| A-R06 | Khóa tạm thời 30 giây | Khoảng khóa kéo dài 30 giây từ mốc kích hoạt; trong khoảng khóa chưa cho đăng nhập thành công, kể cả nhập đúng | S1 thời lượng — trực tiếp; chặn trong thời gian khóa là diễn giải; chi tiết mốc đo ở Q4 |
| A-R07 | Khi sai/khóa phải báo lỗi phù hợp, không lộ chi tiết nguyên nhân | Có thông báo thể hiện thao tác không thành công; không lộ chi tiết nhạy cảm. Không tự bắt buộc một câu lỗi cụ thể | S1 thông báo lỗi — trực tiếp; mức độ chi tiết cho phép ở Q6 |
| A-R08 | Token được lưu phía client | Sau thành công, client giữ token để dùng cho yêu cầu cần xác thực | S1 token — trực tiếp; không bắt buộc localStorage hay cơ chế lưu cụ thể |
| A-R09 | Gửi token đúng header khi gọi API cần xác thực | Request cần xác thực mang `Authorization: Bearer <token>` | S1 token — trực tiếp; không áp cho mọi request công khai |
| A-R10 | Email trên Web dùng validation HTML5 | Input email có `type="email"`; giá trị sai định dạng bị validation HTML5 xử lý khi submit form | S1 email — trực tiếp; `type=email` một mình không quy định trường rỗng bắt buộc bị chặn |
| A-R11 | Đếm các lần sai liên tiếp | Một lần đăng nhập thành công ngắt chuỗi sai; lần sai tiếp theo là lần đầu của chuỗi mới | Diễn giải từ từ “liên tiếp” trong S1; không bắt buộc một cách lưu DB cụ thể |

Khi khóa hết 30 giây, rào cản khóa tạm thời phải hết; thông tin đúng có thể được xét đăng nhập. Điều này không đồng nghĩa mọi request sau 30 giây đều thành công: email/password vẫn phải đúng. SRS chưa nêu cách tính bộ đếm nếu request sau hết khóa tiếp tục sai (Q3).

##### 4. Đầu vào cần ghi lại

| ID | Đầu vào | Ý nghĩa và điều cần ghi |
|---|---|---|
| A-I01 | Email nhập | Chuỗi người dùng nhập; ghi nguyên giá trị, có rỗng/khoảng trắng hay không; tài khoản tương ứng có tồn tại hay không |
| A-I02 | Mật khẩu nhập | Chuỗi người dùng nhập; đúng hay sai so với tài khoản đã chuẩn bị; không áp quy tắc độ mạnh của đăng ký FR-01 lên login |
| A-I03 | Thao tác gửi đăng nhập | Submit từ form Web hay gọi API trực tiếp; browser có thể chặn trước khi request đến server |
| A-I04 | Thứ tự các lần đăng nhập | Trình tự đúng/sai và khoảng thời gian giữa các lần; đây là đầu vào dạng chuỗi thao tác, không phải một ô trên form |
| A-I05 | Thời điểm gửi/xử lý request | Phục vụ xác định request trước hay sau thời điểm hết khóa; không chỉ dựa vào thời gian lúc UI hiện thông báo |

Tài khoản đã lưu, bộ đếm và trạng thái khóa là **điều kiện trước khi thao tác**, không phải giá trị mà người dùng sửa trong form login. Dữ liệu test sẽ được xác định ở bước thiết kế ca, chưa tạo trong bước này.

##### 5. Trạng thái cần theo dõi

| ID | Trạng thái | Cách hiểu | Vì sao cần biết? |
|---|---|---|---|
| A-S01 | Tài khoản tồn tại và thông tin xác thực đã chuẩn bị | Biết email nào có thật và mật khẩu đúng tương ứng | Tránh coi lỗi chuẩn bị tài khoản là lỗi chức năng |
| A-S02 | Số lần sai liên tiếp | Gọi là `n`: số lần sai đã được tính trước lần thao tác hiện tại | Kiểm tra tăng đúng 1 và kích hoạt khóa đúng lần thứ 3 |
| A-S03 | Đang khóa hay không | Trạng thái tài khoản ở thời điểm xét request | Cùng mật khẩu đúng có thể được chấp nhận hoặc bị chặn tùy trạng thái |
| A-S04 | Mốc khóa `t0` và thời gian đã trôi qua | `elapsed = thời_điểm_xét − t0`; `t0` là lúc kích hoạt khóa | Không đo 30 giây từ lần sai đầu tiên |
| A-S05 | Kết quả thao tác trước | Đúng/sai/đang khóa hoặc bị browser chặn | Phân biệt chuỗi sai liên tiếp và các thao tác không chắc được tính |
| A-S06 | Token phía client trước và sau thao tác | Có token cũ hay chưa; token nào xuất hiện sau thành công | Không nhầm token cũ còn lưu với token mới do request thất bại cấp |

Đây là tên biến phân tích, không khẳng định các trường DB bắt buộc mang đúng tên này. Khi thực thi, có thể quan sát UI, Network và đọc trạng thái DB bổ trợ nếu cần; phải ghi cách quan sát. Không chỉnh bộ đếm hoặc giờ khóa rồi coi đó là bằng chứng của luồng người dùng thật mà không khai báo fixture.

##### 6. Đầu ra và nơi quan sát khi thực thi sau này

| ID | Đầu ra cần quan sát | Nơi quan sát dự kiến | Yêu cầu liên quan |
|---|---|---|---|
| A-O01 | Đăng nhập thành công/thất bại | UI và response của `POST /api/login` | A-R02, A-R03, A-R05, A-R06 |
| A-O02 | HTTP status, `token`, `user` khi thành công | Network hoặc response API | A-R02 |
| A-O03 | Thông báo lỗi và thông tin bị tiết lộ | UI và response API; phân biệt thông báo mỗi tầng | A-R07 |
| A-O04 | Bộ đếm thay đổi sau request | Quan sát trạng thái có kiểm soát; UI có thể không hiển thị bộ đếm | A-R04, A-R05, A-R11 |
| A-O05 | Bắt đầu khóa và hết khóa | Response/thao tác đăng nhập cùng timestamp, trạng thái bổ trợ nếu có | A-R05, A-R06 |
| A-O06 | Client lưu token và gửi đúng header | Trạng thái lưu client và Network của request cần xác thực | A-R08, A-R09 |
| A-O07 | Kiểu input email và validation | Inspect phần tử Web, phản hồi browser khi submit | A-R10 |

Các hàng này chỉ xác định **sẽ quan sát gì**. Chưa có actual result. Chuyển trang/hiển thị tên người dùng có thể là dấu hiệu bổ trợ; FR-02 không quy định cụ thể phải chuyển đến URL nào sau đăng nhập.

##### 7. Điểm chưa rõ — không tự biến thành yêu cầu chắc chắn

| ID | Câu hỏi còn thiếu trong SRS | Cách xử lý trước khi chốt ca |
|---|---|---|
| Q1 | Email không tồn tại thì đếm sai cho đối tượng nào? | Chưa có tài khoản để gắn bộ đếm; chỉ xác định phải từ chối xác thực, không tự đặt cơ chế đếm theo IP/email |
| Q2 | Rỗng/sai format/bị browser chặn và request trong lúc khóa có được tính là lần sai không? | Phân biệt tầng UI/API và loại lỗi; chưa khẳng định tất cả đều tăng bộ đếm |
| Q3 | Sau hết khóa, bộ đếm reset hay giữ? Một request sai tiếp có khóa lại ngay không? | Đánh dấu chưa rõ; không tự đặt expected cho chuỗi này. Ngắt chuỗi bởi thành công là diễn giải riêng A-R11 |
| Q4 | 30 giây được đo từ thời điểm xử lý nào, độ chính xác bao nhiêu? | Mô hình dự kiến là từ lúc kích hoạt khóa, hết khoảng khóa ở `t0+30s`; phải ghi cách đo/độ trễ trước khi khẳng định kiểm chứng đúng mốc bằng nhau |
| Q5 | Request trong lúc khóa có kéo dài thời hạn khóa không? | Chưa giả định có hoặc không; cần làm rõ trước khi dùng request thăm dò làm ảnh hưởng phép đo thời gian |
| Q6 | “Không để lộ chi tiết nguyên nhân” cấm phân biệt email sai/password sai đến mức nào? Có được nêu tài khoản đang khóa không? | Không bắt buộc mọi lỗi có cùng câu chữ; ghi diễn giải bảo mật và xin làm rõ khi cần kết luận bug từ khác biệt thông báo |
| Q7 | Email có trim/không phân biệt hoa thường không? Hai trường có độ dài tối đa hoặc bắt buộc chặn rỗng tại UI không? | Chưa có quy tắc rõ trong FR-02. Trường rỗng/sai kiểu là đầu vào cần xem xét, không tự tạo giới hạn hoặc chính sách chuẩn hóa |
| Q8 | Mã HTTP cho sai mật khẩu/đang khóa là gì? | S2 chỉ nêu thành công 200; không tự buộc 401/403 cho từng lỗi |
| Q9 | Token phải lưu ở đâu, tồn tại bao lâu, có phải còn sau reload không? | FR-02 chỉ yêu cầu lưu client và gửi header; chưa đặt TTL, localStorage bắt buộc hoặc lưu qua phiên |

Các câu hỏi trên được giữ để review/đối chiếu với giảng viên hoặc tài liệu bổ sung nếu có. Không cần giải quyết hết mới phân tích phần yêu cầu rõ ràng, nhưng ca phụ thuộc câu hỏi chưa giải quyết phải gắn nhãn giả định/chưa chốt expected.

##### 8. Giới hạn và bước tiếp theo

Phạm vi chính là đăng nhập Web và hành vi API hỗ trợ, khóa tài khoản, token, email HTML5. Không mở rộng sang đăng ký, reset mật khẩu hoặc kiểm thử toàn bộ API phân quyền. Các yêu cầu giao diện chung nếu bổ sung sau phải dẫn nguồn riêng, không gán chúng là nội dung FR-02.

Đã hoàn thành bản nháp xác định yêu cầu/input/output theo bước 1 trong slide. **Chưa phân hoạch EC, chưa tạo test case Domain/BVA, chưa chạy test và chưa ghi human review.**

Bước tiếp theo là `02-domains.md`: chia các biến/trạng thái thành nhóm có kết quả mong đợi tương tự, dùng ID A-R/A-I/A-S/A-O ở trên để truy vết. Bạn nên đọc mục 3 và 7 trước, đánh dấu câu nào còn khó hiểu để tôi giải thích.

#### 02-domains — A-FR02

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.


##### 1. Cách đọc và căn cứ

Lớp tương đương (EC) là nhóm giá trị mà ta dự kiến hệ thống xử lý theo cùng một quy tắc. Ví dụ, mật khẩu sai `Wrong123!` và `Wrong456!` đều thuộc nhóm “không khớp mật khẩu tài khoản”; chưa cần chạy mọi chuỗi sai để đại diện nhóm này.

Căn cứ: 01-requirements.md, đặc biệt A-R01–A-R11 và Q1–Q9; [slide VN](../slide/domain-testing-vn.pdf) trang 8–15; [slide EN](../slide/domain-testing-en.pdf) trang 15–31. Nguồn nghiệp vụ là SRS FR-02 và API specification mục 1.2 như đã dẫn trong requirements. Baseline: `85af3ba875c88283615e22cb108f13e2fccaf0e9`.

Quy ước:

- **H:** hợp lệ đối với điều kiện đang xét. Không có nghĩa cả lần đăng nhập chắc chắn thành công.
- **K:** không hợp lệ đối với điều kiện đó; dự kiến bị chặn/từ chối.
- **C:** chưa chốt được hành vi chi tiết từ đặc tả; phải giữ câu hỏi/giả định, không biến thành bug chắc chắn.
- Với trạng thái, “đang khóa” là trạng thái nghiệp vụ có thật nhưng **không đủ điều kiện đăng nhập**, nên được ghi K về quyền đăng nhập, không coi là dữ liệu hệ thống hỏng.
- Expected trong mỗi bảng giữ các điều kiện còn lại ở mức hợp lệ, trừ khi hàng đó ghi điều kiện khác. Mã HTTP lỗi, câu lỗi cụ thể, cách lưu token chưa được đặc tả thì không tự ấn định.

##### 2. Điều kiện nền cho các ví dụ

Dùng tài khoản test dự kiến `test@eshop.com`, mật khẩu đúng `Test1234!`. Phải xác nhận tài khoản này và trạng thái tại lúc chuẩn bị chạy; không suy ra trạng thái hiện tại chỉ từ dữ liệu seed.

Mặc định: tài khoản tồn tại, chưa khóa, chưa có lần sai trong chuỗi mới, không có token cũ ở client. Gọi `n` là số lần sai liên tiếp **trước** request hiện tại. Mỗi ví dụ là tình huống độc lập, không thực hiện nối tiếp bảng mà giữ nguyên state.

Ví dụ email chưa tồn tại dùng `absent-a-fr02@example.com`, cần kiểm tra chưa có tài khoản này trước khi chạy. Các giá trị null/số/object hoặc thiếu key chỉ dành cho API trực tiếp, không giả vờ có thể nhập chúng nguyên dạng qua ô Web.

##### 3. Email — A-I01 và sự tồn tại tài khoản A-S01

Tách hình dạng dữ liệu khỏi ý nghĩa xác thực. Trong bảng, xét thiếu key/sai kiểu/rỗng trước; với chuỗi không rỗng, tách trường hợp chuẩn hóa chưa rõ trước khi xét format và tài khoản. Như vậy không xếp cùng một giá trị vào hai hàng trong cùng cách phân chia này.

| EC ID | Nhóm và loại | Ví dụ đại diện | Expected và nguồn |
|---|---|---|---|
| A-EC-E01 | H — email đúng format, khớp chính xác tài khoản tồn tại | `test@eshop.com` | Với password đúng, chưa khóa: thành công 200, có token/user; A-R01/R02 |
| A-EC-E02 | K — đúng format nhưng tài khoản không tồn tại, không thuộc nhóm chuẩn hóa | `absent-a-fr02@example.com` | Từ chối xác thực, không cấp token thành công mới; không chốt bộ đếm cho email này; A-R03/R07, Q1 |
| A-EC-E03 | K — chuỗi không rỗng sai format rõ ràng, không thuộc nhóm chuẩn hóa | `not-an-email` | Web dùng HTML5 validation để chặn submit; API trực tiếp không được xác thực thành công với email không hợp lệ này; bộ đếm chưa chốt; A-R03/R10, Q2 |
| A-EC-E04 | C — chuỗi rỗng | `""` | Không có định danh hợp lệ để đăng nhập theo mô hình; chưa chốt Web có required hay không, lỗi/bộ đếm ra sao; A-R01/R03, Q2/Q7 |
| A-EC-E05 | C — giá trị cần quy tắc trim/hoa-thường | ` TEST@ESHOP.COM ` | Chưa chốt được coi là tài khoản có thật hay email khác/sai format; Q7. Không dùng làm ca sai format chắc chắn |
| A-EC-E06 | K về cấu trúc — thiếu key email | Body chỉ có `password` | Không đáp ứng đầu vào email; dự kiến không xác thực thành công; chưa chốt HTTP lỗi/validation/bộ đếm; A-R01, Q2/Q8 |
| A-EC-E07 | K về cấu trúc — email không phải chuỗi | `{"email":123,"password":"Test1234!"}` | Không đáp ứng mô hình email chuỗi; dự kiến không xác thực thành công; chi tiết xử lý ngoài contract chưa rõ; A-R01, Q2/Q8 |

E05 là nhóm tạm cần làm rõ, có thể tách tiếp phần khoảng trắng và hoa/thường khi có quy tắc. E07 đại diện sơ bộ cho null/số/boolean/array/object; nếu cần kiểm tra rủi ro ép kiểu khác nhau thì tách nhỏ, không khẳng định mọi kiểu chắc chắn chạy giống nhau. Không tự đặt độ dài tối đa email.

**Vì sao chia:** email tồn tại khác email không tồn tại về khả năng xác thực; sai format còn có tầng chặn HTML5; thiếu/sai kiểu là lỗi payload khác chuỗi rỗng; chuẩn hóa chưa được đặc tả.

##### 4. Mật khẩu — A-I02

Giữ email E01 và tài khoản chưa khóa. Đối chiếu với mật khẩu đúng đã chuẩn bị, không đánh giá độ mạnh của mật khẩu ở chức năng login.

| EC ID | Nhóm và loại | Ví dụ đại diện | Expected và nguồn |
|---|---|---|---|
| A-EC-P01 | H — chuỗi khớp mật khẩu tài khoản | `Test1234!` | Thành công nếu không khóa; A-R02 |
| A-EC-P02 | K — chuỗi không rỗng, không chỉ khoảng trắng và không khớp | `Wrong123!` | Từ chối; lần sai được tính tăng n đúng 1, khóa nếu đạt ngưỡng; A-R03/R04/R05/R07 |
| A-EC-P03 | C — chuỗi rỗng | `""` | Không khớp tài khoản nền nên không được đăng nhập; chặn UI hay API, bộ đếm chưa chốt; Q2/Q7 |
| A-EC-P04 | C — chuỗi chỉ có khoảng trắng | `"   "` | Không khớp mật khẩu nền; không đăng nhập; chưa chốt coi là thiếu hay sai password thông thường; Q2/Q7 |
| A-EC-P05 | K về cấu trúc — thiếu key password | `{"email":"test@eshop.com"}` | Thiếu thông tin xác thực, dự kiến từ chối; chi tiết status/bộ đếm chưa chốt; A-R01, Q2/Q8 |
| A-EC-P06 | K về cấu trúc — password không phải chuỗi | `{"email":"test@eshop.com","password":null}` | Payload ngoài mô hình chuỗi, dự kiến từ chối; lỗi và bộ đếm chưa chốt; A-R01, Q2/Q8 |

P06 cũng là nhóm sơ bộ như E07. Khi kiểm tra email sai, giữ password đúng; khi kiểm tra password sai, giữ email E01. Không ghép hai lỗi chỉ để giảm số lượng ca.

**Vì sao chia:** P02 có căn cứ rõ để kiểm tra đếm lần sai; P03/P04 có thể bị validation chặn trước khi xác thực. Chúng không nên bị gộp khi chưa biết có cùng quy tắc đếm hay không.

##### 5. Cách gửi — A-I03

Đây là các đường đi của thao tác, không phải mọi đường đều có thể gắn “input không hợp lệ”. API trực tiếp là cách kiểm tra bổ trợ hợp lệ, không thay thế kiểm tra form Web.

| EC ID | Nhóm và loại | Ví dụ | Expected và nguồn |
|---|---|---|---|
| A-EC-G01 | H — submit Web với giá trị hợp lệ theo validation | E01 + P01, bấm nút login | Request có email/password được xử lý; với điều kiện nền trả thành công; A-R01/R02 |
| A-EC-G02 | K về format — submit Web bị validation email chặn | E03 + P01 | Browser chặn request form do format; không xem đây là một lần xác thực sai ở server; A-R10. Chưa đặt kỳ vọng về cách UI khác quản lý state |
| A-EC-G03 | H về đường gửi — gọi API trực tiếp | POST `/api/login` với JSON E01 + P01 | Response theo dữ liệu và trạng thái; ví dụ nền thành công. Với payload sai, dùng expected nhóm E/P tương ứng; A-R01/R02 |

Ba hàng mô tả phạm vi thao tác login đang xét, không bao phủ phương thức/endpoint sai, JSON hỏng hoặc mọi lỗi mạng. Những nội dung đó ngoài phạm vi phân hoạch đầu vào FR-02 hiện tại.

##### 6. Số lần sai trước request — A-S02

Xét **email có thật và password sai không rỗng P02**, request đến server. Các trạng thái phụ thuộc nhau; không ghép `n≥3` với “chưa từng khóa” như một tình huống người dùng bình thường.

| EC ID | Nhóm và loại | Ví dụ đại diện | Expected và nguồn |
|---|---|---|---|
| A-EC-N01 | H về state — chuỗi mới, n=0, chưa khóa | Trước request đầu: n=0 | Sai → n=1, chưa khóa; A-R04/R05 |
| A-EC-N02 | H về state — n=1, chưa khóa | Đã sai một lần | Sai → n=2, chưa khóa; A-R04/R05 |
| A-EC-N03 | H về state — n=2, chưa khóa | Đã sai hai lần | Sai → n=3 và kích hoạt khóa 30 giây; A-R04/R05/R06 |
| A-EC-N04 | K về khả năng đăng nhập — đã đạt ngưỡng và đang khóa | n=3, mới khóa được 10 giây | Từ chối đăng nhập; không khẳng định lần thử tiếp làm n=4 hoặc kéo dài khóa; A-R06, Q2/Q5 |
| A-EC-N05 | C — từng đạt ngưỡng, khóa đã hết, chưa có lần thành công mới | n còn lưu từ chuỗi trước, đã qua 40 giây | Với P02 vẫn không xác thực thành công; reset/giữ n và khóa lại chưa chốt; Q3 |

N01/N02 được tách để phân biệt bắt đầu chuỗi và tiếp tục chuỗi, dù cùng quy tắc “tăng 1, chưa khóa”. N03 phải riêng vì làm thay đổi trạng thái khóa. n âm, thập phân hoặc null là state bất thường do lưu trữ/fixture, không phải lớp invalid mà người dùng nhập qua login; chưa đưa thành ca FR-02 bắt buộc.

##### 7. Thời gian và trạng thái khóa — A-I05, A-S03/A-S04

Để cô lập ảnh hưởng thời gian, dùng email/password đúng. `t0` là thời điểm kích hoạt khóa; `elapsed` tính theo thời điểm server xét request. Không gửi request thăm dò giữa chuỗi đo nếu chưa làm rõ Q5.

| EC ID | Nhóm và loại | Ví dụ đại diện | Expected và nguồn |
|---|---|---|---|
| A-EC-L01 | H — hiện không có khóa đã kích hoạt | Tài khoản nền n=0, không có t0 | Cho đăng nhập đúng; A-R02 |
| A-EC-L02 | K về khả năng đăng nhập — 0 ≤ elapsed < 30s | elapsed=10s | Chặn đăng nhập dù mật khẩu đúng; A-R06 |
| A-EC-L03 | H theo diễn giải — elapsed=30s | Đúng mốc t0+30s | Khoảng khóa hết, xét thông tin đúng để đăng nhập; Q4 về cách đo phải được làm rõ trước khi đánh giá đúng mốc |
| A-EC-L04 | H — elapsed>30s, không có tác động gia hạn xen giữa | elapsed=40s | Khóa cũ đã hết, cho đăng nhập đúng; A-R02/R06 |

L03 tách khỏi L04 để không che khuất vấn đề so sánh tại mốc hết khóa. Ví dụ 10/40 giây là đại diện miền; bộ điểm sát biên và cách đo đầy đủ được làm ở bước BVA, không coi bảng này đã thay thế BVA. elapsed âm là lỗi mô hình đo hoặc fixture, không phải khoảng thời gian khóa bình thường.

##### 8. Thứ tự thao tác/kết quả trước — A-I04, A-S05

Đây là các nhóm lịch sử cần xét, không tuyên bố đã chia mọi chuỗi thao tác vô hạn. Chọn theo sự kiện làm thay đổi cách đếm hoặc còn mơ hồ; có liên hệ với N/L, không cộng chúng thành những ca độc lập mặc định.

| EC ID | Nhóm và loại | Ví dụ cụ thể | Expected và nguồn |
|---|---|---|---|
| A-EC-H01 | H về lịch sử — sai nối tiếp khi chưa khóa | Sai → sai → sai, đều P02 | Bộ đếm 1 → 2 → 3, khóa ở lần thứ 3; A-R04/R05 |
| A-EC-H02 | H về lịch sử — thành công ngắt chuỗi sai | Sai → đúng → sai | Sau thành công chuỗi sai cũ kết thúc, lần sai cuối là lần 1; A-R11 là diễn giải từ “liên tiếp” |
| A-EC-H03 | C — xen thao tác bị validation Web chặn | Sai → email sai format bị chặn → sai | Thao tác bị chặn không có request xác thực; chưa chốt toàn bộ chính sách bộ đếm/chuỗi cho thao tác xen này; Q2 |
| A-EC-H04 | K khi đang khóa; C về state sau đó | Khóa → nhập đúng lúc 10s → thử lại sau đó | Lần tại 10s bị chặn; tác động lên thời hạn/counter và expected lần sau phụ thuộc Q2/Q5 |
| A-EC-H05 | C về counter sau hết khóa | Khóa → chờ hơn 30s không request xen → nhập sai | Không xác thực thành công; bộ đếm/khóa lại chưa chốt; Q3 |

Các ví dụ đúng/sai chỉ mô tả chuỗi đại diện; chưa có steps chi tiết, tài khoản đã tạo hoặc thực thi.

##### 9. Token phía client — A-S06

Tách token trước thao tác khỏi output của request. Token ở đây là dữ liệu do hệ thống tạo, không phải ô nhập login.

| EC ID | Nhóm và loại | Ví dụ | Expected và nguồn |
|---|---|---|---|
| A-EC-T01 | H về điều kiện nền — chưa có token | Client mới, sau đó login đúng | Nhận và lưu token, request cần xác thực gửi đúng Bearer header; A-R02/R08/R09 |
| A-EC-T02 | H về state — đã có token hợp lệ từ thành công trước | Có token T từ lần đúng, tiếp theo nhập sai | Request sai không cấp token thành công mới; không coi token T còn ở client là bằng chứng request sai thành công; A-R03, Q9 về chính sách giữ/xóa |
| A-EC-T03 | C — giá trị token cũ không rõ hiệu lực hoặc sai dạng | Client chứa chuỗi `not-a-jwt` | Không được suy ra login mới thành công từ giá trị này; với login đúng vẫn kiểm tra output và token được lưu/gửi. TTL, xử lý token cũ không được FR-02 mô tả đầy đủ; Q9 |

T03 chưa là bộ kiểm thử API authorization hoặc JWT security. Expected “server phải chặn mọi token giả” thuộc phạm vi yêu cầu bảo mật khác nếu mở rộng sau; không dùng để thay cho kiểm tra A-R09 về gửi header.

##### 10. Lớp đầu ra mong đợi — A-O01 đến A-O07

Đầu ra được chia riêng theo kênh. Một lần thao tác có thể liên quan một lớp kết quả xác thực và một lớp state/token. Đây là các loại output phải quan sát, không phải kết quả thực tế đã thấy.

| EC ID | Lớp output | Ví dụ tình huống dẫn tới output | Expected và nguồn |
|---|---|---|---|
| A-EC-O01 | H — xác thực thành công | E01/P01/L01 | HTTP 200, JWT token và user; client lưu token và gửi header ở request cần xác thực; A-O01/O02/O06, A-R02/R08/R09 |
| A-EC-O02 | K — từ chối thông tin xác thực, chưa khóa | E01/P02/N01 | Không có token thành công mới; thông báo lỗi phù hợp; n tăng 1; A-O01/O03/O04, A-R03/R04/R07 |
| A-EC-O03 | K — từ chối và kích hoạt khóa | E01/P02/N03 | n thành 3, kích hoạt khóa 30s, báo lỗi; A-O03/O04/O05, A-R04/R05/R06/R07 |
| A-EC-O04 | K — từ chối do đang khóa | E01/P01/L02 | Không đăng nhập thành công, có lỗi phù hợp; chưa chốt counter/gia hạn; A-O01/O03/O05, A-R06/R07 |
| A-EC-O05 | K ở form — lỗi validation HTML5 | E03/P01/G02 | Email type=email, browser báo không hợp lệ và không submit request login; A-O07, A-R10 |
| A-EC-O06 | K xác thực — không tìm thấy tài khoản | E02 qua API | Không có token thành công; báo lỗi phù hợp; không đặt bộ đếm cho tài khoản không tồn tại; A-O01/O03, A-R03/R07, Q1 |

Với lỗi, không tự điền HTTP 401/403, bắt buộc câu chữ giống nhau hoặc phân biệt chi tiết email/password; xem Q6/Q8. Các payload ngoài contract và câu hỏi C chưa có toàn bộ output xác định, nên không gộp vào lớp O như thể đã biết chắc cách xử lý.

##### 11. Đối chiếu và cách sử dụng ở bước tiếp theo

| Yêu cầu | Lớp liên quan chính |
|---|---|
| A-R01 | E01–E07, P01–P06, G01/G03 |
| A-R02 | E01, P01, L01/L03/L04, O01 |
| A-R03 | E02, P02, O02/O06; các lớp C cần giữ giới hạn |
| A-R04 | N01/N02/N03, H01, O02/O03 |
| A-R05 | N01–N04, H01, O03 |
| A-R06 | L01–L04, N04/N05, H04/H05, O03/O04 |
| A-R07 | O02/O03/O04/O06; Q6 vẫn chưa rõ |
| A-R08/A-R09 | T01/T02/T03, O01 |
| A-R10 | E03, G02, O05 |
| A-R11 | H02 |

Trong bảng này, E01 là viết tắt của A-EC-E01, tương tự các nhóm khác.

1. Chọn đại diện cho từng lớp có expected đã xác định; nhóm C được đánh dấu cần làm rõ/thăm dò riêng.
2. Ca hợp lệ có thể phủ nhiều lớp. Ca âm cơ bản chỉ vi phạm một điều kiện; những chuỗi kiểm tra khóa là tương tác có chủ đích và cần ghi rõ.
3. Không lấy tích mọi lớp: `n=0, chưa từng khóa` không đi cùng `elapsed=10s sau khóa`; token cũ không có nghĩa request hiện tại thành công.
4. Các lớp cùng dữ liệu nhưng khác state cần ca riêng khi expected thay đổi. Lớp output/state có thể được phủ chung trong cùng ca, không cộng số EC thành số test case.
5. Bước 5.3 sẽ tạo `03-domain-cases.md` có ID ca, setup/reset, dữ liệu, từng thao tác và expected; BVA làm riêng ở bước 5.4. Chưa có ca đã chạy hoặc điểm tự chấm trong tài liệu này.

#### 03-domain-cases — A-FR02

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.


Nguồn: 01-requirements.md, 02-domains.md, SRS FR-02 và API specification mục 1.2 được dẫn trong requirements. Baseline SUT: `85af3ba875c88283615e22cb108f13e2fccaf0e9`. Cách chọn ca theo slide VN trang 15/EN trang 31: phủ các lớp hợp lệ bằng ca kết hợp; mỗi ca âm cơ bản chỉ sai một điều kiện.

##### 1. Quy ước và cách chuẩn bị dùng chung

Các thủ tục dưới đây là một phần của từng ca có viện dẫn chúng. **Chưa thực hiện các lệnh trong tài liệu ở lượt thiết kế này.**

- `U = test@eshop.com`, `P = Test1234!`, `V = absent-a-fr02@example.com`. Nếu tài khoản nền không tồn tại hoặc đã bị thay đổi, dừng để chuẩn bị fixture rồi ghi giá trị thực tế; không đoán mật khẩu.
- EC viết tắt `E01` nghĩa là `A-EC-E01`; requirement `R01` nghĩa là `A-R01`. Mỗi ca bên dưới ghi đầy đủ ID trong mục truy vết.
- **P0 — chuẩn bị độc lập:** Backend/Web đang chạy; xác nhận U tồn tại, mật khẩu test là P, counter n=0 và chưa khóa bằng D. Nếu state không đạt, chưa chạy ca; nhờ chuẩn bị tài khoản riêng hoặc fixture reset có khai báo. Reload Web/đăng xuất chỉ xóa state client, không reset counter server. Không restart backend để reset giữa ca vì sẽ seed lại toàn bộ DB.
- **W — mở Web:** dùng trình duyệt có DevTools (nếu trình duyệt tích hợp không đủ chức năng, mở cùng URL trong Chrome/Firefox và ghi phiên bản). Mở `http://localhost:5173/login`. Đăng xuất nếu cần để bắt đầu client sạch, rồi mở lại /login; kiểm tra token cũ đã hết. Mở F12 → Network, bật Preserve log và xóa log cũ; không bật lại nút submit nhiều lần. Ô email có thể ghi “Username”, nút login “Sign In” theo code hiện tại; nhận diện control không đổi expected theo lỗi UI.
- **D — đọc state bổ trợ:** mở terminal riêng tại thư mục gốc, chạy đoạn Python chỉ đọc dưới đây trước/sau thao tác cần theo dõi. Ghi kết quả và thời điểm. Không import database.js vì sẽ seed DB. Counter/locked_until là điểm quan sát trong bản SUT, không phải yêu cầu tên trường của nghiệp vụ.

```bash
cd /home/zinn/zinn/test/hw02
python3 - <<'READ_STATE'
import sqlite3
from datetime import datetime, timezone
con = sqlite3.connect('file:eshop-sut/backend/database.sqlite?mode=ro', uri=True)
print(datetime.now(timezone.utc).isoformat())
for email in ('test@eshop.com', 'absent-a-fr02@example.com'):
    rows = con.execute('SELECT id, email, login_attempts, locked_until FROM users WHERE email = ?', (email,)).fetchall()
    print(email, rows)
con.close()
READ_STATE
```

- **A — gửi API:** dùng terminal khác để tránh tắt server. Mỗi ca API thay chuỗi JSON của `--data-raw` bên dưới bằng **đúng body ghi ở ca**, gửi một lần; ghi thời điểm, status và body. Không gửi thêm request hợp lệ chỉ để “thử kết nối” vì có thể reset counter. Không có thao tác click ở ca API; lệnh gửi request là thao tác thực hiện.

```bash
curl -i -sS --max-time 10   -X POST http://localhost:3000/api/login   -H 'Content-Type: application/json'   --data-raw '{"email":"test@eshop.com","password":"Test1234!"}'
```

- **K — chuẩn bị khóa độc lập:** bắt đầu P0; thực hiện ba lần sai tuần tự theo 011, ghi response và D sau từng lần. `t0` là mốc kích hoạt khóa quan sát được, không phải lúc bắt đầu lần sai thứ nhất. Không suy ra t0 từ `locked_until−30s` vì thời lượng triển khai có thể sai. Nếu không xác định được khóa/state đúng do lỗi trước, ghi phần phụ thuộc chưa đủ điều kiện; có thể thiết kế fixture riêng sau nhưng không lặng lẽ sửa DB để tuyên bố luồng người dùng đúng.
- Với kiểm tra ở 10/40 giây, đo thời gian thực tế; nếu không đủ chính xác để xác định nằm trong/ngoài cửa sổ thì chưa chấm checkpoint thời gian. Không dùng một chuỗi khóa cho nhiều ca độc lập. Ca đúng mốc 30 giây dành cho BVA có cách đo rõ ràng.
- Khi chạy về sau, lưu ảnh/log dưới `evidence/A-FR02/<TC-ID>/<Run-ID>/`, ghi vào execution. Với ca C/thăm dò, chỉ chấm checkpoint có expected đã biết; phần chưa rõ giữ “chưa chốt”, không biến observed behavior thành expected. Không công khai token đầy đủ trong ảnh/issue.

##### 2. Danh sách ca và thao tác

###### A-DT-001 — Đăng nhập Web đúng; lưu và gửi token

- **Loại:** Web — dương
- **Điều kiện chuẩn bị:** P0 và W; tài khoản U có n=0, chưa khóa; client không có token.
- **Dữ liệu nhập:** Email U; password P.
- **Điều kiện sai duy nhất / mục đích tương tác:** Không có.
- **EC ID:** `A-EC-E01`, `A-EC-P01`, `A-EC-G01`, `A-EC-L01`, `A-EC-T01`, `A-EC-O01`.
- **Requirement:** `A-R01`, `A-R02`, `A-R08`, `A-R09`.

**Thao tác:**

1. Mở /login; nhập U vào ô email (có thể ghi Username), nhập P vào ô Mật khẩu.
2. Bấm Sign In một lần; trong Network mở POST /api/login → Response.
3. Ghi status, token và user của response. Mở Application/Storage → Local Storage của localhost:5173, quan sát token sau đăng nhập.
4. Trong Network mở request cần xác thực GET /api/users/me xuất hiện sau login → Request Headers; đối chiếu Bearer token với token vừa nhận. Nếu chưa xuất hiện, bấm link hồ sơ người dùng; không tự gắn header thủ công để chứng minh client gửi đúng.

**Expected result:** HTTP 200 và JWT token/user đúng tài khoản; client giữ token và request cần xác thực mang Authorization: Bearer <token vừa nhận>. Không buộc một URL chuyển trang cụ thể. Local Storage chỉ là điểm quan sát của bản code này, không phải quy định bắt buộc cách lưu.

**Điểm chưa chốt:** Không có câu hỏi chặn expected chính.

###### A-DT-002 — Một lần sai mật khẩu trên Web

- **Loại:** Web — âm cơ bản
- **Điều kiện chuẩn bị:** P0 và W; n=0, chưa khóa.
- **Dữ liệu nhập:** U; Wrong123!.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ mật khẩu không khớp.
- **EC ID:** `A-EC-E01`, `A-EC-P02`, `A-EC-G01`, `A-EC-N01`, `A-EC-O02`.
- **Requirement:** `A-R03`, `A-R04`, `A-R05`, `A-R07`.

**Thao tác:**

1. Nhập U và Wrong123! trên /login; bấm Sign In đúng một lần.
2. Mở request login trong Network; đọc status/response, chụp thông báo trên form.
3. Dùng D đọc counter/locked_until sau request; không gửi lần login khác để thăm dò.

**Expected result:** Từ chối, không cấp token thành công mới, có lỗi phù hợp ở UI/API. Counter từ 0 thành 1 và chưa khóa. Không chốt status lỗi/câu chữ; ghi từng checkpoint riêng.

**Điểm chưa chốt:** Q6/Q8: chỉ đánh giá ý nghĩa lỗi, không buộc câu chữ/status cụ thể.

###### A-DT-003 — Email đúng format nhưng chưa đăng ký trên Web

- **Loại:** Web — âm cơ bản
- **Điều kiện chuẩn bị:** P0/W; D xác nhận V không tồn tại.
- **Dữ liệu nhập:** V; P.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ email không trỏ tới tài khoản tồn tại; password giữ nguyên P của nền.
- **EC ID:** `A-EC-E02`, `A-EC-G01`, `A-EC-O06`.
- **Requirement:** `A-R01`, `A-R03`, `A-R07`.

**Thao tác:**

1. Nhập V và P; bấm Sign In một lần.
2. Đọc response login, thông báo UI và quan sát có token thành công mới hay không.

**Expected result:** Từ chối xác thực, báo lỗi phù hợp, không cấp token thành công mới. Không đặt expected bộ đếm cho tài khoản không tồn tại.

**Điểm chưa chốt:** P được giữ nguyên từ dữ liệu nền, không khẳng định có mật khẩu đúng cho V. Q1/Q6/Q8 còn mở.

###### A-DT-004 — Email sai format bị HTML5 chặn

- **Loại:** Web — âm cơ bản
- **Điều kiện chuẩn bị:** P0/W; password P.
- **Dữ liệu nhập:** not-an-email; P.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ format email.
- **EC ID:** `A-EC-E03`, `A-EC-P01`, `A-EC-G02`, `A-EC-O05`.
- **Requirement:** `A-R10`.

**Thao tác:**

1. Nhấp phải ô email → Inspect; ghi thuộc tính type đang có, không sửa DOM.
2. Nhập not-an-email và P; xóa danh sách Network cũ rồi bấm Sign In một lần.
3. Quan sát validation trình duyệt và kiểm tra có request POST /api/login mới hay không.

**Expected result:** Input có type=email; browser báo format không hợp lệ và không gửi request login. Nếu request vẫn gửi, ghi checkpoint sai format thất bại; không coi phản hồi API từ chối là thay thế validation HTML5.

**Điểm chưa chốt:** Không có câu hỏi chặn expected chính.

###### A-DT-005 — Login đúng qua API

- **Loại:** API — dương
- **Điều kiện chuẩn bị:** P0; U n=0, chưa khóa.
- **Dữ liệu nhập:** {"email":"test@eshop.com","password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Không có.
- **EC ID:** `A-EC-E01`, `A-EC-P01`, `A-EC-G03`, `A-EC-L01`.
- **Requirement:** `A-R01`, `A-R02`.

**Thao tác:**

1. Theo A, gửi đúng body đã cho một lần.
2. Ghi HTTP status và response token/user.

**Expected result:** HTTP 200, JWT token và user của U. Ca API này không chứng minh client Web lưu/gửi token; phần đó thuộc 001.

**Điểm chưa chốt:** Không có câu hỏi chặn expected chính.

###### A-DT-006 — Email không tồn tại qua API

- **Loại:** API — âm cơ bản
- **Điều kiện chuẩn bị:** P0; D xác nhận V không tồn tại.
- **Dữ liệu nhập:** {"email":"absent-a-fr02@example.com","password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ email không tồn tại.
- **EC ID:** `A-EC-E02`, `A-EC-G03`, `A-EC-O06`.
- **Requirement:** `A-R01`, `A-R03`, `A-R07`.

**Thao tác:**

1. Theo A, gửi body một lần.
2. Đọc status, lỗi và kiểm tra không có token thành công mới.

**Expected result:** Từ chối xác thực và lỗi phù hợp; không chốt counter cho V.

**Điểm chưa chốt:** Q1/Q6/Q8; không gán lớp password khớp tài khoản không tồn tại.

###### A-DT-007 — Thiếu key email

- **Loại:** API — âm cơ bản, oracle chi tiết chưa chốt
- **Điều kiện chuẩn bị:** P0; U sẵn sàng, payload chỉ bỏ email.
- **Dữ liệu nhập:** {"password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ thiếu email.
- **EC ID:** `A-EC-E06`, `A-EC-G03`.
- **Requirement:** `A-R01`.

**Thao tác:**

1. Theo A, gửi body giữ nguyên password, không thêm key email.
2. Ghi response và việc có/không có token thành công.

**Expected result:** Theo mô hình A-R01, payload thiếu định danh không được xác thực thành công. Status/thông báo/counter chưa được contract quy định; không tự coi một status cụ thể là bắt buộc.

**Điểm chưa chốt:** Q2/Q8; giữ password nền P, chưa xác định tài khoản ở payload.

###### A-DT-008 — Email là số

- **Loại:** API — âm cơ bản, oracle chi tiết chưa chốt
- **Điều kiện chuẩn bị:** P0.
- **Dữ liệu nhập:** {"email":123,"password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ kiểu email.
- **EC ID:** `A-EC-E07`, `A-EC-G03`.
- **Requirement:** `A-R01`.

**Thao tác:**

1. Theo A, gửi số 123 không có dấu nháy, giữ password chuỗi P.
2. Ghi response; không lặp thêm biến thể kiểu khác trong cùng run.

**Expected result:** Email ngoài mô hình chuỗi nên dự kiến không xác thực thành công; chưa chốt xử lý ép kiểu/status/counter. Null/object/array cần run hoặc ca riêng nếu mở rộng.

**Điểm chưa chốt:** Q2/Q8; oracle từ mô hình đầu vào, không phải schema validation chi tiết đã được đặc tả.

###### A-DT-009 — Thiếu key password

- **Loại:** API — âm cơ bản, oracle chi tiết chưa chốt
- **Điều kiện chuẩn bị:** P0; U n=0.
- **Dữ liệu nhập:** {"email":"test@eshop.com"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ thiếu password.
- **EC ID:** `A-EC-E01`, `A-EC-P05`, `A-EC-G03`.
- **Requirement:** `A-R01`.

**Thao tác:**

1. Theo A, gửi body chỉ có email.
2. Ghi response, quan sát counter bằng D nếu cần nhưng chưa chấm hành vi counter.

**Expected result:** Không xác thực thành công khi thiếu mật khẩu theo A-R01. Không đặt status lỗi hay số counter cụ thể.

**Điểm chưa chốt:** Q2/Q8.

###### A-DT-010 — Password là null

- **Loại:** API — âm cơ bản, oracle chi tiết chưa chốt
- **Điều kiện chuẩn bị:** P0; U n=0.
- **Dữ liệu nhập:** {"email":"test@eshop.com","password":null}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ kiểu password.
- **EC ID:** `A-EC-E01`, `A-EC-P06`, `A-EC-G03`.
- **Requirement:** `A-R01`.

**Thao tác:**

1. Theo A, gửi null không đặt trong dấu nháy.
2. Ghi response và việc có token thành công hay không.

**Expected result:** Payload không có mật khẩu chuỗi phù hợp; dự kiến không xác thực thành công. Không chốt status/counter hoặc tự suy ra mọi kiểu sai được xử lý giống nhau.

**Điểm chưa chốt:** Q2/Q8.

###### A-DT-011 — Chuỗi ba lần sai và kích hoạt khóa

- **Loại:** Web + D — tương tác trạng thái có chủ đích
- **Điều kiện chuẩn bị:** P0/W; D xác nhận n=0, chưa khóa.
- **Dữ liệu nhập:** U; Wrong123! cho từng lần.
- **Điều kiện sai duy nhất / mục đích tương tác:** Mỗi request chỉ sai password; lặp ba lần là chủ đích kiểm tra state.
- **EC ID:** `A-EC-E01`, `A-EC-P02`, `A-EC-G01`, `A-EC-N01`, `A-EC-N02`, `A-EC-N03`, `A-EC-H01`, `A-EC-O02`, `A-EC-O03`.
- **Requirement:** `A-R03`, `A-R04`, `A-R05`, `A-R06`, `A-R07`.

**Thao tác:**

1. Nhập U/Wrong123!, bấm Sign In một lần; đợi response xong, đọc D và lưu mốc giờ.
2. Giữ dữ liệu, bấm lần thứ hai; đợi response xong, đọc D và lưu mốc giờ.
3. Giữ dữ liệu, bấm lần thứ ba; đọc response/D, ghi mốc kích hoạt khóa t0 và locked_until nếu có.
4. Nếu sai khác xảy ra từ bước đầu, ghi ngay bước đó; chỉ tiếp tục quan sát chuỗi nếu an toàn, không giả định đã đạt n=1/2 đúng để chấm lớp tiếp theo.

**Expected result:** Cả ba request bị từ chối vì password sai. Sau mỗi lần counter lần lượt 1,2,3; hai lần đầu chưa khóa; lần thứ ba kích hoạt khóa 30 giây, có thông báo lỗi phù hợp. Nếu lỗi trước ngăn đạt state, phần sau chưa được kiểm chứng độc lập.

**Điểm chưa chốt:** Q4: D chỉ hỗ trợ kiểm tra cấu hình thời hạn; thời lượng thực tế cần ca 012/013 và BVA. Không suy ra runtime đúng chỉ từ locked_until.

###### A-DT-012 — Mật khẩu đúng khi đang khóa

- **Loại:** Web + D — âm về trạng thái
- **Điều kiện chuẩn bị:** K độc lập: xác nhận tài khoản đang khóa; không có token cũ.
- **Dữ liệu nhập:** U/P; mục tiêu elapsed khoảng 10 giây.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ trạng thái khóa không cho phép; email/password đúng.
- **EC ID:** `A-EC-E01`, `A-EC-P01`, `A-EC-G01`, `A-EC-N04`, `A-EC-L02`, `A-EC-O04`.
- **Requirement:** `A-R02`, `A-R06`, `A-R07`.

**Thao tác:**

1. Chuẩn bị form U/P trước khi đến mốc; Network đã bật.
2. Tại khoảng t0+10s bấm Sign In một lần; lưu thời điểm và response.
3. Chụp lỗi; kiểm tra không có token thành công mới. Không dùng cùng chuỗi này cho ca hết khóa độc lập.

**Expected result:** Nếu request thực sự nằm trong khoảng khóa 0≤elapsed<30s, đăng nhập bị từ chối dù thông tin đúng. Không khẳng định counter tăng hoặc thời hạn được gia hạn.

**Điểm chưa chốt:** Q2/Q4/Q5; nếu không chứng minh được request đang trong cửa sổ khóa thì không chấm ca này.

###### A-DT-013 — Thông tin đúng sau thời gian khóa

- **Loại:** Web + D — dương sau chuyển trạng thái
- **Điều kiện chuẩn bị:** K độc lập; không có request login nào xen giữa kích hoạt khóa và phép đo.
- **Dữ liệu nhập:** U/P; elapsed mục tiêu 40 giây.
- **Điều kiện sai duy nhất / mục đích tương tác:** Không có lỗi đầu vào.
- **EC ID:** `A-EC-E01`, `A-EC-P01`, `A-EC-G01`, `A-EC-L04`.
- **Requirement:** `A-R02`, `A-R06`.

**Thao tác:**

1. Chuẩn bị form U/P và đồng hồ đo từ t0.
2. Chờ ít nhất 40 giây kể từ mốc khóa đã ghi, không bấm login thăm dò.
3. Bấm Sign In một lần; lưu thời điểm, response và trạng thái client.

**Expected result:** Ở thời điểm >30s, khóa 30s phải hết, thông tin đúng được xác thực thành công HTTP 200/token/user. Nếu vẫn bị chặn, ghi actual và kiểm tra tiền điều kiện trước khi báo lỗi. Không dùng ca này để tuyên bố đã đo chính xác 30s.

**Điểm chưa chốt:** Q4; phải biết t0 và không có tác động gia hạn xen giữa.

###### A-DT-014 — Thành công ngắt chuỗi sai

- **Loại:** Web + D — tương tác trạng thái
- **Điều kiện chuẩn bị:** P0/W; n=0, chưa khóa.
- **Dữ liệu nhập:** Chuỗi U/Wrong123! → U/P → U/Wrong123!.
- **Điều kiện sai duy nhất / mục đích tương tác:** Mỗi request âm chỉ sai password; request giữa hợp lệ.
- **EC ID:** `A-EC-E01`, `A-EC-P02`, `A-EC-P01`, `A-EC-G01`, `A-EC-H02`, `A-EC-N01`.
- **Requirement:** `A-R02`, `A-R03`, `A-R04`, `A-R05`, `A-R11`.

**Thao tác:**

1. Gửi một lần sai; đọc counter bằng D.
2. Sửa password thành P, bấm Sign In; xác nhận response thành công. Nếu bước này không thành công, dừng phần kiểm tra reset.
3. Bấm nút đăng xuất (có thể ghi Thoát), về /login.
4. Nhập U/Wrong123!, bấm một lần; đọc counter bằng D.

**Expected result:** Lần đầu sai được tính là 1; lần đúng thành công ngắt chuỗi; lần sai cuối là lần đầu của chuỗi mới, counter logic=1 và chưa khóa. Đây là diễn giải A-R11 từ “liên tiếp”, chưa phải human review đã duyệt.

**Điểm chưa chốt:** Không có câu hỏi chặn expected chính.

###### A-DT-015 — Email rỗng trên Web

- **Loại:** Web — thăm dò C
- **Điều kiện chuẩn bị:** P0/W.
- **Dữ liệu nhập:** Email rỗng; P.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ email rỗng.
- **EC ID:** `A-EC-E04`, `A-EC-P01`.
- **Requirement:** `A-R01`, `A-R03`.

**Thao tác:**

1. Xóa hết email, nhập P; bấm Sign In một lần.
2. Ghi browser có chặn không; nếu có request thì lưu response; ghi actual theo tầng.

**Expected result:** Không có định danh đúng để đăng nhập theo mô hình; không được xác thực thành công. Chưa chốt phải chặn required tại Web hay trả lỗi API, hoặc counter ra sao.

**Điểm chưa chốt:** Q2/Q7; phần UI required chưa có expected để chấm.

###### A-DT-016 — Password rỗng trên Web

- **Loại:** Web — thăm dò C
- **Điều kiện chuẩn bị:** P0/W.
- **Dữ liệu nhập:** U; password rỗng.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ password rỗng.
- **EC ID:** `A-EC-E01`, `A-EC-P03`.
- **Requirement:** `A-R01`, `A-R03`.

**Thao tác:**

1. Nhập U, xóa hết password, bấm Sign In một lần.
2. Ghi browser có chặn, có request login hay không; lưu phản hồi nếu có.

**Expected result:** Password rỗng không khớp P của tài khoản nền nên không đăng nhập thành công. Chưa chốt tầng validation/status/counter.

**Điểm chưa chốt:** Q2/Q7.

###### A-DT-017 — Password chỉ có khoảng trắng

- **Loại:** Web — thăm dò C
- **Điều kiện chuẩn bị:** P0/W.
- **Dữ liệu nhập:** U; ba dấu cách ASCII.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ password không hợp lệ.
- **EC ID:** `A-EC-E01`, `A-EC-P04`.
- **Requirement:** `A-R01`, `A-R03`.

**Thao tác:**

1. Nhập U và đúng ba dấu cách vào password; bấm Sign In một lần.
2. Đọc request payload để xác nhận số dấu cách nếu request được gửi, đọc response và ghi counter bổ trợ.

**Expected result:** Không khớp P nên không đăng nhập thành công. Chưa chốt được tính là sai thông thường hay thiếu password, không chấm counter theo suy đoán.

**Điểm chưa chốt:** Q2/Q7.

###### A-DT-018 — Email khác hoa/thường

- **Loại:** API — thăm dò C, tách một yếu tố
- **Điều kiện chuẩn bị:** P0; chỉ tài khoản chính xác U tồn tại, không tạo bản chữ hoa.
- **Dữ liệu nhập:** {"email":"TEST@ESHOP.COM","password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ thay hoa/thường của email; không thêm khoảng trắng.
- **EC ID:** `A-EC-E05`, `A-EC-G03`.
- **Requirement:** `A-R01`, `A-R02`.

**Thao tác:**

1. Theo A, gửi body một lần.
2. Ghi response và tài khoản nếu thành công; không tự kết luận thành công hoặc bị từ chối là bug.

**Expected result:** Chưa chốt email có phân biệt hoa/thường. Thu thập hành vi để làm rõ Q7, chưa có verdict cho chính sách chuẩn hóa.

**Điểm chưa chốt:** Q7; chưa chốt expected chính.

###### A-DT-019 — Email có khoảng trắng đầu/cuối

- **Loại:** API — thăm dò C, tách một yếu tố
- **Điều kiện chuẩn bị:** P0.
- **Dữ liệu nhập:** {"email":" test@eshop.com ","password":"Test1234!"}
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ thêm khoảng trắng; không đổi hoa/thường.
- **EC ID:** `A-EC-E05`, `A-EC-G03`.
- **Requirement:** `A-R01`, `A-R02`.

**Thao tác:**

1. Theo A, gửi body giữ nguyên khoảng trắng.
2. Ghi response và định danh user nếu thành công.

**Expected result:** Chưa chốt trim email; cả chấp nhận sau trim hoặc từ chối đều cần đối chiếu quy tắc bổ sung trước verdict.

**Điểm chưa chốt:** Q7; tách khỏi 018 để không thay hai yếu tố cùng lúc.

###### A-DT-020 — Validation email xen giữa hai lần sai

- **Loại:** Web + D — thăm dò chuỗi C
- **Điều kiện chuẩn bị:** P0/W; n=0.
- **Dữ liệu nhập:** U/Wrong123! → not-an-email/P → U/Wrong123!.
- **Điều kiện sai duy nhất / mục đích tương tác:** Hai request xác thực chỉ sai password; thao tác giữa chỉ sai format email.
- **EC ID:** `A-EC-E03`, `A-EC-G02`, `A-EC-H03`, `A-EC-P02`.
- **Requirement:** `A-R03`, `A-R04`, `A-R10`.

**Thao tác:**

1. Gửi U/Wrong123! một lần, ghi counter.
2. Đổi email thành not-an-email và password P; bấm Sign In; xác nhận browser chặn và không có request.
3. Nếu bước giữa thực sự bị chặn, đổi về U/Wrong123!, gửi một lần và ghi response/counter.
4. Nếu bước giữa vẫn gửi request, ghi lỗi validation và dừng kết luận cho chuỗi yêu cầu “bị browser chặn”.

**Expected result:** Bước giữa phải bị HTML5 chặn theo A-R10. Với hai request password sai, xác thực phải từ chối; chính sách bộ đếm toàn chuỗi khi xen thao tác bị chặn còn Q2, chưa gán số cuối chắc chắn.

**Điểm chưa chốt:** Q2; đây là chuỗi có chủ đích, không là ca âm cơ bản.

###### A-DT-021 — Thử lại sau một request trong lúc khóa

- **Loại:** Web + D — thăm dò chuỗi C
- **Điều kiện chuẩn bị:** K độc lập, mốc t0 được lưu.
- **Dữ liệu nhập:** U/P tại khoảng 10s và khoảng 40s.
- **Điều kiện sai duy nhất / mục đích tương tác:** Trạng thái khóa là yếu tố xét; thông tin đều đúng.
- **EC ID:** `A-EC-N04`, `A-EC-L02`, `A-EC-H04`.
- **Requirement:** `A-R06`, `A-R07`.

**Thao tác:**

1. Chuẩn bị form U/P; bấm tại t0+10s, ghi response và state D.
2. Giữ chuỗi, đến t0+40s bấm U/P lần nữa; ghi response và thời hạn đang lưu.

**Expected result:** Request tại 10s phải bị chặn. Kết quả request 40s chưa chốt vì chưa biết lần thử trong khóa có gia hạn hay không. Không dùng ca này thay cho 013.

**Điểm chưa chốt:** Q2/Q4/Q5; chỉ checkpoint đầu có expected xác định nếu đo đúng cửa sổ.

###### A-DT-022 — Sai mật khẩu sau khi khóa cũ hết

- **Loại:** Web + D — thăm dò C
- **Điều kiện chuẩn bị:** K độc lập; không request xen giữa.
- **Dữ liệu nhập:** U/Wrong123! tại khoảng t0+40s.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ password sai tại lúc đáng lẽ khóa cũ đã hết.
- **EC ID:** `A-EC-N05`, `A-EC-H05`, `A-EC-P02`.
- **Requirement:** `A-R03`, `A-R06`.

**Thao tác:**

1. Chờ 40s từ t0, không thăm dò login.
2. Nhập U/Wrong123!, bấm Sign In một lần.
3. Lưu response; đọc counter/locked_until để mô tả trạng thái sau đó.

**Expected result:** Không đăng nhập thành công vì password sai. Counter reset/giữ, có kích hoạt khóa mới hay không chưa chốt. Nếu runtime khóa cũ chưa hết vì lỗi thời lượng, ghi tiền điều kiện chưa đạt thay vì khẳng định đã phủ N05.

**Điểm chưa chốt:** Q3/Q4; không có expected chắc chắn cho counter sau hết khóa.

###### A-DT-023 — Token cũ không chứng minh lần login sai thành công

- **Loại:** Web — âm với token nền hợp lệ
- **Điều kiện chuẩn bị:** Login đúng như 001 để có token T; dùng đúng tài khoản đã xác thực; không đăng xuất.
- **Dữ liệu nhập:** Token T hợp lệ đang lưu; U/Wrong123!.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ password mới sai; token cũ hợp lệ.
- **EC ID:** `A-EC-E01`, `A-EC-P02`, `A-EC-T02`, `A-EC-G01`.
- **Requirement:** `A-R03`, `A-R07`.

**Thao tác:**

1. Ghi token T cục bộ để so sánh, không đưa token đầy đủ vào ảnh công khai.
2. Mở /login trực tiếp mà không đăng xuất, xác nhận T vẫn tồn tại; nếu app không cho vào form, ghi chưa thể thực hiện đường UI này.
3. Nhập U/Wrong123!, bấm Sign In; chỉ đọc response POST login mới và token trước/sau.

**Expected result:** Request sai bị từ chối, không cấp token thành công mới. Có thể token T vẫn còn: không coi đó là login sai được chấp nhận. Chính sách giữ/xóa T chưa được yêu cầu quy định.

**Điểm chưa chốt:** Q9; không bắt buộc xóa phiên cũ.

###### A-DT-024 — Login đúng khi client có token sai dạng

- **Loại:** Web — thăm dò C có fixture client
- **Điều kiện chuẩn bị:** P0/W; mở DevTools tại /login. Tạo fixture chỉ trên client, không sửa mã nguồn.
- **Dữ liệu nhập:** Token cũ not-a-jwt; U/P.
- **Điều kiện sai duy nhất / mục đích tương tác:** Chỉ state token cũ sai dạng; thông tin login đúng.
- **EC ID:** `A-EC-E01`, `A-EC-P01`, `A-EC-T03`.
- **Requirement:** `A-R02`, `A-R08`, `A-R09`.

**Thao tác:**

1. Trong Application/Storage → Local Storage localhost:5173, đặt key token thành not-a-jwt; ghi đây là fixture.
2. Không reload; nhập U/P và bấm Sign In. Kiểm tra token sai thực sự còn tại lúc gửi; nếu app đã xóa nó, ghi tiền điều kiện khác.
3. Đọc response login; kiểm tra token mới được lưu và header của request cần xác thực như 001.
4. Sau khi thu bằng chứng, đăng xuất/xóa fixture token; không dùng state này cho ca tiếp theo.

**Expected result:** Theo A-R02, thông tin đúng và không khóa phải được xét thành công; token mới được lưu/gửi đúng. Chính sách tự xóa/giữ token sai trước login còn Q9; không chấm toàn bộ JWT security hoặc ép app phải giữ token sai.

**Điểm chưa chốt:** Q9; fixture Local Storage dựa vào code để thao tác, không phải nơi lưu bắt buộc của SRS.

##### 3. Truy vết lớp tương đương và giới hạn độ phủ

Bảng này là độ phủ **thiết kế dự kiến**, không phải độ phủ thực thi. EC thuộc ca thăm dò chưa có oracle hoàn chỉnh vẫn phải ghi hạn chế; không tuyên bố đã phủ xác định 100%.

| EC ID | Ca liên quan | Lưu ý |
|---|---|---|
| A-EC-E01 | A-DT-001, A-DT-002, A-DT-005, A-DT-009, A-DT-010, A-DT-011, A-DT-012, A-DT-013, A-DT-014, A-DT-016, A-DT-017, A-DT-023, A-DT-024 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E02 | A-DT-003, A-DT-006 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E03 | A-DT-004, A-DT-020 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E04 | A-DT-015 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E05 | A-DT-018, A-DT-019 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E06 | A-DT-007 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-E07 | A-DT-008 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P01 | A-DT-001, A-DT-004, A-DT-005, A-DT-012, A-DT-013, A-DT-014, A-DT-015, A-DT-024 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P02 | A-DT-002, A-DT-011, A-DT-014, A-DT-020, A-DT-022, A-DT-023 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P03 | A-DT-016 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P04 | A-DT-017 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P05 | A-DT-009 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-P06 | A-DT-010 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-G01 | A-DT-001, A-DT-002, A-DT-003, A-DT-011, A-DT-012, A-DT-013, A-DT-014, A-DT-023 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-G02 | A-DT-004, A-DT-020 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-G03 | A-DT-005, A-DT-006, A-DT-007, A-DT-008, A-DT-009, A-DT-010, A-DT-018, A-DT-019 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-N01 | A-DT-002, A-DT-011, A-DT-014 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-N02 | A-DT-011 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-N03 | A-DT-011 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-N04 | A-DT-012, A-DT-021 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-N05 | A-DT-022 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-L01 | A-DT-001, A-DT-005 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-L02 | A-DT-012, A-DT-021 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-L03 | Chưa có — dành cho BVA | Chuyển sang 04-boundary-cases.md: cần phép đo tại đúng 30s; chưa có ca Domain kiểm chứng lớp này. |
| A-EC-L04 | A-DT-013 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-H01 | A-DT-011 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-H02 | A-DT-014 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-H03 | A-DT-020 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-H04 | A-DT-021 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-H05 | A-DT-022 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-T01 | A-DT-001 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-T02 | A-DT-023 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-T03 | A-DT-024 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O01 | A-DT-001 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O02 | A-DT-002, A-DT-011 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O03 | A-DT-011 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O04 | A-DT-012 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O05 | A-DT-004 | Theo expected và giới hạn ở từng ca; chưa chạy. |
| A-EC-O06 | A-DT-003, A-DT-006 | Theo expected và giới hạn ở từng ca; chưa chạy. |

###### Cách tránh đếm sai hoặc tạo kết luận vượt bằng chứng

- Có 24 TC ID trong file này, gồm ca chính và ca thăm dò/chỉ có expected một phần. Chưa có ca nào được thực thi hoặc human review. Số thiết kế này chưa tự động trở thành số liệu đã duyệt trong README.
- N02/N03 có checkpoint trong chuỗi 011. Nếu lỗi sớm làm state lệch, checkpoint phía sau không chứng minh đã kiểm tra độc lập đúng lớp N02/N03; cần ca/fixture bổ trợ khi review. Không sửa SUT để che lỗi.
- E05 được xét bằng hai biến thể 018/019: thay hoa/thường và khoảng trắng riêng, tránh thay hai yếu tố cùng lúc. E07/P06 dùng một đại diện mỗi nhóm, không khẳng định mọi kiểu sai tương đương khi chưa kiểm tra rủi ro ép kiểu.
- Ca 003/006 dùng V không tồn tại: không thể gọi password là “đúng cho V”. Giá trị P được giữ cố định để chỉ thay yếu tố định danh. Kết quả lớp E02 là trọng tâm.
- G01 ở ca âm là đường gửi Web khi browser cho submit, không khẳng định cả lần xác thực hợp lệ. O01 được kiểm tra đầy đủ ở ca 001 (UI + token/header); ca API 005 chỉ chứng minh phần response.
- L03 được hoãn công khai sang BVA, không thao tác bằng tay rồi tuyên bố chính xác đúng 30 giây. Q1–Q9 vẫn giữ trạng thái chưa được làm rõ như requirements; không tự gán status lỗi, câu thông báo, cơ chế chuẩn hóa hoặc TTL.
- Với A-R07, lưu thông báo UI/API; ghi bằng chứng nếu lộ chi tiết nhạy cảm nhưng không tự kết luận mọi khác biệt câu chữ là bug. Review sẽ chốt oracle chi tiết nếu cần.

##### 4. Bước tiếp theo

Tạo `04-boundary-cases.md` cho số lần sai và thời gian khóa, rồi review cả bộ thiết kế trước khi thực thi. Khi review, ưu tiên kiểm tra fixture/reset, tính độc lập của ca, oracle còn thiếu và cách thu bằng chứng token/thời gian. Không điền sẵn actual hoặc Pass/Fail vào bộ thiết kế.

#### 04-boundary-cases — A-FR02

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.


##### 1. Nguồn và cách chọn biên

- Requirements: A-R02–A-R07, A-R11; đặc biệt Q2–Q5 về bộ đếm, hết khóa và phép đo.
- Các lớp tương đương: N01–N05, L01–L04, H01/H02; L03 đúng 30s được thiết kế ở đây.
- Ca Domain: thủ tục P0/W/D/A/K để chuẩn bị, thao tác Web/API và quan sát state.
- [Slide VN](../slide/domain-testing-vn.pdf), trang 19–26: xét miền có thứ tự, các giá trị sát biên trong/ngoài miền; [slide EN](../slide/domain-testing-en.pdf), trang 34–37: lỗi điều kiện biên và lựa chọn điểm.
- SRS FR-02 tại baseline `85af3ba875c88283615e22cb108f13e2fccaf0e9`: sai liên tiếp từ 3 lần thì khóa 30 giây. Code chỉ giúp tìm điểm quan sát, không thay expected 3 lần/30 giây bằng hành vi triển khai.

| Biến | Định nghĩa | Biên và điểm chọn | Lý do |
|---|---|---|---|
| k | Số request nhập sai password đã gửi trong một chuỗi mới, không có đăng nhập thành công xen giữa | Ngưỡng 3; chọn 2, 3, 4. Thêm 0, 1 | Phân biệt trước/đến/sau ngưỡng và lỗi tăng counter ngay lần đầu |
| n | Counter phía hệ thống, đọc trước/sau request | Kỳ vọng n=k trước/khi kích hoạt khóa | Không đồng nhất k với n nếu ứng dụng tăng sai; không tự bắt n=4 cho request bị khóa |
| elapsed | Thời gian server xét request kể từ lúc kích hoạt khóa t0 | 29s, 30s, 31s; thêm 10s, 40s | Kiểm tra trong khoảng, đúng lúc hết và ngoài khoảng khóa |
| elapsed ở đồng hồ kiểm soát | Thời gian giả lập ở điểm kiểm tra khóa trong bản chạy tách biệt | 29.999s, 30.000s, 30.001s nếu harness thực sự hỗ trợ tick 1ms | Phân biệt toán tử so sánh sát mốc; không gán độ chính xác ms cho bấm tay |

**Điểm quan trọng về lần thứ 4:** lần nhập sai thứ 4 được gửi ngay khi tài khoản đang khóa. Expected là không được đăng nhập; chưa biết counter có tăng/gia hạn hay không (Q2/Q5). Không gọi đây là trạng thái “đã xác thực sai 4 lần nhưng chưa khóa”.

Không áp máy móc công thức Standard 4n+1 hoặc Robust 6n+1: bộ đếm và thời gian là biến trạng thái phụ thuộc nhau, không phải hai khoảng số độc lập có đủ LB/UB. Chọn quanh từng ngưỡng, giữ thông tin đăng nhập và tiền điều kiện còn lại cố định. Không tạo giới hạn password/email tùy ý để có thêm BVA.

##### 2. Chuẩn bị riêng cho mỗi ca

1. Backend/Web đã chạy; ghi baseline, môi trường và Run ID. Lưu ảnh/log trong `evidence/A-FR02/<TC-ID>/<Run-ID>/` khi thực thi sau này.
2. Mỗi ca dùng một tài khoản test riêng hoặc một lần reset fixture riêng được ghi nhận. Tài khoản có email tồn tại, password đúng P=`Test1234!`, n=0, không khóa. Email ví dụ `bva001-run001@example.com` là dữ liệu **dự kiến**, chưa tạo. Nếu dùng U=`test@eshop.com`, phải chứng minh state sạch trước mỗi ca; không dựa vào reload/đăng xuất để reset server.
3. Dùng thủ tục D chỉ đọc của 03-domain-cases.md để xem state; thay email truy vấn bằng tài khoản của ca. Đọc sau khi DB update đã hoàn tất; nếu response đã về nhưng state chưa ổn định, ghi thời điểm quan sát và chờ state hoàn tất, không tự tăng counter bằng tay.
4. Tài khoản mới/reset do setup riêng chuẩn bị, không qua việc sửa logic login. Nếu cần SQL fixture, phải có before/after, phạm vi tài khoản cụ thể và cách khôi phục được review trước. Tài liệu này không tự thực hiện SQL ghi.
5. Với ca thời gian, kích hoạt khóa bằng chuỗi sai tự nhiên, ghi mỗi request và state. Không gọi API login thăm dò trong lúc chờ: request đó có thể tác động thời hạn khóa chưa rõ ở Q5.
6. Không dùng chung một lần khóa để thử lần lượt 29/30/31s. Mỗi điểm có tài khoản/chuỗi khóa độc lập. Một lần login đúng có thể reset state, làm phép thử sau mất ý nghĩa.
7. Nếu ứng dụng khóa sớm hoặc counter tăng sai khi setup, ghi lỗi tại bước có bằng chứng; không giả vờ đã đạt tiền điều kiện đúng. Có thể đo thời lượng từ mốc khóa **thực tế** như kiểm tra chẩn đoán riêng, nêu rõ khác luồng chuẩn. Phần kiểm tra phụ thuộc ngưỡng đúng vẫn chưa được chứng minh.
8. Không restart backend giữa ca: import database.js seed lại DB. Cleanup chỉ sau khi đã giữ bằng chứng, không reset dữ liệu chung chưa được sao lưu.

Mật khẩu sai dùng W=`Wrong123!`. Khi kiểm tra số lần sai, chỉ password sai. Khi kiểm tra thời gian, email/password đều đúng; chỉ thay thời điểm. Chuỗi sai dùng để setup khóa không phải ca âm đa điều kiện.

##### 3. Đo thời gian trung thực

###### 3.1 Chạy baseline thật: đo khoảng, không giả độ chính xác

Dùng script/harness tuần tự (sẽ tạo ở bước hỗ trợ thực thi), đồng hồ monotonic để đo elapsed; đồng thời ghi UTC cho nhật ký. Ghi t_send và t_receive cho request kích hoạt khóa, request thử login. Không dùng giờ trên thanh desktop, thời gian sleep yêu cầu hoặc HTTP Date làm bằng chứng server xử lý đúng mốc.

Nếu cùng client đo được:

- Request kích hoạt khóa được gửi tại `a`, response về tại `b`.
- Request thử đăng nhập được gửi tại `c`, response về tại `d`.
- Nếu mốc kích hoạt và điểm kiểm tra thực sự nằm trong hai khoảng xử lý tương ứng, elapsed server nằm trong khoảng bảo thủ **[c−b, d−a]**.

Dùng đơn vị giây và cùng nguồn monotonic cho a,b,c,d. Điều kiện của phép chặn khoảng phải được xác nhận: response được nhận sau mốc đang xét, không retry ngầm, không có request cạnh tranh; chưa xác nhận thì không dùng công thức như chứng cứ chắc chắn.

| Khoảng đo thu được | Có thể kết luận về miền? |
|---|---|
| Cận dưới ≥0 và cận trên <30s | Có thể xác định request được xét trong khoảng khóa |
| Cận dưới >30s | Có thể xác định request được xét sau 30s |
| Khoảng chứa/cắt mốc 30s | Chưa phân biệt trước/đúng/sau; không chấm Pass/Fail cho checkpoint đúng biên |

Ví dụ **minh họa, không phải kết quả đo**: khoảng [28.98,29.06]s hỗ trợ “trước 30s”; khoảng [30.96,31.08]s hỗ trợ “sau 30s”; khoảng [29.97,30.05]s không chứng minh đúng 30s. Sai số thực tế phải tính từ log, không mặc định ±0.01s hoặc ±1ms.

Lập lịch gửi gần mục tiêu 29/31s bằng monotonic; sau response tính khoảng thực tế rồi gắn nhãn đúng mức. Nếu lệch, ghi “mục tiêu 29s, miền quan sát trước 30s”, không nói đã đo chính xác 29.000s. Request sleep 30s rồi gửi thường được xử lý muộn hơn 30s, không đủ phủ L03.

Mốc t0 không được lấy bằng `locked_until−30s`: cách đó đã giả định điều đang kiểm thử là đúng. Dữ liệu locked_until chỉ là bằng chứng bổ trợ. Độ dài khóa thực tế cần kiểm tra bằng hành vi, không chỉ nhìn timestamp lưu trong DB.

###### 3.2 Kiểm tra đúng 30s: cần đồng hồ kiểm soát ở server

Để thực sự đánh giá L03, dùng harness có khả năng điều khiển thời gian tại **điểm server so sánh khóa**, trên bản sao SUT và DB riêng. Đây là kế hoạch, chưa có harness được tạo/chạy.

1. Lưu commit baseline và mọi patch của harness; chỉ can thiệp nguồn thời gian/ghi quan sát, không sửa ngưỡng 3, thời lượng 30s, toán tử so sánh hoặc nhánh login. Giữ server Web đang dùng nguyên trạng.
2. Đồng bộ các API thời gian liên quan (`Date.now()` và `new Date()` hoặc clock abstraction thực tế); đặt mốc kích hoạt là T0 và chờ ghi DB hoàn tất. Đặt đồng hồ đúng tại phép xét request, không chỉ tại lúc client gửi.
3. Chạy chuỗi khóa tự nhiên với logic baseline. Ở bản sao độc lập, thử T0+30.000s. Nếu lỗi ngưỡng trước đó ngăn setup chuẩn, ghi giới hạn; phép đo từ khóa thực tế là chẩn đoán, không thay bằng chứng ngưỡng đúng.
4. Muốn kiểm riêng toán tử hết hạn trong khi thời lượng tạo khóa bị sai, có thể dùng **fixture bổ trợ** với hạn hết T0+30s và n=3, rồi thử trước/đúng/sau hạn. Ghi rõ fixture này bỏ qua logic tạo khóa, không chứng minh baseline tự tạo khóa 30s.
5. Lưu giá trị clock ở chính điểm so sánh, clock resolution, request/response, state và patch. Với tick 1ms, đó là độ phân giải mô phỏng, không phải độ chính xác hạ tầng thật.

Nếu chưa có harness/không quan sát được điểm so sánh, ca đúng 30s vẫn **Not run** hoặc **Blocked vì giới hạn phép đo** khi đã cố thực hiện. Không đổi expected sang 31s, không tự đánh dấu Pass. Log thêm từ server cũng chỉ giúp nếu thời điểm đo đúng chỗ; log trước handler không chứng minh thời điểm so sánh.

##### 4. Các ca biên

Các bước setup và đo ở mục 2–3 là một phần của từng ca. API là kênh chính để điều khiển tuần tự/thời gian; đối chiếu UI ở ca thích hợp bằng trình duyệt, không suy ra UI đúng từ API. Dùng POST `/api/login`, body `{"email":"<tài khoản riêng>","password":"<P hoặc W>"}` theo thủ tục A trong 03-domain-cases.md.

###### A-BV-001 — Không có lần sai trước đăng nhập đúng

- **Điểm biên/đại diện:** k=0.
- **Chuẩn bị:** Tài khoản riêng n=0, không khóa; client sạch.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L01`, `A-EC-E01`, `A-EC-P01`.
- **Requirement:** `A-R02`, `A-R05`.

**Thao tác:**

1. Mở /login, nhập email của ca và P; mở Network.
2. Bấm Sign In một lần; lưu response và state sau khi xử lý hoàn tất.

**Expected result:** Đăng nhập thành công HTTP 200/token/user; không bị khóa bởi một chuỗi sai chưa tồn tại. Đây là điểm nền cho biến đếm.

**Giới hạn/điểm chưa rõ:** Không coi đây là kiểm tra toàn bộ luồng token/header; Domain 001 phụ trách phần đó.

###### A-BV-002 — Một lần sai đầu tiên

- **Điểm biên/đại diện:** k=1.
- **Chuẩn bị:** Tài khoản riêng n=0, chưa khóa.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-N01`, `A-EC-P02`, `A-EC-O02`.
- **Requirement:** `A-R03`, `A-R04`, `A-R05`.

**Thao tác:**

1. Theo A, gửi email đúng/W một lần; chờ response và DB ổn định.
2. Đọc D, lưu n và trạng thái khóa; không login đúng để thăm dò.

**Expected result:** Từ chối, n từ 0 thành 1, chưa kích hoạt khóa; chỉ password sai.

**Giới hạn/điểm chưa rõ:** Không dùng response lỗi đơn thuần để kết luận counter tăng đúng.

###### A-BV-003 — Ngay dưới ngưỡng khóa

- **Điểm biên/đại diện:** k=2.
- **Chuẩn bị:** Tài khoản riêng n=0, chưa khóa.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-N01`, `A-EC-N02`, `A-EC-P02`.
- **Requirement:** `A-R02`, `A-R03`, `A-R04`, `A-R05`.

**Thao tác:**

1. Gửi email đúng/W lần 1, chờ hoàn tất, đọc n.
2. Gửi lần 2 tuần tự, đọc n/locked_until và response.
3. Để kiểm tra chưa bị khóa trên hành vi, gửi P đúng một lần sau khi đã giữ state sau lần sai thứ 2; đây là bước cuối của ca, không tái dùng state.

**Expected result:** Sau hai lần sai, n=2 và chưa khóa. Request P đúng cuối được đăng nhập thành công. Nếu bước đầu lệch, ghi lỗi sớm và giới hạn checkpoint ngưỡng.

**Giới hạn/điểm chưa rõ:** Thăm dò đúng làm reset chuỗi; tuyệt đối không nối ca k=3 vào tài khoản này.

###### A-BV-004 — Đúng ngưỡng khóa

- **Điểm biên/đại diện:** k=3.
- **Chuẩn bị:** Tài khoản riêng n=0, chưa khóa.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-N01`, `A-EC-N02`, `A-EC-N03`, `A-EC-H01`, `A-EC-O03`, `A-EC-L02`.
- **Requirement:** `A-R03`, `A-R04`, `A-R05`, `A-R06`.

**Thao tác:**

1. Gửi 3 request email đúng/W tuần tự; sau mỗi request ghi response và D.
2. Lưu mốc request đầu tiên kích hoạt khóa và counter sau lần 3.
3. Nếu setup đạt khóa, gửi P đúng trong khoảng xác minh được <30s để kiểm tra bị chặn; lưu riêng thời điểm.

**Expected result:** Counter đi 1→2→3; khóa kích hoạt ở lần thứ 3. Trong khoảng khóa, P đúng bị chặn. Thời lượng 30s được kiểm tra bằng ca thời gian riêng.

**Giới hạn/điểm chưa rõ:** Nếu khóa ở lần 2, đó là sai expected ngưỡng nếu có bằng chứng, không gọi request thứ 3 là lần xác thực sai hợp lệ tiếp theo.

###### A-BV-005 — Request sai thứ tư trong lúc khóa

- **Điểm biên/đại diện:** k=4 request sai đã gửi.
- **Chuẩn bị:** Tài khoản riêng; đã chuẩn bị 3 lần sai tự nhiên, xác nhận đang khóa và thời điểm thử thứ 4 vẫn <30s.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-N04`, `A-EC-P02`, `A-EC-O04`.
- **Requirement:** `A-R03`, `A-R05`, `A-R06`, `A-R07`.

**Thao tác:**

1. Gửi email đúng/W lần thứ tư một lần khi đã khóa; không thay email hoặc payload type.
2. Lưu response, thời điểm và D trước/sau; không gửi thêm probe đúng.

**Expected result:** Request thứ tư bị từ chối; tài khoản vẫn không được đăng nhập trong thời gian khóa. Không bắt buộc n=4: request bị khóa có thể không được tính là lần xác thực sai.

**Giới hạn/điểm chưa rõ:** Q2/Q5: counter sau request/gia hạn chưa chốt. Nếu 3 lần sai không tạo đúng state, chưa chứng minh checkpoint sau ngưỡng chuẩn.

###### A-BV-006 — Đăng nhập đúng tại mục tiêu 29 giây

- **Điểm biên/đại diện:** elapsed=29s.
- **Chuẩn bị:** Một tài khoản/chuỗi khóa riêng cho ca; email/password đúng; không request xen giữa setup và probe.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L02`, `A-EC-P01`, `A-EC-O04`.
- **Requirement:** `A-R02`, `A-R06`, `A-R07`.

**Thao tác:**

1. Chuẩn bị khóa riêng theo mục 2, ghi a/b của request kích hoạt khóa; không gửi request xen.
2. Lập lịch một request email đúng/P gần mục tiêu 29s; lưu c/d bằng monotonic.
3. Tính khoảng elapsed theo mục 3.1; đối chiếu miền trước/sau 30s, lưu response và state.

**Expected result:** Request nằm trong [0,30)s phải bị chặn dù P đúng; không cấp token thành công mới.

**Giới hạn/điểm chưa rõ:** Ghi khoảng đo thực tế, không khẳng định đúng số giây mục tiêu. Khoảng cắt 30s: checkpoint thời gian chưa kết luận; nếu khóa sớm trong setup phải ghi chẩn đoán từ mốc thực, không che lỗi ngưỡng.

###### A-BV-007 — Đăng nhập đúng tại mục tiêu 30 giây

- **Điểm biên/đại diện:** elapsed=30s.
- **Chuẩn bị:** Một tài khoản/chuỗi khóa riêng cho ca; email/password đúng; không request xen giữa setup và probe.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L03`, `A-EC-P01`.
- **Requirement:** `A-R02`, `A-R06`.

**Thao tác:**

1. Chuẩn bị chuỗi khóa riêng và T0 theo harness mục 3.2, giữ code login baseline.
2. Đặt clock tại điểm kiểm tra khóa bằng T0+30.000s; gửi email đúng/P.
3. Lưu giá trị clock thực tại phép so sánh, response, state, patch harness và loại setup tự nhiên/fixture.

**Expected result:** Tại đúng 30s kể từ kích hoạt, thời hạn khóa 30s đã hết; P đúng được xác thực thành công 200/token/user. Diễn giải theo A-R06, Q4 cần phương pháp đo phù hợp.

**Giới hạn/điểm chưa rõ:** Chỉ có verdict tại đúng mốc nếu harness đạt điều kiện 3.2. Sleep 30s/bấm tay không đủ; không có harness thì chưa kiểm chứng L03.

###### A-BV-008 — Đăng nhập đúng tại mục tiêu 31 giây

- **Điểm biên/đại diện:** elapsed=31s.
- **Chuẩn bị:** Một tài khoản/chuỗi khóa riêng cho ca; email/password đúng; không request xen giữa setup và probe.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L04`, `A-EC-P01`.
- **Requirement:** `A-R02`, `A-R06`.

**Thao tác:**

1. Chuẩn bị khóa riêng theo mục 2, ghi a/b của request kích hoạt khóa; không gửi request xen.
2. Lập lịch một request email đúng/P gần mục tiêu 31s; lưu c/d bằng monotonic.
3. Tính khoảng elapsed theo mục 3.1; đối chiếu miền trước/sau 30s, lưu response và state.

**Expected result:** Request nằm sau 30s, không có gia hạn xen giữa: khóa cũ hết và P đúng được xác thực thành công 200/token/user.

**Giới hạn/điểm chưa rõ:** Ghi khoảng đo thực tế, không khẳng định đúng số giây mục tiêu. Khoảng cắt 30s: checkpoint thời gian chưa kết luận; nếu khóa sớm trong setup phải ghi chẩn đoán từ mốc thực, không che lỗi ngưỡng.

###### A-BV-009 — Đăng nhập đúng tại mục tiêu 10 giây

- **Điểm biên/đại diện:** elapsed=10s.
- **Chuẩn bị:** Một tài khoản/chuỗi khóa riêng cho ca; email/password đúng; không request xen giữa setup và probe.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L02`, `A-EC-P01`, `A-EC-O04`.
- **Requirement:** `A-R02`, `A-R06`, `A-R07`.

**Thao tác:**

1. Chuẩn bị khóa riêng theo mục 2, ghi a/b của request kích hoạt khóa; không gửi request xen.
2. Lập lịch một request email đúng/P gần mục tiêu 10s; lưu c/d bằng monotonic.
3. Tính khoảng elapsed theo mục 3.1; đối chiếu miền trước/sau 30s, lưu response và state.

**Expected result:** Request nằm trong [0,30)s phải bị chặn dù P đúng; không cấp token thành công mới.

**Giới hạn/điểm chưa rõ:** Ghi khoảng đo thực tế, không khẳng định đúng số giây mục tiêu. Khoảng cắt 30s: checkpoint thời gian chưa kết luận; nếu khóa sớm trong setup phải ghi chẩn đoán từ mốc thực, không che lỗi ngưỡng.

###### A-BV-010 — Đăng nhập đúng tại mục tiêu 40 giây

- **Điểm biên/đại diện:** elapsed=40s.
- **Chuẩn bị:** Một tài khoản/chuỗi khóa riêng cho ca; email/password đúng; không request xen giữa setup và probe.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L04`, `A-EC-P01`.
- **Requirement:** `A-R02`, `A-R06`.

**Thao tác:**

1. Chuẩn bị khóa riêng theo mục 2, ghi a/b của request kích hoạt khóa; không gửi request xen.
2. Lập lịch một request email đúng/P gần mục tiêu 40s; lưu c/d bằng monotonic.
3. Tính khoảng elapsed theo mục 3.1; đối chiếu miền trước/sau 30s, lưu response và state.

**Expected result:** Request nằm sau 30s, không có gia hạn xen giữa: khóa cũ hết và P đúng được xác thực thành công 200/token/user.

**Giới hạn/điểm chưa rõ:** Ghi khoảng đo thực tế, không khẳng định đúng số giây mục tiêu. Khoảng cắt 30s: checkpoint thời gian chưa kết luận; nếu khóa sớm trong setup phải ghi chẩn đoán từ mốc thực, không che lỗi ngưỡng.

###### A-BV-011 — Sát mốc hết khóa ở 29.999s

- **Điểm biên/đại diện:** elapsed=29.999s (tick giả lập 1ms).
- **Chuẩn bị:** Bản sao và harness mục 3.2; mỗi ca state riêng. Chỉ dùng nếu clock và phép so sánh thật sự hỗ trợ độ phân giải 1ms.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L02`, `A-EC-P01`.
- **Requirement:** `A-R06`.

**Thao tác:**

1. Chuẩn bị khóa tự nhiên trên bản sao hoặc fixture toán tử riêng có khai báo; ghi phương án.
2. Đặt clock ở điểm kiểm tra bằng T0+29.999s, gửi email đúng/P một lần.
3. Lưu clock thực tại so sánh và response; không dùng sleep thực 1ms để thay việc điều khiển clock.

**Expected result:** Trước mốc 30s, đăng nhập đúng vẫn bị chặn.

**Giới hạn/điểm chưa rõ:** Đây là ca bổ sung phụ thuộc harness, không phải độ chính xác đã đo trên môi trường thật. Fixture chỉ kiểm toán tử hết hạn, không chứng minh logic tạo khóa.

###### A-BV-012 — Sát mốc hết khóa ở 30.001s

- **Điểm biên/đại diện:** elapsed=30.001s (tick giả lập 1ms).
- **Chuẩn bị:** Bản sao và harness mục 3.2; mỗi ca state riêng. Chỉ dùng nếu clock và phép so sánh thật sự hỗ trợ độ phân giải 1ms.
- **Dữ liệu:** email tài khoản riêng của ca; P=`Test1234!`, W=`Wrong123!`; chọn đúng P/W theo từng bước.
- **EC ID:** `A-EC-L04`, `A-EC-P01`.
- **Requirement:** `A-R02`, `A-R06`.

**Thao tác:**

1. Chuẩn bị khóa tự nhiên trên bản sao hoặc fixture toán tử riêng có khai báo; ghi phương án.
2. Đặt clock ở điểm kiểm tra bằng T0+30.001s, gửi email đúng/P một lần.
3. Lưu clock thực tại so sánh và response; không dùng sleep thực 1ms để thay việc điều khiển clock.

**Expected result:** Sau mốc 30s, khóa hết; đăng nhập đúng thành công 200/token/user.

**Giới hạn/điểm chưa rõ:** Đây là ca bổ sung phụ thuộc harness, không phải độ chính xác đã đo trên môi trường thật. Fixture chỉ kiểm toán tử hết hạn, không chứng minh logic tạo khóa.

##### 5. Truy vết và cách đánh giá sau khi chạy

| Điểm cần phủ | Ca | Ý nghĩa và điều kiện |
|---|---|---|
| k=0/1 | A-BV-001/002 | Nền và tăng đúng 1 |
| k=2/3/4 | A-BV-003/004/005 | Trước ngưỡng, kích hoạt khóa, thử tiếp trong khóa |
| 29/30/31s | A-BV-006/007/008 | Trước/đúng/sau mốc; 007 cần clock kiểm soát |
| 10/40s | A-BV-009/010 | Đại diện miền cách xa biên để đối chiếu |
| 29.999/30.001s | A-BV-011/012 | Bổ sung sát biên trên harness 1ms nếu khả thi |
| A-EC-L03 | A-BV-007 | Lớp đã hoãn từ Domain; mới có thiết kế, chưa có bằng chứng thực thi |

- Có **12 ca thiết kế**, không phải 12 ca đã chạy. Các ca 007/011/012 phụ thuộc harness chưa được xây dựng; không đánh dấu đã đạt hoặc Blocked như kết quả thực thi ở lượt này.
- Khi chạy, phân biệt: Not run (chưa chạy), Blocked (thiếu fixture/harness hoặc tiền điều kiện không đạt), Pass/Fail (checkpoint có expected rõ và bằng chứng đủ). Phép đo cắt biên ghi “chưa kết luận do phép đo”, không ép thành Pass hoặc Fail; nếu summary chỉ dùng bốn trạng thái, ghi Blocked với lý do và giữ log lần thử đo.
- Nếu có lỗi rõ ở setup, có thể ghi Fail ở checkpoint setup của ca tương ứng và đánh dấu checkpoint phụ thuộc chưa kiểm chứng. Không đếm cùng lỗi nhiều lần; không dùng một kết quả Fail tổng để tuyên bố mọi EC đã được thực thi.
- A-BV-001/002/004/009/010 có thể chồng dữ liệu với Domain 001/002/011/012/013. Khi thực thi, một run có đủ bằng chứng cho cả hai nhãn thì liên kết cùng Run ID và không đếm hai lần việc chạy. Nếu vẫn giữ hai TC ID thiết kế, giải thích phần trùng và cách thống kê; có thể hợp nhất khi human review.
- Các câu Q2/Q3/Q5 về counter sau khóa, gia hạn và reset chưa được tự giải quyết. BVA không tạo expected n=4 hoặc bắt buộc reset ngay hết khóa khi SRS chưa nói.

##### 6. Thông tin cần lưu trong mỗi lần đo (chưa điền kết quả)

`TC ID; Run ID; baseline/patch; tài khoản fixture; counter/khóa trước và sau; setup tự nhiên hay fixture; payload; thời điểm gửi/nhận UTC và monotonic; a,b,c,d; khoảng elapsed; clock tại điểm so sánh nếu có; độ phân giải/giới hạn đo; response; ảnh UI nếu chạy Web; kết luận từng checkpoint; điểm chưa đủ bằng chứng`.

Không suy ra t0 từ hạn khóa bằng cách trừ 30s, không đồng nhất thời điểm response với thời điểm phép so sánh, không nhập số thời gian lý tưởng vào log. Script thực thi sẽ được chuẩn bị ở bước sau và phải lưu số đo thật.

##### 7. Bước tiếp theo

Sinh viên đọc lại requirements, domains, Domain cases và file BVA này. Ưu tiên review: định nghĩa k/n, expected request thứ 4, điều kiện đo đúng 30s và việc tách fixture khỏi luồng thật. Chỉ tạo `05-review-coverage.md` dựa trên nhận xét thật; chưa ghi sinh viên đã duyệt.

### B-FR07 — thiết kế đầy đủ

#### 01-requirements — B-FR07

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### 1. Phạm vi và nguồn expected result

| Mã | Nguồn | Dùng để xác định |
|---|---|---|
| S1 | `eshop-sut/README.md`, FR-07 | Hành vi giỏ hàng Web: nội dung/ cột, gộp sản phẩm, xác nhận xóa, tiếp tục mua sắm, nhãn tổng tiền, giỏ rỗng |
| S2 | `eshop-sut/README.md`, FR-06 | Ô nhập số lượng trên trang chi tiết sản phẩm: số nguyên dương, tối thiểu 1; phản hồi trực quan khi thêm vào giỏ |
| S3 | `eshop-sut/api_specification.md`, mục 4.1–4.2 | API cart được tài liệu hóa là `GET /api/cart`, `POST /api/cart`; header yêu cầu Bearer token; body thêm hàng có `id`, `name`, `price`, `quantity` |
| S4 | `group_feature_assignment.md`, Thành viên 2 / Pool B FR-07 | Input được giao: số lượng, nút +/−, nút Xóa; thành tiền = đơn giá × số lượng; số lượng tối thiểu ≥1; dialog xác nhận; nhãn “Tổng cộng” |
| S5 | Slide [`domain-testing-en.pdf`](../slide/domain-testing-en.pdf) và [`domain-testing-vn.pdf`](../slide/domain-testing-vn.pdf) | Phương pháp: xác định input/output từ đặc tả; expected của một phân hoạch phải nhất quán; chọn giá trị biên từ điều kiện có nguồn |

S1 là oracle chính cho hành vi FR-07. S2 chỉ là nguồn quy tắc số lượng nhập ở FR-06; không tự động coi mọi chi tiết trang sản phẩm là phần việc FR-07. S3 mô tả giao tiếp API và ví dụ dữ liệu, không định nghĩa đầy đủ expected cho các thao tác Web trong FR-07. S4 là phân công bổ sung của nhóm; nội dung nào S1 không nêu rõ được ghi là giả định/câu hỏi, không gán thành yêu cầu SRS.

**Baseline tham chiếu:** SUT commit `85af3ba875c88283615e22cb108f13e2fccaf0e9`. Không đọc code SUT để đặt expected result.

##### 2. Input và trạng thái cần theo dõi

| ID | Input / trạng thái | Ý nghĩa |
|---|---|---|
| B-I01 | Sản phẩm | Danh tính sản phẩm được thêm vào giỏ; API spec minh họa bằng `id` và `name`. Quy tắc xác định hai mục là “cùng sản phẩm” chưa được mô tả chi tiết ngoài việc so sánh theo sản phẩm. |
| B-I02 | Đơn giá | Giá sản phẩm cần hiển thị trên dòng giỏ và dùng để xác định thành tiền theo phân công nhóm. Định dạng hiển thị và thời điểm lấy giá chưa rõ. |
| B-I03 | Số lượng | Giá trị đưa vào giỏ hoặc thay đổi bằng nút +/−. FR-06 yêu cầu số nguyên dương, tối thiểu 1 đối với ô nhập số lượng trên trang chi tiết. |
| B-I04 | Thao tác người dùng | Thêm vào giỏ; bấm +/−; bấm Xóa; xác nhận hoặc hủy dialog; bấm Tiếp tục mua sắm; mở trang giỏ. |
| B-S01 | Nội dung giỏ trước thao tác | Giỏ rỗng hay có một/nhiều dòng; sản phẩm và số lượng hiện tại. Cần biết để đánh giá thay đổi sau thao tác. |
| B-S02 | Dòng sản phẩm | Danh tính sản phẩm, đơn giá và số lượng trước/sau; số dòng cho sản phẩm đó. |
| B-S03 | Tổng giỏ | Giá trị tổng hiển thị trước/sau thao tác. Quy tắc tổng hợp/rounding chưa được nêu đầy đủ trong SRS. |
| B-S04 | Dialog xóa | Dialog đang mở hay chưa; quyết định người dùng xác nhận hoặc hủy. |
| B-S05 | Trang hiện tại | Trang giỏ hay trang chủ, để kiểm tra thao tác tiếp tục mua sắm. |

##### 3. Yêu cầu, trạng thái và đầu ra cần quan sát

###### B-R01 — Hiển thị trạng thái giỏ rỗng

- **Yêu cầu:** Khi giỏ không có sản phẩm, Web hiển thị hình minh họa và thông báo rõ ràng rằng giỏ đang rỗng.
- **Input:** Trạng thái giỏ trước là rỗng; mở trang giỏ.
- **Trạng thái trước → sau:** 0 dòng → vẫn 0 dòng; không có thao tác thêm/xóa trong bước quan sát.
- **Đầu ra Web:** Có hình minh họa và thông báo rõ ràng về giỏ rỗng.
- **Nguồn expected:** S1 FR-07. SRS không quy định ảnh hay câu chữ cụ thể.

###### B-R02 — Hiển thị các cột của giỏ

- **Yêu cầu:** Khi giỏ có sản phẩm, danh sách hiển thị các cột Sản phẩm, Đơn giá, Số lượng, Thành tiền, Thao tác.
- **Input:** Một hay nhiều dòng sản phẩm trong giỏ; mở trang giỏ.
- **Trạng thái trước → sau:** Có dòng → giữ nguyên dòng trong lúc quan sát.
- **Đầu ra Web:** Nhìn thấy đủ năm cột và dữ liệu tương ứng.
- **Nguồn expected:** S1 FR-07. Tên/cách trình bày có thể khác về kiểu chữ nhưng ý nghĩa cột phải tương ứng; chi tiết bố cục chưa được quy định.

###### B-R03 — Thêm một sản phẩm vào giỏ

- **Yêu cầu:** Giỏ có thể hiển thị sản phẩm đã được thêm từ luồng mua sắm.
- **Input:** Sản phẩm (id/tên), đơn giá, số lượng; thao tác thêm. Số lượng ở ô nhập trên trang chi tiết chịu quy tắc FR-06.
- **Trạng thái trước → sau:** Giỏ ban đầu chưa có sản phẩm đó → giỏ có dòng sản phẩm sau khi thêm thành công.
- **Đầu ra Web:** Dòng sản phẩm xuất hiện với tên, đơn giá, số lượng và thành tiền; phản hồi thêm hàng thuộc FR-06 có thể là toast hoặc badge.
- **Nguồn expected:** S1 FR-07 cho nội dung giỏ; S2 FR-06 cho input số lượng và phản hồi thêm; S3 mục 4.2 cho các trường API mẫu. SRS không chỉ rõ giá trị mặc định khi thêm.

###### B-R04 — Thêm lại cùng sản phẩm thì gộp dòng và tăng số lượng

- **Yêu cầu:** Thêm cùng một sản phẩm lần nữa làm tăng số lượng hiện có, không tạo thêm dòng cho sản phẩm đó.
- **Input:** Sản phẩm đã có trong giỏ; số lượng đang có; thao tác thêm lại cùng sản phẩm.
- **Trạng thái trước → sau:** Có một dòng cho sản phẩm với số lượng hiện tại → vẫn một dòng cho sản phẩm đó, số lượng tăng theo lượng được thêm.
- **Đầu ra Web:** Không xuất hiện dòng trùng; số lượng dòng hiện có tăng. Số lượng tăng cụ thể phụ thuộc input ở lần thêm.
- **Nguồn expected:** S1 FR-07. Cách nhận diện “cùng sản phẩm” theo ID hay thuộc tính khác chưa được đặc tả.

###### B-R05 — Nút cộng số lượng

- **Yêu cầu:** Dòng sản phẩm có nút `+` để điều chỉnh số lượng.
- **Input:** Một dòng có số lượng hiện tại q; bấm `+` một lần.
- **Trạng thái trước → sau:** q → số lượng mới lớn hơn q theo một bước điều chỉnh.
- **Đầu ra Web:** Số lượng trên dòng được cập nhật và thành tiền được cập nhật tương ứng nếu phép tính theo đơn giá × số lượng được áp dụng.
- **Nguồn expected:** S1 FR-07 nói có nút +/- để chỉnh; S4 yêu cầu kiểm tra nút và công thức thành tiền. SRS chưa nêu bước tăng là bao nhiêu (phân công hàm ý tăng 1, cần xác nhận trước khi chấm chi tiết).

###### B-R06 — Nút trừ số lượng và giới hạn tối thiểu

- **Yêu cầu:** Dòng sản phẩm có nút `−` để điều chỉnh số lượng; số lượng dương, tối thiểu 1 là quy tắc được nêu cho quantity ở FR-06.
- **Input:** Một dòng có số lượng q; bấm `−`.
- **Trạng thái trước → sau:** q → số lượng mới nhỏ hơn q khi thao tác được chấp nhận; không được suy ra từ FR-06 rằng số lượng ở giỏ được phép thành 0 hoặc âm.
- **Đầu ra Web:** Số lượng/ thành tiền phản ánh thay đổi được chấp nhận; khi đang ở 1 thì kết quả của thao tác trừ cần làm rõ.
- **Nguồn expected:** S1 FR-07 về nút +/-; S2 FR-06 và S4 về số lượng nguyên dương tối thiểu 1. Phạm vi áp dụng ngưỡng 1 khi giảm trong giỏ chưa được diễn đạt trực tiếp trong S1.

###### B-R07 — Thành tiền trên từng dòng

- **Yêu cầu:** Mỗi dòng có cột Thành tiền; theo phân công nhóm, thành tiền bằng đơn giá nhân số lượng.
- **Input:** Đơn giá p và số lượng q trên một dòng.
- **Trạng thái trước → sau:** p, q của dòng → sau khi q đổi thì thành tiền cần phản ánh p × q theo quy ước được giao.
- **Đầu ra Web:** Giá trị thành tiền của đúng dòng sản phẩm.
- **Nguồn expected:** S1 FR-07 yêu cầu cột Thành tiền; công thức `p × q` có nguồn S4, không được ghi như câu chữ trực tiếp từ SRS. Định dạng tiền/làm tròn chưa rõ.

###### B-R08 — Tổng tiền và nhãn “Tổng cộng”

- **Yêu cầu:** Khu vực tổng tiền dùng chính xác nhãn **“Tổng cộng”**, không dùng **“Tổng tạm tính”**.
- **Input:** Các dòng sản phẩm, đơn giá, số lượng và thao tác làm thay đổi giỏ.
- **Trạng thái trước → sau:** Tập dòng trước thao tác → tập dòng sau thao tác; tổng hiển thị được quan sát trước/sau.
- **Đầu ra Web:** Nhãn “Tổng cộng” và giá trị tổng tiền hiện trên trang giỏ.
- **Nguồn expected:** Nhãn theo S1 FR-07 và S4. S1 chưa viết rõ công thức tổng giỏ; S4 chỉ nêu rõ công thức thành tiền từng dòng. Không tự giả định quy tắc làm tròn, phí/vận chuyển/giảm giá hay thời điểm cập nhật tổng.

###### B-R09 — Xóa sản phẩm mở dialog xác nhận

- **Yêu cầu:** Khi chọn xóa một dòng sản phẩm, hệ thống phải hỏi xác nhận trước khi thực hiện.
- **Input:** Giỏ có dòng sản phẩm; bấm Xóa sản phẩm.
- **Trạng thái trước → sau:** Dòng còn trong giỏ, dialog chưa mở → dialog xác nhận xuất hiện; chưa xác nhận thì không coi là đã xóa.
- **Đầu ra Web:** Có dialog/confirmation trước khi xóa.
- **Nguồn expected:** S1 FR-07; S4 cũng nêu dialog. Câu chữ và loại dialog (native hay giao diện tùy biến) chưa quy định.

###### B-R10 — Xác nhận xóa

- **Yêu cầu:** Khi người dùng xác nhận trong dialog, thao tác xóa được thực hiện.
- **Input:** Dialog đang mở; chọn hành động xác nhận.
- **Trạng thái trước → sau:** Dòng được chọn còn trong giỏ → dòng đó không còn trong giỏ sau khi xác nhận; các dòng khác (nếu có) cần được quan sát.
- **Đầu ra Web:** Dòng bị xóa; nếu đó là dòng cuối, trạng thái giỏ rỗng cần tuân theo B-R01.
- **Nguồn expected:** S1 FR-07 yêu cầu dialog trước thao tác xóa; kết quả sau xác nhận là diễn giải chức năng thông thường, cần giữ rõ là expected suy ra từ “Xóa sản phẩm”, chưa có mô tả cụ thể về ảnh hưởng dòng khác.

###### B-R11 — Hủy xóa

- **Yêu cầu:** Khi người dùng hủy/đóng dialog thay vì xác nhận, không thực hiện yêu cầu xóa.
- **Input:** Dialog đang mở; chọn hủy/đóng.
- **Trạng thái trước → sau:** Dòng vẫn còn trước quyết định → dòng tiếp tục còn sau khi hủy; số lượng và tổng không đổi do riêng thao tác hủy.
- **Đầu ra Web:** Dialog đóng và sản phẩm không bị xóa.
- **Nguồn expected:** S1 nói cần dialog xác nhận nhưng không mô tả nút Hủy hoặc kết quả cụ thể khi hủy. Đây là giả định cần xác nhận, không đánh dấu là yêu cầu trực tiếp của SRS.

###### B-R12 — Tiếp tục mua sắm

- **Yêu cầu:** Có nút Tiếp tục mua sắm; bấm nút đưa người dùng trở về trang chủ.
- **Input:** Đang ở trang giỏ; bấm nút Tiếp tục mua sắm.
- **Trạng thái trước → sau:** Trang giỏ, nội dung giỏ hiện tại → trang chủ; FR-07 không nói thao tác này xóa giỏ, nên không kỳ vọng giỏ bị xóa.
- **Đầu ra Web:** Điều hướng về trang chủ.
- **Nguồn expected:** S1 FR-07. Việc giữ giỏ khi điều hướng là điều không được S1 nói trực tiếp, ghi thành câu hỏi ở mục 4.

###### B-R13 — Số lượng hợp lệ từ FR-06

- **Yêu cầu phụ thuộc:** Khi lượng hàng được nhập ở ô quantity trên trang chi tiết trước khi thêm, giá trị phải là số nguyên dương, tối thiểu 1.
- **Input:** Giá trị quantity nhập và thao tác thêm vào giỏ.
- **Trạng thái trước → sau:** Giỏ có trạng thái trước đó → chỉ khi thao tác được chấp nhận mới kỳ vọng số lượng được thêm vào giỏ; hành vi với input không hợp lệ chưa được SRS mô tả đủ ở client/API.
- **Đầu ra Web:** Quantity hợp lệ được chuyển vào luồng thêm hàng; FR-06 yêu cầu có phản hồi trực quan (toast hoặc badge).
- **Nguồn expected:** S2 FR-06. Đây là quy tắc của trang chi tiết sản phẩm, phụ thuộc chức năng FR-06 do thành viên khác phụ trách; phần B-FR07 chỉ ghi nhận quantity được đưa vào giỏ và kết quả trên giỏ, không nhận toàn bộ kiểm thử FR-06.

##### 4. Điều chưa được SRS nói rõ — giữ dạng câu hỏi

Các điểm dưới đây chưa được dùng để tự đặt expected result:

1. **Số lượng tối đa và tồn kho:** có giới hạn tối đa không; tăng quantity vượt tồn kho xử lý ra sao?
2. **Lưu giỏ qua reload/đóng mở trình duyệt/đăng nhập:** FR-07 không nói giỏ phải được lưu ở đâu hoặc bền qua lần tải lại hay không.
3. **Giá đổi sau khi thêm:** dùng giá lúc thêm hay giá mới khi mở giỏ; khi giá sản phẩm thay đổi thì thành tiền/tổng cập nhật thế nào?
4. **Số âm, số thập phân, rỗng hoặc chuỗi không phải số ở client/API:** FR-06 xác định quantity nhập là số nguyên dương tối thiểu 1, nhưng chưa nêu rõ thông báo/chặn ở client và phản hồi cho API invalid. Không suy ra từ code.
5. **Giảm từ quantity 1:** nút `−` bị disable, giữ ở 1, hỏi xóa hay xóa luôn dòng?
6. **Câu chữ của empty state, dialog và phản hồi thêm/xóa:** SRS yêu cầu thông báo/hình và dialog nhưng không cho nội dung cụ thể.
7. **Bước của nút +/-:** phân công gợi ý nút cộng/trừ; SRS không nêu mỗi lần thay đổi bao nhiêu.
8. **Tổng giỏ:** SRS nêu nhãn và giá trị tổng nhưng chưa định nghĩa tường minh công thức tổng hợp, làm tròn, phí hay giảm giá trong FR-07. Công thức thành tiền từng dòng chỉ được nêu ở phân công nhóm.
9. **Định danh sản phẩm trùng:** “cùng một sản phẩm” chưa chỉ rõ so theo ID hay theo trường nào.
10. **Hủy dialog và điều hướng:** FR-07 chưa nêu nút/behavior hủy, hoặc giỏ được giữ thế nào sau khi quay về trang chủ.

##### 5. Giả định cần review và ranh giới thành viên 2

- Dùng chính các từ SRS “cùng một sản phẩm”, không tự chốt quy tắc matching ID/name trước khi review.
- `Đơn giá × Số lượng` cho **thành tiền dòng** là hướng dẫn của phân công nhóm; khi báo cáo cần ghi nguồn S4.
- Không suy rộng yêu cầu quantity FR-06 sang mọi request/API, hoặc sang quy tắc tồn kho/tối đa chưa có nguồn.
- Phạm vi thành viên 2: **FR-07 giỏ hàng trên Web**. Chỉ tham chiếu FR-06 ở quantity và luồng thêm sản phẩm; không nhận kiểm thử đầy đủ trang chi tiết sản phẩm. Không mở rộng sang FR-08 checkout, FR-09 coupon, API quản lý sản phẩm hay Mobile FR-20.

##### 6. Phương pháp và trạng thái bước

Theo slide Domain/BVA, xác định input/output trước khi chia lớp; chỉ chọn expected có căn cứ trong đặc tả hoặc nguồn phân công được ghi rõ. Tài liệu này dừng ở requirements. EC, đại diện lớp, test case, boundary case, execution result và human review sẽ được tạo ở các bước riêng sau khi review các câu hỏi mở.

#### 02-domains — B-FR07

**Nguồn requirement:** `01-requirements.md`, SRS FR-06/FR-07, API spec mục 4.1–4.2 và phân công Thành viên 2.

##### Cách chia lớp

Theo slide Domain Testing, các giá trị thuộc cùng lớp nếu expected result của chúng giống nhau; input có điều kiện rõ thì tách lớp hợp lệ và không hợp lệ. Mỗi lớp dưới đây có một ví dụ để người đọc hiểu ranh giới, chưa phải lịch chạy test. Expected lấy từ SRS khi có; hướng dẫn bổ sung của phân công được ghi riêng. Điểm thiếu oracle được xếp “chưa kết luận / thăm dò”, không ép vào lớp Fail.

Trong các ví dụ, `P1`/`P2` là hai sản phẩm mẫu có ID khác nhau; giá chỉ minh họa phép tính. Số lượng được nhập tại **ô quantity của trang chi tiết sản phẩm trước khi bấm Thêm vào giỏ** (FR-06). API payload là một điểm nhập khác, không dùng để thay thế kiểm tra input Web.

##### 1. Trạng thái giỏ và sản phẩm

| EC ID | Input/trạng thái | Lớp và điều kiện chính xác | Ví dụ đại diện | Expected result và căn cứ | B-R liên quan |
|---|---|---|---|---|---|
| B-EC-01 | Số dòng giỏ | Hợp lệ — giỏ rỗng, 0 dòng | `[]` | Web hiển thị hình minh họa và thông báo giỏ rỗng. SRS FR-07, trực tiếp. | B-R01 |
| B-EC-02 | Số dòng giỏ | Hợp lệ — giỏ có đúng 1 dòng sản phẩm | `P1 × 1` | Web hiển thị các cột Sản phẩm, Đơn giá, Số lượng, Thành tiền, Thao tác. SRS FR-07. | B-R02, B-R03 |
| B-EC-03 | Số dòng giỏ | Hợp lệ — giỏ có từ 2 dòng khác nhau trở lên | `P1`, `P2` | Danh sách có một dòng cho mỗi sản phẩm khác nhau; các cột SRS hiển thị. Việc một sản phẩm khác ID là sản phẩm khác dựa trên ví dụ `id` của API spec, cần xác nhận quy tắc identity. | B-R02 |
| B-EC-04 | ID sản phẩm thêm lại | Hợp lệ theo giả định identity — ID lần thêm bằng ID sản phẩm đã có | P1 có `id=1`; thêm lại P1 `id=1` | Nếu hai mục cùng sản phẩm, số dòng giữ 1 và quantity tăng; SRS FR-07 trực tiếp nói cùng sản phẩm phải gộp. Dùng cùng ID làm đại diện là giả định từ trường `id` trong API spec. | B-R04 |
| B-EC-05 | ID sản phẩm được thêm | Hợp lệ theo giả định identity — ID khác ID đang có | Giỏ có P1 `id=1`; thêm P2 `id=2` | Kỳ vọng mỗi sản phẩm là một dòng riêng là suy luận tự nhiên từ “cùng một sản phẩm” và trường `id`; SRS không nêu rõ quy tắc matching. Cần xác nhận trước khi chấm số dòng theo ID. | B-R02, B-R04 |
| B-EC-06 | Tồn tại sản phẩm | Hợp lệ — sản phẩm được chọn còn xác định được từ danh mục sản phẩm | P1 tồn tại và có giá hiển thị | Có thể quan sát thông tin sản phẩm và luồng thêm; SRS FR-06 mô tả chi tiết sản phẩm. | B-R03, B-R13 |
| B-EC-07 | Tồn tại sản phẩm | Chưa kết luận — ID không tồn tại, sản phẩm bị xóa hoặc không xác định được | ID `999999` không có nguồn xác nhận tồn tại | SRS FR-06/FR-07 và API spec không nói xử lý ra sao; chỉ thăm dò để ghi actual, không có expected/Pass/Fail. | B-R03, B-R04; câu hỏi |

##### 2. Đơn giá và số lượng

| EC ID | Input | Lớp và điều kiện chính xác | Ví dụ đại diện | Expected result và căn cứ | B-R liên quan |
|---|---|---|---|---|---|
| B-EC-08 | Đơn giá sản phẩm | Giá sản phẩm hiện có và xác định được ở thời điểm mở trang | P1 có đơn giá được SUT hiển thị là 50.000 | Web có cột Đơn giá; giá trị cụ thể phụ thuộc dữ liệu sản phẩm. Không kiểm tra biến động giá ở lớp này. SRS FR-07. | B-R02, B-R03, B-R07 |
| B-EC-09 | Giá thiếu, sai hoặc thay đổi | Chưa kết luận — giá không xác định, âm, hoặc thay đổi sau khi thêm | Giá P1 thay đổi giữa lúc thêm và mở giỏ | SRS/API spec không đặt miền hợp lệ cho giá trong giỏ hay quy tắc chọn giá cũ/mới. Thăm dò/đợi làm rõ; không gán expected. | B-R07, B-R08; câu hỏi |
| B-EC-10 | Quantity ở ô nhập FR-06 | Hợp lệ — số nguyên đúng bằng 1 | `1` | Được chấp nhận theo FR-06: số nguyên dương, tối thiểu 1; sau khi thêm, quantity được đưa vào giỏ. | B-R03, B-R13 |
| B-EC-11 | Quantity ở ô nhập FR-06 | Hợp lệ — số nguyên lớn hơn 1 | `2` | Là số nguyên dương; FR-06 cho phép quantity theo mô tả. Giá trị cụ thể không đại diện cho giới hạn tối đa. | B-R03, B-R13 |
| B-EC-12 | Quantity ở ô nhập FR-06 | Không hợp lệ — bằng 0 | `0` | FR-06 chỉ nhận số nguyên dương tối thiểu 1; giá trị 0 không được chấp nhận làm quantity thêm vào giỏ. Hình thức chặn/thông báo chưa quy định. | B-R13 |
| B-EC-13 | Quantity ở ô nhập FR-06 | Không hợp lệ — số nguyên âm | `-1` | Không phải số nguyên dương tối thiểu 1; không được chấp nhận làm quantity thêm. Cách UI chặn/thông báo chưa quy định. | B-R13 |
| B-EC-14 | Quantity ở ô nhập FR-06 | Không hợp lệ — số thập phân | `1.5` | Không phải số nguyên; FR-06 yêu cầu số nguyên dương nên không được chấp nhận làm quantity thêm. Cách UI chặn/thông báo chưa quy định. | B-R13 |
| B-EC-15 | Quantity ở ô nhập FR-06 | Không hợp lệ — nội dung không phải số | `abc` nếu điểm nhập cho phép gõ chuỗi này | Không đáp ứng yêu cầu số nguyên dương; không được chấp nhận làm quantity thêm. Nếu control không cho nhập chuỗi, ghi nhận điểm nhập không thể nhận giá trị đó, không đổi sang API để giả lập UI. | B-R13 |
| B-EC-16 | Quantity tại API `POST /api/cart` | Chưa kết luận — 0, âm, thập phân, null, chuỗi hoặc thiếu trường gửi trực tiếp API | `quantity: 1.5` | API spec chỉ cho ví dụ trường `quantity`, không định nghĩa validate/error/side effect. Có thể thăm dò khi thiết kế execution riêng; không gán expected hoặc verdict từ FR-06 UI. | B-R03; câu hỏi |
| B-EC-17 | Quantity thay đổi bằng `+` | Hợp lệ — dòng đã có, bấm nút `+` | P1 quantity 1 rồi bấm `+` | SRS FR-07 yêu cầu nút + để chỉnh. Quantity cần tăng; bước tăng chính xác chưa được SRS nêu, phân công hàm ý mỗi click tăng một đơn vị nhưng cần xác nhận. | B-R05 |
| B-EC-18 | Quantity thay đổi bằng `−` | Hợp lệ — dòng có quantity lớn hơn mức tối thiểu, bấm nút `−` | P1 quantity 2 rồi bấm `−` | SRS FR-07 yêu cầu nút − để chỉnh; quantity giảm khi thao tác được chấp nhận. FR-06 và phân công nêu tối thiểu 1; mức giảm một click cần xác nhận trước khi chấm số cụ thể. | B-R06 |
| B-EC-19 | Bấm `−` tại quantity 1 | Chưa kết luận — thao tác ở ngưỡng tối thiểu | P1 quantity 1 rồi bấm `−` | Không rõ có disable nút, giữ 1, mở confirm xóa hay xóa ngay. Không đặt expected; cần câu trả lời từ SRS/giảng viên. | B-R06; câu hỏi |

**Phân biệt quan trọng:** lớp 0/âm/thập phân/không phải số ở B-EC-12–15 là input Web tại ô quantity FR-06. B-EC-16 là payload API riêng và đang thiếu oracle. Không gộp hai điểm nhập thành một lớp vì kết quả mong đợi và nguồn đặc tả khác nhau.

##### 3. Thao tác và trạng thái dialog xóa

| EC ID | Input/trạng thái | Lớp và điều kiện chính xác | Ví dụ đại diện | Expected result và căn cứ | B-R liên quan |
|---|---|---|---|---|---|
| B-EC-20 | Xóa sản phẩm | Hợp lệ — bấm Xóa khi dòng đang tồn tại và chưa có dialog | Giỏ có P1, dialog đóng → bấm Xóa P1 | Dialog xác nhận phải hiện trước khi xóa. SRS FR-07. | B-R09 |
| B-EC-21 | Quyết định dialog | Hợp lệ — người dùng xác nhận | Dialog mở → chọn xác nhận | Sản phẩm được xóa là diễn giải của thao tác “Xóa sản phẩm”; theo dõi giỏ sau đó. Exact wording/type của dialog chưa quy định. | B-R09, B-R10 |
| B-EC-22 | Quyết định dialog | Hợp lệ về thao tác người dùng, expected còn cần xác nhận — người dùng hủy/đóng | Dialog mở → chọn hủy hoặc đóng | SRS chỉ yêu cầu hỏi xác nhận, không nói cụ thể nút hủy và kết quả. Dự kiến không xóa nhưng phải giữ là câu hỏi/giả định cho tới khi xác nhận. | B-R11; câu hỏi |
| B-EC-23 | Tiếp tục mua sắm | Hợp lệ — đang ở giỏ và bấm nút Tiếp tục mua sắm | Trang giỏ → bấm nút | Điều hướng về trang chủ theo SRS FR-07. SRS không nói persistence của giỏ qua chuyển trang/reload. | B-R12 |

##### 4. Lớp đầu ra cần quan sát trên Web

| EC ID | Output | Lớp đầu ra và điều kiện | Ví dụ/expected | Nguồn và B-R |
|---|---|---|---|---|
| B-EC-24 | Empty state | Hợp lệ — giỏ có 0 dòng, có hình và thông báo rõ | Giỏ rỗng: có cả hình minh họa và thông báo giỏ rỗng | SRS FR-07; B-R01 |
| B-EC-25 | Empty state | Không hợp lệ — giỏ 0 dòng nhưng thiếu hình hoặc thiếu thông báo rõ | Chỉ hiện một trong hai thành phần | Vi phạm điều kiện có hình minh họa **và** thông báo rõ trong SRS FR-07; câu chữ cụ thể không bị kiểm tra | B-R01 |
| B-EC-26 | Cột/dòng hàng | Hợp lệ — dòng có tên sản phẩm, đơn giá, quantity, thành tiền, thao tác | P1 ở một dòng | Các cột Sản phẩm/Đơn giá/Số lượng/Thành tiền/Thao tác hiển thị | SRS FR-07; B-R02 |
| B-EC-27 | Dòng hàng trùng | Không hợp lệ — cùng một sản phẩm xuất hiện thành nhiều dòng sau thao tác thêm lại | Hai dòng P1 sau khi thêm lại cùng P1 | SRS yêu cầu tăng quantity và không tạo dòng mới. Việc map cùng sản phẩm với cùng ID vẫn là giả định cần xác nhận. | SRS FR-07; B-R04 |
| B-EC-28 | Đơn giá đầu ra | Hợp lệ — mỗi dòng có giá trị ở cột Đơn giá | P1 có đơn giá được hiển thị | Có cột Đơn giá; giá trị cụ thể cần đối chiếu với nguồn sản phẩm được chốt khi thiết kế test. Giá đổi sau khi thêm là câu hỏi. | SRS FR-07; B-R02, B-R07 |
| B-EC-29 | Thành tiền đầu ra | Hợp lệ theo phân công — giá trị dòng bằng đơn giá × quantity | `50.000 × 2 = 100.000` | Công thức có ở phân công nhóm Thành viên 2; SRS chỉ yêu cầu cột Thành tiền, không ghi công thức. Là expected có nguồn S4. | B-R07 |
| B-EC-30 | Thành tiền đầu ra | Không hợp lệ theo phân công — giá trị khác đơn giá × quantity | `50.000 × 2` nhưng hiển thị giá trị khác 100.000 | Sai với công thức phân công S4; định dạng/làm tròn cần giữ thống nhất, hiện chưa có quy tắc chi tiết. | B-R07 |
| B-EC-31 | Nhãn tổng | Hợp lệ — nhãn chính xác “Tổng cộng” | `Tổng cộng` | SRS FR-07 nêu đúng nhãn này. | B-R08 |
| B-EC-32 | Nhãn tổng | Không hợp lệ — dùng “Tổng tạm tính” thay cho nhãn yêu cầu hoặc thiếu nhãn “Tổng cộng” | `Tổng tạm tính` | Vi phạm nhãn chính xác theo SRS FR-07. | B-R08 |
| B-EC-33 | Giá trị tổng | Chưa kết luận về phép tính — có giá trị tổng hiển thị nhưng tổng hợp/rounding chưa được SRS định nghĩa | Hai dòng, mỗi thành tiền 100.000; hiển thị tổng được ghi nhận | Có thể quan sát giá trị và ghi actual, nhưng chưa chấm đúng/sai phép tổng hợp theo SRS. Không giả định về phí/giảm giá/làm tròn. | B-R08; câu hỏi |
| B-EC-34 | Phản hồi thêm hàng | Hợp lệ — sau thao tác thêm thành công, có toast hoặc badge cập nhật | Toast hiện hoặc badge cart thay đổi | FR-06 chấp nhận phản hồi trực quan kiểu toast **hoặc** badge; không bắt buộc đồng thời cả hai. | B-R03, B-R13 |
| B-EC-35 | Phản hồi thêm hàng | Không hợp lệ — thao tác thêm thành công nhưng không có toast và cũng không có badge cập nhật | Không thấy toast, badge không đổi | Không thỏa một trong hai dạng phản hồi FR-06. Nếu thao tác thêm thất bại thì chưa áp dụng lớp output thành công này. | B-R03, B-R13 |
| B-EC-36 | Kết quả xác nhận xóa | Hợp lệ theo diễn giải — sau xác nhận, dòng đã chọn không còn | Xác nhận xóa P1; P1 biến mất | Expected được suy ra từ nhãn “Xóa sản phẩm”; SRS không mô tả riêng hậu quả cho các dòng còn lại. | B-R10 |
| B-EC-37 | Kết quả hủy xóa | Chưa kết luận — dòng còn hay mất sau hủy dialog | Hủy dialog với P1 trong giỏ | Dự kiến giữ nguyên nhưng SRS không nêu hành vi Cancel. Ghi observation nếu thăm dò; không gán Pass/Fail. | B-R11; câu hỏi |
| B-EC-38 | Badge giỏ | Chưa kết luận về badge số lượng cụ thể | Thêm P1 quantity 2; badge hiển thị một số | FR-06 chỉ cho badge là một dạng phản hồi, không nói badge biểu thị số sản phẩm, tổng quantity hay cách cập nhật khi xóa. Không chấm con số badge. | B-R03, B-R13; câu hỏi |

##### 5. Persistence và lớp chưa có oracle

| EC ID | Trạng thái/input | Phân loại | Ví dụ | Expected/cách xử lý hiện tại | B-R |
|---|---|---|---|---|---|
| B-EC-39 | Reload khi giỏ có sản phẩm | Chưa kết luận | Có P1 trong giỏ → reload trang | SRS không nêu giỏ có phải tồn tại qua reload hay không; chỉ ghi nhận nếu thăm dò, không kết luận lỗi. | B-S01; câu hỏi |
| B-EC-40 | Giá/tồn kho đổi sau khi thêm | Chưa kết luận | P1 thay giá hoặc hết hàng sau khi đã thêm | SRS không nêu refresh giá, cập nhật tồn kho hoặc giới hạn max; không tạo expected. | B-R07, B-R08; câu hỏi |
| B-EC-41 | Nội dung/câu chữ thông báo | Chưa kết luận về exact text | Empty state/dialog/toast có câu chữ khác nhau | Yêu cầu chỉ đòi thông báo rõ, dialog xác nhận hoặc phản hồi trực quan; chỉ chấm sự hiện diện/chức năng, không chấm nguyên văn. | B-R01, B-R09, B-R13 |

Không lớp nào trong B-EC-07, B-EC-09, B-EC-16, B-EC-19, B-EC-22, B-EC-33, B-EC-37–41 được gán Pass/Fail. Chúng chứa câu hỏi đặc tả hoặc đầu ra cần quan sát thêm.

##### 6. Vì sao các đại diện phân biệt được hành vi

- **Rỗng / một dòng / nhiều dòng** thay đổi cấu trúc đầu ra cần có: empty state, một record, hoặc danh sách nhiều record.
- **Cùng ID / ID khác** phân biệt yêu cầu gộp quantity khỏi trường hợp sản phẩm riêng; phép map ID sang “cùng sản phẩm” được đánh dấu là giả định vì SRS dùng khái niệm sản phẩm chứ không nêu khóa định danh.
- **Quantity 1 / 0 / âm / thập phân / không phải số** tách đúng biên số nguyên dương tối thiểu và kiểu dữ liệu tại ô nhập FR-06. API payload được đặt lớp riêng vì API spec không cho validation oracle.
- **Dialog đóng / mở / xác nhận / hủy** phân biệt chưa yêu cầu xóa, yêu cầu xác nhận, đã xác nhận và nhánh hủy. Nhánh hủy vẫn cần làm rõ trước khi chấm.
- **Các output cột, dòng trùng, thành tiền, label và empty state** tách những điều kiện có expected riêng trong SRS/phân công. Tổng giỏ và badge number giữ ở trạng thái câu hỏi khi nguồn không đủ.

Đây là tập lớp để review và chuẩn bị bước tiếp theo. Không liệt kê trình tự thao tác test, không thiết kế TC, không chạy SUT và không có kết quả thực thi/human review.

#### 03-domain-cases — B-FR07

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### Quy ước dữ liệu và chuẩn bị

- Tất cả ca là UI Web, trừ B-DT-020 exploratory API. API không thay thế ca giao diện.
- Fixture sản phẩm đã do người dùng cung cấp: P1 = iPhone 15 Pro Max, ID 1, đơn giá 30.000.000 VND; P2 = Samsung Galaxy S24 Ultra, ID 2, đơn giá 28.000.000 VND. Trước khi chạy, đối chiếu tên/ID/giá đang hiển thị bằng quan sát chỉ đọc. Nếu khác, sửa fixture trong ca. Không sửa/xóa sản phẩm mẫu.
- Dùng tài khoản kiểm thử riêng, không dùng admin/giỏ của người khác. Đăng nhập là tiền điều kiện, không thuộc expected của các ca. API spec yêu cầu Bearer token cho API cart; token không ghi vào log.
- Reset cho từng ca độc lập bằng UI: trong giỏ của tài khoản test, xóa và xác nhận chỉ các dòng P1/P2 do ca trước thêm, rồi kiểm tra số dòng. Không xóa bản ghi sản phẩm, không gọi API để reset. Nếu không xác định được dòng test hoặc không thể dọn qua UI, dừng ca; không đụng dữ liệu khác.
- Reload chỉ được dùng ở đầu một ca độc lập khi cần mở trang; không dùng reload làm thao tác reset và không reload giữa chuỗi. Vì persistence chưa rõ, luôn kiểm tra trạng thái thực sau khi mở.
- Khi chạy sau này, lưu ảnh trước/sau tại evidence/B-FR07/<TC-ID>/<Run-ID>/; ghi browser/OS/SUT commit, thời điểm, thao tác, input, output. Nếu có request, lưu response đã che token. Ảnh tính tiền cần thấy tên, đơn giá, quantity, thành tiền, nhãn và tổng.
- Với nút +/−, Xóa và dialog: trước hết kiểm tra control có mặt. Nếu thiếu, ghi nhận thiếu control, không giả sử để click; ca tương tác phụ thuộc được ghi Blocked khi execution.

##### B-DT-001 — Giỏ rỗng

- **Mục tiêu / requirement:** Empty state, B-R01.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Tài khoản test; reset qua UI; giỏ 0 dòng.
- **Dữ liệu:** Không có sản phẩm/giá/quantity.
- **Thao tác:** Mở Giỏ hàng; quan sát vùng nội dung, không thêm sản phẩm.
- **Expected:** Có hình minh họa và thông báo rõ giỏ rỗng; không kiểm câu chữ cụ thể (SRS FR-07).
- **EC:** B-EC-01, B-EC-24, B-EC-25.
- **Quan sát/evidence:** Ảnh toàn vùng empty state; ghi riêng có/không có hình và thông báo.

##### B-DT-002 — Một sản phẩm

- **Mục tiêu / requirement:** Một dòng và các cột giỏ, B-R02/B-R03/B-R13.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; P1 có trong catalog.
- **Dữ liệu:** P1 ID 1, 30.000.000 VND, nhập quantity 1 ở trang chi tiết.
- **Thao tác:** Trang chủ → mở chi tiết P1 → nhập 1 → bấm Thêm vào giỏ → quan sát phản hồi → mở Giỏ hàng.
- **Expected:** Một dòng P1, quantity 1; có cột Sản phẩm/Đơn giá/Số lượng/Thành tiền/Thao tác. Sau thêm thành công có toast hoặc badge cập nhật, một trong hai là đủ (FR-06/07).
- **EC:** B-EC-02, B-EC-06, B-EC-08, B-EC-10, B-EC-26, B-EC-28, B-EC-34.
- **Quan sát/evidence:** Ảnh input, phản hồi thêm, và dòng giỏ; ghi ID, tên, giá, quantity.

##### B-DT-003 — Hai sản phẩm khác nhau

- **Mục tiêu / requirement:** Nhiều dòng, B-R02.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; P1/P2 còn hiển thị.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1; P2 ID 2, 28.000.000, quantity 1.
- **Thao tác:** Thêm P1 qua chi tiết; điều hướng UI về danh sách; thêm P2; mở giỏ.
- **Expected:** Có hai sản phẩm/dòng khác nhau và các cột yêu cầu. Hai ID khác nhau là đại diện cho hai sản phẩm dựa trên API spec; quy tắc identity cần xác nhận nếu chấm số dòng theo ID.
- **EC:** B-EC-03, B-EC-05, B-EC-06, B-EC-10, B-EC-26, B-EC-28.
- **Quan sát/evidence:** Ảnh cả hai dòng và tên/ID/giá.

##### B-DT-004 — Thêm lại cùng sản phẩm, xác nhận gộp dòng

- **Mục tiêu / requirement:** B-R04.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; P1 còn hiển thị.
- **Dữ liệu:** P1 ID 1, 30.000.000; lần đầu quantity 1, lần hai quantity 2.
- **Thao tác:** Thêm P1 quantity 1 → điều hướng UI lại chi tiết P1 → nhập 2 → thêm lần hai → mở giỏ, đếm dòng và quantity.
- **Expected:** Chỉ một dòng P1 và quantity tăng từ 1 theo quantity thêm (diễn giải là tổng 3); không tạo dòng trùng (SRS FR-07). Cách map “cùng sản phẩm” với cùng ID và phép cộng cần xác nhận trước khi chấm chi tiết.
- **EC:** B-EC-04, B-EC-06, B-EC-10, B-EC-11, B-EC-27.
- **Quan sát/evidence:** Ảnh trước lần thêm thứ hai và sau; ghi số dòng và quantity.

##### B-DT-005 — Đơn giá, thành tiền dòng và tổng

- **Mục tiêu / requirement:** B-R02/B-R07/B-R08.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; rỗng; xác nhận fixture P1/P2.
- **Dữ liệu:** P1 30.000.000 × quantity 2; P2 28.000.000 × quantity 1.
- **Thao tác:** Thêm P1 quantity 2; thêm P2 quantity 1; mở giỏ; ghi đơn giá, quantity, thành tiền từng dòng, nhãn và tổng.
- **Expected có căn cứ:** Hai dòng có đơn giá; thành tiền P1 = 60.000.000 và P2 = 28.000.000 theo công thức phân công Thành viên 2; nhãn đúng “Tổng cộng” theo SRS FR-07.
- **Expected tổng:** Ghi giá trị tổng. 88.000.000 là candidate theo phép cộng thông thường, nhưng SRS không nêu rõ công thức tổng giỏ; không chấm đúng/sai tổng cho tới khi xác nhận. Không thêm phí/giảm giá/làm tròn.
- **EC:** B-EC-03, B-EC-08, B-EC-11, B-EC-26, B-EC-28–B-EC-33.
- **Quan sát/evidence:** Ảnh đủ hai dòng và vùng tổng; ghi phần expected trực tiếp riêng với tổng còn chờ oracle.

##### B-DT-006 — Kiểm tra nút cộng hiện diện

- **Mục tiêu / requirement:** B-R05, kiểm tra control trước ca phụ thuộc.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; chỉ P1 quantity 1 trong giỏ.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1.
- **Thao tác:** Mở giỏ; tìm nút + trên dòng P1; ghi có/không và enable/disable. Không click trong ca presence này.
- **Expected:** Nút + tồn tại để chỉnh quantity theo FR-07.
- **EC:** B-EC-17.
- **Quan sát/evidence:** Ảnh dòng hàng và nút quantity.
- **Phụ thuộc:** Nếu thiếu, ghi nhận vấn đề presence; B-DT-007 sẽ Blocked khi thực thi.

##### B-DT-007 — Tăng quantity bằng nút +

- **Mục tiêu / requirement:** B-R05/B-R07.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; P1 quantity 1; nút + hiện diện theo B-DT-006.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity trước 1.
- **Thao tác:** Mở giỏ; xác nhận control +; click một lần; ghi quantity/thành tiền.
- **Expected:** Quantity tăng. Nếu bước là +1 thì quantity 2 và thành tiền theo phân công là 60.000.000; FR-07 chưa nêu delta mỗi click, nên không chấm con số cụ thể nếu chưa review.
- **EC:** B-EC-17, B-EC-29.
- **Quan sát/evidence:** Ảnh trước/sau, quantity, đơn giá, thành tiền.
- **Phụ thuộc:** Nếu nút thiếu, Blocked; không thay bằng API hoặc nhập quantity trực tiếp.

##### B-DT-008 — Kiểm tra nút trừ hiện diện

- **Mục tiêu / requirement:** B-R06, kiểm tra control trước ca phụ thuộc.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; chỉ P1 quantity 2 trong giỏ.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 2.
- **Thao tác:** Mở giỏ; tìm nút −; ghi có/không và enable/disable. Không click trong ca presence này.
- **Expected:** Nút − tồn tại để chỉnh quantity theo FR-07.
- **EC:** B-EC-18/B-EC-19.
- **Quan sát/evidence:** Ảnh dòng P1 và control.
- **Phụ thuộc:** Nếu thiếu, B-DT-009/B-DT-010 sẽ Blocked khi execution.

##### B-DT-009 — Giảm quantity khi lớn hơn 1

- **Mục tiêu / requirement:** B-R06/B-R07.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; P1 quantity 2; nút − hiện diện theo B-DT-008.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity trước 2.
- **Thao tác:** Mở giỏ; xác nhận quantity 2; click − một lần; ghi quantity/thành tiền.
- **Expected:** Quantity giảm, không thấp hơn 1 theo minimum trong FR-06/phân công. Nếu delta là 1, kết quả quantity 1 và thành tiền 30.000.000; delta cần xác nhận trước khi chấm số cụ thể.
- **EC:** B-EC-18, B-EC-29.
- **Quan sát/evidence:** Ảnh trước/sau và giá trị từng cột.
- **Phụ thuộc:** Nếu nút thiếu, Blocked; không giả định control tồn tại.

##### B-DT-010 — Bấm nút trừ tại quantity 1

- **Mục tiêu / requirement:** Quan sát ngưỡng minimum mà không tự đặt policy.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; chỉ P1 quantity 1; nút − hiện diện.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1.
- **Thao tác:** Mở giỏ; ghi trạng thái nút −. Nếu enable, click một lần; nếu disable, chỉ ghi nhận, không click. Quan sát dòng/quantity/dialog.
- **Expected:** Chưa rõ nút bị disable, giữ quantity 1, hỏi xác nhận hay xóa dòng. Ghi observation; không chấm Pass/Fail cho outcome cho tới khi có oracle.
- **EC:** B-EC-19.
- **Quan sát/evidence:** Ảnh trước/sau, trạng thái nút và mọi dialog/thay đổi.
- **Phụ thuộc:** Nếu không có nút, presence đã kiểm ở B-DT-008; tương tác Blocked.

##### B-DT-011 — Mở dialog xóa rồi hủy

- **Mục tiêu / requirement:** B-R09 và nhánh B-R11 cần review.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; chỉ P1 quantity 1 trong giỏ.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1.
- **Thao tác:** Mở giỏ; xác nhận Xóa hiện diện; click Xóa; chụp dialog; nếu có Hủy thì click Hủy, nếu không có thì không tự giả định cách đóng; quan sát giỏ.
- **Expected:** Dialog phải xuất hiện trước khi xóa (SRS FR-07). Dự kiến P1 còn nguyên sau Hủy, nhưng SRS chưa nói rõ Cancel; giữ là expected cần review, không chấm cho tới khi xác nhận.
- **EC:** B-EC-20, B-EC-22, B-EC-37, B-EC-41.
- **Quan sát/evidence:** Ảnh trước click, dialog, sau hủy; ghi nguyên văn nút nếu có.
- **Phụ thuộc:** Nếu không có Xóa/dialog/Hủy, ghi đúng control thiếu và không chạy nhánh phụ thuộc.

##### B-DT-012 — Xác nhận xóa đúng dòng

- **Mục tiêu / requirement:** B-R09/B-R10.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; thêm P1 và P2, mỗi sản phẩm quantity 1; xác nhận hai dòng.
- **Dữ liệu:** P1 ID 1, 30.000.000 × 1; P2 ID 2, 28.000.000 × 1.
- **Thao tác:** Mở giỏ; tại dòng P1 click Xóa; xác nhận dialog; chọn Xác nhận; quan sát cả hai dòng.
- **Expected:** Có dialog trước xóa; P1 được chọn không còn sau xác nhận. P2 còn lại là diễn giải “xóa sản phẩm được chọn”; nếu cần chấm tác động lên dòng khác, xác nhận oracle trước.
- **EC:** B-EC-03, B-EC-20, B-EC-21, B-EC-36.
- **Quan sát/evidence:** Ảnh hai dòng trước, dialog và P2 còn lại sau; không xóa sản phẩm khỏi catalog.
- **Phụ thuộc:** Nếu Xóa/dialog/confirm thiếu, ghi presence/confirmation và không giả định thao tác.

##### B-DT-013 — Xác nhận xóa dòng cuối

- **Mục tiêu / requirement:** B-R10 rồi B-R01.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; thêm duy nhất P1 quantity 1.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1.
- **Thao tác:** Mở giỏ; click Xóa trên P1; xác nhận dialog; chọn Xác nhận; quan sát trạng thái rỗng.
- **Expected:** P1 dòng cuối bị xóa theo diễn giải thao tác Xóa; giỏ rỗng hiển thị hình minh họa và thông báo rõ theo FR-07.
- **EC:** B-EC-01, B-EC-20, B-EC-21, B-EC-24, B-EC-36.
- **Quan sát/evidence:** Ảnh dòng trước, dialog, empty state sau. Không xóa catalog item.
- **Phụ thuộc:** Nếu control/dialog thiếu thì không giả định để tiếp tục.

##### B-DT-014 — Tiếp tục mua sắm

- **Mục tiêu / requirement:** B-R12.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; thêm P1 quantity 1; đang ở trang Giỏ hàng.
- **Dữ liệu:** P1 ID 1, 30.000.000, quantity 1.
- **Thao tác:** Chụp trang giỏ; click Tiếp tục mua sắm; quan sát URL/trang đích.
- **Expected:** Có nút này và đưa người dùng về trang chủ (SRS FR-07). Không chấm persistence của giỏ sau điều hướng.
- **EC:** B-EC-23, B-EC-39.
- **Quan sát/evidence:** Ảnh trước/sau và URL/trang đích.

##### B-DT-015 — Nhãn “Tổng cộng”

- **Mục tiêu / requirement:** B-R08.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; thêm P1 quantity 1; mở giỏ.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000, quantity 1.
- **Thao tác:** Đi tới vùng tổng; ghi nguyên văn nhãn.
- **Expected:** Nhãn chính xác “Tổng cộng”, không phải “Tổng tạm tính”; không chấm phép tính giá trị tổng trong ca này (SRS FR-07).
- **EC:** B-EC-31/B-EC-32.
- **Quan sát/evidence:** Ảnh rõ nhãn và giá trị đi kèm.

##### B-DT-016 — Quantity bằng 0 tại ô nhập FR-06

- **Mục tiêu / requirement:** B-R13, input invalid duy nhất là quantity.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; mở trang chi tiết P1.
- **Dữ liệu:** P1 ID 1, 30.000.000; quantity 0; input khác hợp lệ.
- **Thao tác:** Focus ô Số lượng; nhập 0 và ghi giá trị/validation. Nếu control giữ 0, bấm Thêm một lần; nếu từ chối, không can thiệp DOM/API. Mở giỏ quan sát có quantity 0 được thêm không.
- **Expected:** 0 không được nhận làm quantity thêm theo FR-06 (số nguyên dương tối thiểu 1); wording/chặn cụ thể chưa được quy định.
- **EC:** B-EC-12.
- **Quan sát/evidence:** Ảnh input và giỏ; Network redacted nếu phát sinh request.

##### B-DT-017 — Quantity âm tại ô nhập FR-06

- **Mục tiêu / requirement:** B-R13, chỉ quantity sai miền.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; trang chi tiết P1.
- **Dữ liệu:** P1 ID 1, 30.000.000; quantity -1; input khác hợp lệ.
- **Thao tác:** Thử nhập -1 vào ô Số lượng; ghi giá trị/validation. Nếu control giữ giá trị thì bấm Thêm; nếu không giữ thì dừng quan sát. Mở giỏ kiểm tra.
- **Expected:** Số âm không phải số nguyên dương tối thiểu 1 nên không được nhận làm quantity thêm theo FR-06; không gọi API để thay UI.
- **EC:** B-EC-13.
- **Quan sát/evidence:** Ảnh input/giỏ; Network redacted nếu có request.

##### B-DT-018 — Quantity thập phân tại ô nhập FR-06

- **Mục tiêu / requirement:** B-R13, chỉ quantity sai miền.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; trang chi tiết P1.
- **Dữ liệu:** P1 ID 1, 30.000.000; quantity 1.5; input khác hợp lệ.
- **Thao tác:** Thử nhập 1.5; ghi giá trị/validation. Nếu control giữ thì bấm Thêm một lần; nếu từ chối thì không dùng script/API. Mở giỏ quan sát.
- **Expected:** Quantity thập phân không phải số nguyên, không được nhận theo FR-06; wording cụ thể chưa quy định.
- **EC:** B-EC-14.
- **Quan sát/evidence:** Ảnh input/giỏ; Network redacted nếu phát sinh request.

##### B-DT-019 — Quantity không phải số tại ô nhập FR-06

- **Mục tiêu / requirement:** B-R13, chỉ quantity sai kiểu.
- **Loại:** UI Web.
- **Điều kiện / giỏ đầu:** Reset UI; giỏ rỗng; trang chi tiết P1.
- **Dữ liệu:** P1 ID 1, 30.000.000; chuỗi abc; input khác hợp lệ.
- **Thao tác:** Thử nhập abc. Nếu control không nhận chữ, ghi đúng giá trị/validation và dừng; nếu nhận, bấm Thêm một lần. Mở giỏ quan sát.
- **Expected:** Nếu nhận được chuỗi, abc không được nhận làm số lượng theo FR-06. Nếu control ngăn gõ thì ghi observation; không thay bằng API.
- **EC:** B-EC-15.
- **Quan sát/evidence:** Ảnh ô quantity, giỏ; Network redacted nếu có request.

##### B-DT-020 — Thăm dò quantity thập phân qua API (chưa có oracle)

- **Mục tiêu:** Quan sát riêng API invalid; không thay thế UI case B-DT-018.
- **Loại:** API exploratory.
- **Điều kiện / giỏ đầu:** Test account riêng có token hợp lệ; reset giỏ qua UI trước request; P1 không bị sửa.
- **Dữ liệu:** POST /api/cart; body id=1, name="iPhone 15 Pro Max", price=30000000, quantity=1.5; chỉ quantity sai, trường khác khớp fixture.
- **Thao tác:** Xác nhận giỏ rỗng bằng UI; gửi một POST; lưu response redacted; mở giỏ qua UI quan sát; nếu có dòng test thì dọn qua UI.
- **Expected:** Chưa có oracle: API spec liệt kê quantity nhưng không định nghĩa validation; FR-06 nói về ô UI. Chỉ ghi observation, không Pass/Fail.
- **EC:** B-EC-16.
- **Quan sát/evidence:** Request/response, timestamp, ảnh giỏ trước/sau; không lưu token.

##### Giới hạn

- Không xóa/sửa sản phẩm catalog hoặc dữ liệu mẫu.
- Reset giỏ chỉ bằng thao tác UI; reload không được dùng giữa chuỗi hay làm cách reset.
- B-DT-005 có expected line amount theo phân công; tổng 88.000.000 là candidate cần xác nhận, không tự chấm.
- B-DT-010, nhánh Hủy ở B-DT-011, một số delta +/- và API B-DT-020 cần làm rõ. Nếu control không tồn tại, ghi presence riêng và đánh dấu tương tác phụ thuộc Blocked ở bước execution.
- File này chỉ chứa thiết kế: không có actual, status, ảnh/log chạy hoặc human review.

#### 04-boundary-cases — B-FR07

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.
**Phạm vi:** Thiết kế BVA từ FR-06/FR-07 và phân công Thành viên 2; chưa chạy SUT, không có actual/status.

##### Căn cứ và cách chọn biên

- FR-06 quy định ô nhập số lượng chỉ nhận số nguyên dương, tối thiểu là 1. Do quantity là số nguyên, bước nhỏ nhất quanh lower boundary là **δ = 1 đơn vị**: `LB−δ = 0`, `LB = 1`, `LB+δ = 2`.
- **Không có UB được nêu** cho quantity trong FR-06/FR-07 hoặc phân công Thành viên 2. Không dùng giá trị tùy đặt như 99/100 và không suy ra giới hạn từ tồn kho. Vì không có UB, không thiết kế ca `UB−1/UB/UB+1`.
- Giá trị `0` chỉ được thử tại ô nhập quantity nếu có thể nhập bằng thao tác người dùng. Không ép giá trị qua DOM, script hoặc API. Số âm/thập phân không phải là các ca nhập trực tiếp trong tài liệu BVA này: control có thể không nhận các kiểu/giá trị đó; chúng đã được đặt riêng trong Domain cases theo khả năng nhập của UI.
- Nút `+`/`−` là thao tác trạng thái, không phải ô nhập số. BVA của chúng được biểu diễn bằng quantity trước thao tác gần LB. SRS không nêu delta mỗi click; vì vậy chỉ kỳ vọng chiều thay đổi được yêu cầu, còn giá trị chính xác cần oracle bổ sung. Giảm từ 1 là transition riêng, chưa đặt expected cho cách xử lý.
- SRS không đặt giới hạn số dòng giỏ. Dùng một và nhiều dòng làm trạng thái đại diện theo Domain testing, không gọi chúng là biên hoặc UB.
- Công thức thành tiền `đơn giá × quantity` lấy từ phân công nhóm. Với P1 có giá đã biết 30.000.000 VND: q=1 → 30.000.000; q=2 → 60.000.000. Đây là kiểm tra thành tiền dòng; không dùng để tự suy ra công thức tổng giỏ.

##### Chuẩn bị độc lập và bằng chứng

1. Dùng tài khoản kiểm thử riêng đã đăng nhập. Kiểm tra bằng giao diện, chỉ đọc, fixture P1: iPhone 15 Pro Max, ID 1, giá 30.000.000 VND. Không sửa/xóa sản phẩm mẫu.
2. Bắt đầu mỗi TC ở trạng thái độc lập. Dọn giỏ qua UI bằng cách xóa và xác nhận chỉ các dòng P1/P2 do ca trước thêm; mở giỏ và kiểm tra đúng số dòng. Không dùng API/DB để reset.
3. Chỉ reload khi bắt đầu một ca độc lập nếu cần mở lại trang; không reload giữa chuỗi. Persistence của giỏ chưa được quy định.
4. Lưu ảnh/ghi nhận tại `evidence/B-FR07/<TC-ID>/<Run-ID>/`: trang nhập trước thao tác, giá trị đang hiển thị, thông báo nếu có, giỏ sau thao tác, tên/ID/đơn giá/quantity/thành tiền. Ghi môi trường và SUT commit khi thực thi. Nếu control không cho nhập giá trị yêu cầu, lưu ảnh và ghi observation về giới hạn control; không giả lập bằng cách khác.
5. Tính expected thành tiền bằng phép nhân giá fixture với quantity kỳ vọng/quan sát được. Không đánh giá tổng giỏ trong các ca này.

##### Các ca BVA

###### B-BV-001 — Ô nhập tại LB−δ: quantity 0

- **Mục tiêu:** Kiểm tra dưới lower boundary của ô nhập quantity FR-06.
- **Loại:** UI Web — nhập trực tiếp ở trang chi tiết sản phẩm.
- **Biên / δ:** `LB=1`, `δ=1`, giá trị `LB−δ=0`.
- **Requirement / lớp:** B-R13; B-EC-12; liên quan Domain case B-DT-016.
- **Điều kiện / giỏ đầu:** Giỏ rỗng đã xác nhận qua UI; P1 có trong catalog.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity nhập `0`.
- **Thao tác:** Mở chi tiết P1 → focus ô Số lượng → thử nhập `0` → ghi giá trị thực sự hiển thị và validation → chỉ bấm “Thêm vào giỏ hàng” nếu UI giữ giá trị 0 và cho thao tác bằng giao diện → mở giỏ.
- **Expected:** Quantity 0 không được chấp nhận làm quantity thêm vì FR-06 yêu cầu số nguyên dương tối thiểu 1. Cách chặn/thông báo chưa được quy định. Nếu control không nhận/không cho submit, ghi nhận đây là cách UI chặn; không ép submit.
- **Quan sát / bằng chứng:** Ảnh ô nhập và validation; nếu submit được, ảnh giỏ sau đó xác nhận không có dòng P1 quantity 0. Lưu mọi request/response phát sinh đã che token nếu được quan sát.

###### B-BV-002 — Ô nhập tại LB: quantity 1

- **Mục tiêu:** Kiểm tra đúng lower boundary hợp lệ.
- **Loại:** UI Web — nhập trực tiếp ở trang chi tiết sản phẩm.
- **Biên / δ:** `LB=1`, giá trị `LB`; điểm kề trên là `LB+δ=2` ở B-BV-003.
- **Requirement / lớp:** B-R03/B-R07/B-R13; B-EC-10/B-EC-29; liên quan B-DT-002.
- **Điều kiện / giỏ đầu:** Giỏ rỗng đã xác nhận qua UI; P1 có trong catalog.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity nhập `1`.
- **Thao tác:** Mở chi tiết P1 → nhập `1` → xác nhận UI hiển thị 1 → bấm “Thêm vào giỏ hàng” → mở giỏ.
- **Expected:** Giá trị 1 hợp lệ theo FR-06; giỏ có P1 quantity 1. Thành tiền dòng `30.000.000 × 1 = 30.000.000 VND` theo công thức phân công.
- **Quan sát / bằng chứng:** Ảnh giá trị nhập, phản hồi thêm hàng và dòng giỏ gồm tên, đơn giá, quantity, thành tiền.

###### B-BV-003 — Ô nhập tại LB+δ: quantity 2

- **Mục tiêu:** Kiểm tra điểm hợp lệ liền kề phía trên lower boundary.
- **Loại:** UI Web — nhập trực tiếp ở trang chi tiết sản phẩm.
- **Biên / δ:** `LB=1`, `δ=1`, giá trị `LB+δ=2`. Đây không phải UB.
- **Requirement / lớp:** B-R03/B-R07/B-R13; B-EC-11/B-EC-29; liên quan B-DT-005.
- **Điều kiện / giỏ đầu:** Giỏ rỗng đã xác nhận qua UI; P1 có trong catalog.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity nhập `2`.
- **Thao tác:** Mở chi tiết P1 → nhập `2` → xác nhận UI hiển thị 2 → bấm “Thêm vào giỏ hàng” → mở giỏ.
- **Expected:** Giá trị 2 là số nguyên dương nên hợp lệ theo FR-06; giỏ có P1 quantity 2. Thành tiền dòng `30.000.000 × 2 = 60.000.000 VND` theo công thức phân công.
- **Quan sát / bằng chứng:** Ảnh giá trị nhập, phản hồi thêm hàng và dòng giỏ với đơn giá/quantity/thành tiền.

###### B-BV-004 — Nút giảm từ 2 về phía lower boundary

- **Mục tiêu:** Kiểm tra transition nút `−` khi quantity ở sát trên mức tối thiểu.
- **Loại:** UI Web — thao tác nút, không nhập số trực tiếp.
- **Biên / δ:** Trạng thái ban đầu q=2=`LB+δ`; thao tác hướng về LB=1. Delta mỗi click chưa được SRS định nghĩa.
- **Requirement / lớp:** B-R06/B-R07; B-EC-18/B-EC-29; liên quan B-DT-008/B-DT-009.
- **Điều kiện / giỏ đầu:** Ca độc lập; giỏ chỉ có P1 quantity 2, được tạo qua trang chi tiết; nút `−` đã được kiểm tra hiện diện.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity trước 2.
- **Thao tác:** Mở giỏ → xác nhận P1 có quantity 2 và nút `−` hiện diện → click `−` đúng một lần → ghi quantity sau thao tác và thành tiền.
- **Expected:** FR-07 yêu cầu nút `−` chỉnh quantity xuống; quantity sau thao tác phải thấp hơn 2 nếu thao tác được chấp nhận. Không kết luận trước rằng một click phải cho đúng 1 vì bước thay đổi chưa được nêu. Với quantity sau là q, expected thành tiền theo phân công là `30.000.000 × q`; quantity không được giả định dưới 1 theo quy tắc tối thiểu ở FR-06/phân công. Chi tiết ngưỡng trong giỏ cần review.
- **Quan sát / bằng chứng:** Ảnh trước/sau; ghi rõ nút có/enable, q trước/sau, đơn giá và thành tiền. Nếu nút không tồn tại, dừng tương tác và ghi nhận presence; không thay bằng API.

###### B-BV-005 — Nút giảm tại lower boundary q=1

- **Mục tiêu:** Quan sát transition đúng tại mức tối thiểu khi người dùng bấm `−`.
- **Loại:** UI Web — thao tác nút, không nhập số trực tiếp.
- **Biên / δ:** q=LB=1; phép giảm một đơn vị nếu áp dụng sẽ đi tới `LB−δ=0`, là giá trị không hợp lệ ở ô nhập FR-06. Quy tắc xử lý nút tại đây chưa được SRS định nghĩa.
- **Requirement / lớp:** B-R06 (expected chưa rõ); B-EC-19; liên quan B-DT-010.
- **Điều kiện / giỏ đầu:** Ca độc lập; giỏ chỉ có P1 quantity 1; nút `−` hiện diện.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity trước 1.
- **Thao tác:** Mở giỏ → xác nhận q=1 → ghi trạng thái enable/disable của nút `−`. Nếu disable thì không click. Nếu enable thì click một lần, quan sát quantity/dòng/dialog sau đó; không lặp click.
- **Expected:** Chưa có oracle để chọn giữa disable, giữ ở 1, hỏi xác nhận xóa hoặc xóa dòng. Chỉ ghi nhận quan sát; không gán kết quả Pass/Fail. Nếu quantity/dòng còn lại, phép tính thành tiền quan sát được đối chiếu bằng `30.000.000 × q`, nhưng không giải quyết câu hỏi hành vi.
- **EC / liên quan:** B-EC-19; B-DT-010; B-R06.
- **Quan sát / bằng chứng:** Ảnh trước/sau, enable state, dialog nếu có, quantity/dòng còn lại và thành tiền.

###### B-BV-006 — Nút tăng tại lower boundary q=1

- **Mục tiêu:** Kiểm tra transition nút `+` từ mức tối thiểu.
- **Loại:** UI Web — thao tác nút, không nhập số trực tiếp.
- **Biên / δ:** Trạng thái ban đầu q=LB=1; tăng hướng vào miền hợp lệ. Không có UB được nêu.
- **Requirement / lớp:** B-R05/B-R07; B-EC-17/B-EC-29; liên quan B-DT-006/B-DT-007.
- **Điều kiện / giỏ đầu:** Ca độc lập; giỏ chỉ có P1 quantity 1; nút `+` hiện diện.
- **Dữ liệu:** P1 ID 1, đơn giá 30.000.000 VND; quantity trước 1.
- **Thao tác:** Mở giỏ → xác nhận q=1 và nút `+` hiện diện → click `+` một lần → ghi q sau và thành tiền.
- **Expected:** FR-07 yêu cầu nút `+` chỉnh quantity lên; q sau phải lớn hơn 1 nếu thao tác được chấp nhận. SRS không nêu delta một click, do đó không khẳng định q sau đúng 2. Thành tiền theo phân công được tính là `30.000.000 × q sau`. Không kiểm tra điểm dừng trên vì không có UB được nêu.
- **Quan sát / bằng chứng:** Ảnh trước/sau, trạng thái control, q trước/sau, đơn giá và thành tiền. Nếu nút thiếu, ghi nhận presence và không tương tác bằng cách khác.

##### Phạm vi không được gọi là biên

- **Số dòng giỏ:** Không có lower/upper limit về số dòng được nêu. Ca giỏ một dòng và hai dòng khác nhau trong Domain cases là đại diện cấu trúc, không phải biên số dòng.
- **Tổng tiền:** Dùng ca kiểm tra thành tiền dòng trong B-BV-002/003/004–006 theo công thức có nguồn ở phân công. Tổng giỏ không có công thức đầy đủ trong SRS; không tạo biên hay expected tổng tiền ở đây.
- **Giá trị nhập ngoài miền khác:** Số âm, thập phân và chuỗi không phải số chỉ thử nếu ô UI thực sự nhận được bằng thao tác người dùng; chúng thuộc Domain cases, không tự xem là các điểm biên số nguyên. Không gửi chúng vào control `+`/`−`.

Tài liệu này chỉ thiết kế ca BVA. Chưa chạy SUT và chưa ghi actual/status hoặc kết quả.

### C-FR14 — thiết kế đầy đủ

#### 01-requirements — C-FR14

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### 1. Phạm vi và nguồn expected result

| Nguồn | Nội dung dùng trong tài liệu |
|---|---|
| `eshop-sut/README.md`, FR-14 | Admin có thể thêm, xem, xóa danh mục; tên danh mục bắt buộc, không được để trống. |
| `eshop-sut/README.md`, FR-12 | Phân hệ Admin chỉ dành cho role admin; các API ghi `/api/categories` phải yêu cầu JWT hợp lệ và role admin trong token. |
| `eshop-sut/api_specification.md`, mục 3.4 | `GET /api/categories`, `POST /api/categories` với body `{"name":"Tên DM"}`, `PUT /api/categories/:id`, `DELETE /api/categories/:id`. Mục này không nêu response mẫu hoặc HTTP status. |
| `group_feature_assignment.md`, Pool C — Thành viên 2 | FR-14; input tên danh mục; xét tên rỗng, chỉ khoảng trắng, tên hợp lệ; thêm và xóa. Đây là phân công kiểm thử, không bổ sung chính sách trim chưa có trong SRS. |
| Slide [`domain-testing-vn.pdf`](../slide/domain-testing-vn.pdf) và [`domain-testing-en.pdf`](../slide/domain-testing-en.pdf) | Phương pháp xác định input/output từ đặc tả và phân biệt các lớp dữ liệu; slide là phương pháp, không đặt thêm expected nghiệp vụ. |

##### 2. Input, trạng thái và output cần quan sát

| ID | Input / trạng thái | Ý nghĩa |
|---|---|---|
| C-I01 | Tên danh mục | Tên nhập khi Admin thêm danh mục. FR-14 chỉ nói tên bắt buộc và không được để trống. |
| C-I02 | JWT | Token gửi trong `Authorization: Bearer <token>` khi gọi API ghi. FR-12 yêu cầu token hợp lệ. |
| C-I03 | Role trong token | FR-12 yêu cầu `role = 'admin'` cho các API ghi danh mục. |
| C-I04 | Category ID | ID trong đường dẫn `DELETE /api/categories/:id` để chỉ định danh mục cần xóa. API specification cũng liệt kê ID ở endpoint PUT, nhưng PUT không thuộc yêu cầu FR-14. |
| C-S01 | Danh sách danh mục trước thao tác | Ghi nhận danh sách hiện có để đối chiếu sau thêm/xóa; không sửa hoặc xóa dữ liệu mẫu khi chưa được phép. |
| C-S02 | Danh tính/role phiên Admin | Phân hệ Admin dành cho tài khoản có role admin (FR-12). Token có thể là input API; giao diện dùng trạng thái đăng nhập tương ứng. |

**Output quan sát được:**

- **Admin Web:** có thể thao tác thêm, xem danh sách và xóa danh mục với vai trò Admin; quan sát tên/danh sách trước và sau thao tác cùng phản hồi giao diện nếu có. SRS/API không quy định câu chữ cụ thể cho phản hồi.
- **API:** danh sách từ `GET /api/categories`; thao tác thêm qua `POST /api/categories` với trường `name`; thao tác xóa qua `DELETE /api/categories/:id`. Ghi lại HTTP status/body thực tế khi kiểm thử sau này, nhưng hiện không đặt status/body làm expected vì hợp đồng không quy định.
- **Trạng thái:** sau khi thêm hợp lệ, danh mục mới được kỳ vọng xuất hiện trong danh sách; sau khi xóa một danh mục, danh mục được chọn được kỳ vọng không còn trong danh sách. Đây là hệ quả trực tiếp của các thao tác Thêm/Xem/Xóa; cần theo dõi đúng category ID và các danh mục còn lại.
- **Input tên để trống:** không tạo danh mục với tên để trống theo FR-14. Cách hiển thị lỗi, status HTTP và việc giữ nguyên form chưa được nêu.

##### 3. Yêu cầu có mã

###### C-R01 — Phân hệ danh mục dành cho Admin

- **Yêu cầu:** Thao tác quản lý danh mục trong phân hệ Admin dành cho người dùng có `role = 'admin'` (SRS FR-12).
- **Input/trạng thái:** danh tính và role của phiên đăng nhập.
- **Trạng thái:** trước khi vào thao tác, phiên có role admin hoặc role khác/chưa đăng nhập; trạng thái danh mục cần được ghi nhận.
- **Output quan sát:** khả năng truy cập/hiển thị khu vực Admin và các chức năng danh mục. SRS không quy định cách chuyển hướng hoặc thông báo cho tài khoản không phải admin.
- **Nguồn expected:** `eshop-sut/README.md`, FR-12.

###### C-R02 — Admin thêm danh mục

- **Yêu cầu:** Admin có thể thêm một danh mục (SRS FR-14).
- **Input:** tên danh mục; đối với API là `POST /api/categories` với body có trường `name`; JWT hợp lệ với role admin theo C-R06.
- **Trạng thái trước/sau:** ghi danh sách trước; sau thao tác thêm hợp lệ, danh mục mới được kỳ vọng xuất hiện trong danh sách.
- **Output quan sát:** Admin Web cập nhật danh sách/phản hồi; API status/body và kết quả `GET /api/categories` được ghi nhận như actual. Status/body thành công cụ thể chưa có oracle.
- **Nguồn expected:** `eshop-sut/README.md`, FR-14 và `api_specification.md`, mục 3.4.

###### C-R03 — Admin xem danh sách danh mục

- **Yêu cầu:** Admin có thể xem danh sách danh mục (SRS FR-14).
- **Input:** phiên Admin; API endpoint `GET /api/categories`.
- **Trạng thái trước/sau:** không yêu cầu thay đổi danh mục; trạng thái dữ liệu giữ nguyên.
- **Output quan sát:** danh sách danh mục trong Admin Web và dữ liệu trả về từ API; hợp đồng không định nghĩa schema/field hoặc thứ tự danh sách.
- **Nguồn expected:** `eshop-sut/README.md`, FR-14; `api_specification.md`, mục 3.4.
- **Điểm cần review:** FR-12 nói phân hệ Admin chỉ dành cho role admin, nhưng không nói rõ `GET /api/categories` (endpoint dùng chung ở mục 3.4) có bắt buộc JWT/role admin hay không. Không tự đặt yêu cầu phân quyền cho GET nếu chưa làm rõ.

###### C-R04 — Admin xóa danh mục được chọn

- **Yêu cầu:** Admin có thể xóa danh mục (SRS FR-14).
- **Input:** category ID được chọn; API `DELETE /api/categories/:id`; JWT hợp lệ với role admin theo C-R06.
- **Trạng thái trước/sau:** ghi danh sách và ID trước thao tác; sau khi xóa thành công, danh mục có ID được chọn được kỳ vọng không còn trong danh sách. Các danh mục khác cần được đối chiếu để phát hiện thay đổi ngoài mục tiêu.
- **Output quan sát:** phản hồi thao tác trên Admin Web/API và danh sách sau xóa. HTTP status, body, dialog xác nhận hoặc xử lý ID không tồn tại chưa được đặc tả.
- **Nguồn expected:** `eshop-sut/README.md`, FR-14; endpoint theo `api_specification.md`, mục 3.4.

###### C-R05 — Tên danh mục không được để trống

- **Yêu cầu:** Không chấp nhận thêm danh mục có tên để trống (SRS FR-14).
- **Input:** trường tên danh mục rỗng; input còn lại hợp lệ; API request dùng trường `name`.
- **Trạng thái trước/sau:** ghi danh sách trước; khi tên để trống, danh mục không được thêm vào danh sách.
- **Output quan sát:** UI validation/feedback hoặc API response và danh sách sau thao tác. Câu chữ thông báo, HTTP status/body và chi tiết phân biệt chuỗi rỗng với các loại khoảng trắng chưa được quy định.
- **Nguồn expected:** `eshop-sut/README.md`, FR-14. Phân công Thành viên 2 gợi ý xét chuỗi rỗng và chuỗi khoảng trắng, nhưng không xác định policy trim.

###### C-R06 — API ghi danh mục yêu cầu JWT hợp lệ và role admin

- **Yêu cầu:** Các thao tác ghi qua `/api/categories` phải có JWT hợp lệ và token có `role = 'admin'` (SRS FR-12). Trong phạm vi FR-14, thao tác ghi là POST thêm và DELETE xóa.
- **Input:** token hợp lệ/admin; token hợp lệ nhưng role khác; thiếu token; token không hợp lệ. Với POST/DELETE, body hoặc category ID tương ứng.
- **Trạng thái trước/sau:** với token admin hợp lệ, đánh giá theo C-R02/C-R04. Với thiếu/sai token hoặc role không phải admin, thao tác ghi không được làm thay đổi danh sách; response status/body cụ thể chưa có oracle.
- **Output quan sát:** kết quả API và đối chiếu danh sách trước/sau; nếu thao tác qua Admin Web, ghi trạng thái truy cập/phản hồi mà không đặt câu chữ cụ thể.
- **Nguồn expected:** `eshop-sut/README.md`, FR-12; API endpoints tại `api_specification.md`, mục 3.4 và quy tắc Bearer token ở mục 6 cho các API Admin được liệt kê ở phần đó.

##### 4. Phạm vi và điểm chưa rõ cần review

- **FR-14 không yêu cầu sửa danh mục.** Dù API specification liệt kê `PUT /api/categories/:id` và tên FR-14 ghi “CRUD”, yêu cầu mô tả chỉ nêu Thêm/Xem/Xóa. Không đưa Edit/PUT vào phạm vi kiểm thử FR-14 nếu chưa có yêu cầu bổ sung.
- **Không tự thêm uniqueness:** SRS không nói tên danh mục phải duy nhất.
- **Không tự thêm giới hạn độ dài 255:** giới hạn 255 ký tự nằm ở FR-15 cho tên sản phẩm, không áp dụng sang tên danh mục.
- **Không tự quy định trim:** FR-14 không nói có trim khoảng trắng ở đầu/cuối hay chuỗi toàn khoảng trắng có được xem là rỗng. Phân công gợi ý lớp chuỗi chỉ có khoảng trắng nhưng expected cần được xác nhận.
- **Không tự đặt chính sách xóa category đang được sản phẩm tham chiếu:** SRS/API contract không nói chặn xóa, xóa dây chuyền, đổi tham chiếu hay phản hồi thế nào.
- **Không tự đặt HTTP status/body:** API specification liệt kê endpoint/body tạo danh mục nhưng không quy định response cho thành công, validation hoặc lỗi quyền.
- **GET authorization chưa rõ:** FR-12 nêu các API Admin và các API ghi ảnh hưởng dữ liệu; cần xác nhận GET `/api/categories` dùng chung có cần JWT/admin không.
- **Category ID:** API dùng `:id` cho xóa; hành vi ID không tồn tại/không hợp lệ chưa được quy định.
- **Dialog xác nhận xóa:** FR-14 chỉ yêu cầu Admin xóa; không yêu cầu rõ dialog xác nhận, nên không đặt dialog làm expected.
- **Giới hạn phạm vi:** Pool C — FR-14 thuộc Thành viên 2. Không mở rộng sang FR-15 quản lý sản phẩm, FR-17 coupon hoặc thao tác sửa danh mục ngoài FR-14.

Tài liệu này chỉ phân tích yêu cầu. Chưa tạo EC/test case, chưa chạy SUT và chưa ghi nhận review/phê duyệt của sinh viên.

#### 02-domains — C-FR14

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### 1. Căn cứ và quy ước

Expected dựa trên `01-requirements.md`, SRS FR-14/FR-12 trong `eshop-sut/README.md`, và endpoint trong `eshop-sut/api_specification.md`. Slide Domain/BVA được dùng để chia đầu vào/trạng thái thành các lớp có hành vi tương tự và chọn đại diện; slide không bổ sung quy tắc nghiệp vụ.

- C-R02/C-R05 áp dụng khi thêm danh mục; C-R03 khi xem; C-R04 khi xóa; C-R06 cho quyền của thao tác API ghi.
- FR-12 ràng buộc **POST/DELETE** danh mục: JWT hợp lệ và role admin. Không chuyển ràng buộc đó thành điều kiện cấm người dùng thường/khách gọi **GET** danh sách, vì SRS không nói điều này cho `GET /api/categories`.
- “Không hợp lệ” chỉ dùng khi requirement cho expected rõ. Trường hợp thiếu oracle được ghi **cần xác định/thăm dò**, không gán Pass/Fail.
- Không giả định uniqueness, giới hạn độ dài, trim, mã HTTP hay chính sách xóa danh mục đang được sản phẩm tham chiếu.

##### 2. Các lớp tương đương

| EC ID | Input/trạng thái và lớp | Đại diện cụ thể | Expected theo nguồn | Output/state cần quan sát | Requirement |
|---|---|---|---|---|---|
| **C-EC-01** | **Tên rỗng** — không hợp lệ khi thêm | UI để trống; API `POST /api/categories` body `{"name":""}` | Không tạo danh mục vì FR-14 nói tên bắt buộc, không được để trống. Câu chữ lỗi và HTTP status/body chưa có expected. | So sánh danh sách trước/sau; quan sát validation hoặc API response mà không chấm status/message. | C-R02, C-R05 |
| **C-EC-02** | **Tên không rỗng gồm ASCII** — lớp tên có giá trị | `Do uong test C` | FR-14 chỉ yêu cầu tên không rỗng và không nêu giới hạn ký tự; theo yêu cầu hiện có, đây là đại diện tên có giá trị để thêm. Không suy ra giới hạn độ dài/duy nhất. | Sau thao tác với quyền hợp lệ, kiểm tra tên và danh mục mới trong danh sách; ghi response thực tế. | C-R02, C-R05, C-R06 |
| **C-EC-03** | **Tên không rỗng có Unicode/dấu** — lớp tên có giá trị, kiểm tra dữ liệu ký tự | `Đồ uống thử nghiệm` | FR-14 không giới hạn bảng chữ cái; tên không rỗng thuộc miền có giá trị. Không đặt expected về chuẩn hóa Unicode hay cách sắp xếp. | Quan sát tên gửi/hiển thị/đọc lại có được giữ; đối chiếu danh sách. Quy tắc chuẩn hóa/encoding chi tiết chưa được nêu. | C-R02, C-R05 |
| **C-EC-04** | **Chỉ có khoảng trắng** — lớp cần xác định, không xếp hợp lệ/không hợp lệ trước | UI nhập ba dấu cách `"   "`; API body `{"name":"   "}` | Chưa kết luận. FR-14 không định nghĩa “để trống” đối với whitespace-only và không quy định trim. Phân công Thành viên 2 yêu cầu xét lớp này nhưng không cung cấp oracle. | Ghi chính xác input, phản hồi UI/API, danh sách trước/sau; kết quả chỉ là observation cho tới khi có quyết định yêu cầu. | C-R05 |
| **C-EC-05** | **Danh sách rỗng** — trạng thái dữ liệu không có category | `GET /api/categories` trả danh sách rỗng theo observation; hoặc Admin Web ở trạng thái không có danh mục | C-R03 yêu cầu xem danh sách; expected ở mức nghiệp vụ là danh sách không có category. Câu chữ/empty illustration và schema/status HTTP không được quy định. Không giả định cách tạo trạng thái rỗng. | Ghi danh sách trên Admin/API, response body/status thực tế; đảm bảo chỉ quan sát, không xóa dữ liệu thật để tạo lớp. | C-R03 |
| **C-EC-06** | **Danh sách có danh mục** — trạng thái dữ liệu có ít nhất một category | Một category hiện có hoặc category test vừa tạo; ghi ID/tên cụ thể trong lần test sau | C-R03 yêu cầu có thể xem danh sách; category hiện có cần được liệt kê. Không đặt thứ tự, schema field hoặc phân quyền GET ngoài điều nguồn nói. | So sánh tên/ID trong Web với dữ liệu GET; lưu trạng thái không đổi sau GET. | C-R03 |
| **C-EC-07** | **Category ID vừa tạo, hiện tồn tại** — target hợp lệ, an toàn hơn nếu là fixture do test tạo | Tạo tên duy nhất cho run, lấy ID qua API/Web, rồi dùng đúng ID ở bước xóa trong thiết kế sau | C-R04 cho phép Admin xóa category; với ID đang tồn tại, category được chọn được kỳ vọng biến mất sau thao tác xóa thành công. Chỉ dùng ID test; không đặt dialog/status. | Ghi ID, tên và danh sách trước/sau. Nếu thao tác thực tế, giữ các danh mục mẫu nguyên vẹn. | C-R04, C-R06 |
| **C-EC-08** | **Category ID đã tồn tại trước test** — target tồn tại nhưng có thể là dữ liệu mẫu | ID/tên đã được xác minh từ danh sách trước đó; không xóa trong kiểm thử nếu chưa được phép | Category tồn tại thuộc lớp ID có thể định danh. SRS không phân biệt category mẫu và test khi xóa; không được xem lớp này là an toàn để xóa dữ liệu thật. | Quan sát/ghi ID, tên và tham chiếu sản phẩm nếu có căn cứ; chỉ dùng để đọc hoặc lập kế hoạch, không xóa khi chưa được phép. | C-R03, C-R04 |
| **C-EC-09** | **Category ID không tồn tại/không xác định** — xử lý chưa đủ oracle | Ví dụ số ID được xác nhận không nằm trong danh sách; giá trị cần chọn sau khi quan sát dataset | API có đường dẫn `DELETE /api/categories/:id`, nhưng SRS/API không quy định phản hồi cho ID không tồn tại. Không kết luận status, message hay behavior; chỉ thăm dò nếu an toàn. | Ghi request/response và đối chiếu danh sách trước/sau. Không dùng ID mẫu hoặc suy ra expected lỗi cụ thể. | C-R04, C-R06 |
| **C-EC-10** | **Role admin + JWT hợp lệ** — lớp quyền được phép cho API ghi | Token còn hiệu lực lấy từ phiên admin đã xác thực; không lưu token vào evidence | FR-12 yêu cầu JWT hợp lệ và role admin; POST/DELETE được phép đi vào chức năng theo C-R02/C-R04. API spec không định nghĩa status/body thành công. | Lưu request đã che token; quan sát response và xác minh state theo thao tác. | C-R02, C-R04, C-R06 |
| **C-EC-11** | **Role user thường + JWT hợp lệ** — lớp quyền không đủ | Token còn hiệu lực của tài khoản role user | FR-12 yêu cầu role admin; user thường không được phép làm thay đổi danh mục bằng POST/DELETE. Expected chỉ là không thay đổi state; mã HTTP/message chưa quy định. | So sánh danh sách trước/sau; lưu response đã che token. Thử trên POST/DELETE an toàn, không nhắm tới dữ liệu mẫu để xóa. | C-R06 |
| **C-EC-12** | **Thiếu token** — lớp xác thực không hợp lệ cho ghi | POST/DELETE không có header Authorization | FR-12 yêu cầu JWT hợp lệ; không có token không đáp ứng điều kiện, nên thao tác ghi không được làm thay đổi danh sách. Response cụ thể chưa có oracle. | Ghi response/status như actual; xác nhận không đổi danh sách. | C-R06 |
| **C-EC-13** | **Token sai định dạng/không hợp lệ** — lớp xác thực không hợp lệ | Header Bearer chứa chuỗi không phải JWT hợp lệ, ví dụ `Bearer not-a-valid-token` | Không đáp ứng yêu cầu JWT hợp lệ ở FR-12; không được làm thay đổi danh sách. Không chấm status/body. | Ghi response thực tế và so sánh danh sách trước/sau; không ghi token thật. | C-R06 |
| **C-EC-14** | **Token hết hạn** — lớp xác thực không hợp lệ | JWT có thời hạn đã qua, nếu có thể tạo/lấy an toàn | Token hết hạn không còn hợp lệ theo yêu cầu JWT hợp lệ của FR-12; POST/DELETE không được làm thay đổi danh sách. Cách trả lỗi chưa quy định. | Ghi thời điểm/token test đã che, response và danh sách trước/sau. Không dùng token cá nhân trong tài liệu. | C-R06 |
| **C-EC-15** | **GET danh sách với các trạng thái đăng nhập khác nhau** — quyền GET cần phân biệt với ghi | Gọi `GET /api/categories` lần lượt với admin, user thường và không token nếu có thể; hoặc quan sát danh sách công khai | FR-14 cho phép xem danh sách; FR-12 nói phân hệ Admin chỉ dành cho role admin nhưng không nói rõ GET `/api/categories` dùng chung có cần token/admin hay không. Không đặt expected từ chối user/khách; đây là câu hỏi/thăm dò. Với Admin Web, đánh giá quyền vào phân hệ theo C-R01. | Ghi response/status cho từng dạng request và ghi rõ là observation; GET không làm thay đổi danh sách. | C-R01, C-R03; liên quan câu hỏi C-R06 |

##### 3. Vì sao chia như vậy

- Tên rỗng và tên không rỗng tách theo điều kiện bắt buộc của FR-14; ASCII và Unicode có dấu là hai đại diện không rỗng để quan sát khả năng giữ/hiển thị ký tự mà không tự đặt quy tắc charset.
- Whitespace-only được tách riêng vì phân công yêu cầu xem xét, nhưng FR-14 không định nghĩa trim hoặc ý nghĩa của “trống” với khoảng trắng. Gán nó vào lớp hợp lệ hay không hợp lệ lúc này sẽ tự tạo oracle.
- Danh sách rỗng/có dữ liệu tạo hai trạng thái đầu ra khác nhau cho thao tác xem. Category vừa tạo, category tồn tại từ trước và ID không tồn tại phân biệt target có thể xác nhận an toàn, target có nguy cơ là dữ liệu mẫu, và target không có đối tượng tương ứng.
- Admin, user thường, thiếu token, token sai và token hết hạn được tách vì mỗi lớp kiểm tra một điều kiện xác thực/phân quyền của POST/DELETE. Trạng thái GET được xem riêng; không suy ra ràng buộc của thao tác ghi áp dụng cho GET.
- Các lớp chưa đủ nguồn được ghi là câu hỏi/thăm dò và không có Pass/Fail dự kiến. Không tạo lớp theo độ dài tên hoặc tính duy nhất vì SRS không quy định các giới hạn đó.

##### 4. Câu hỏi cần làm rõ trước khi chấm kết quả

1. Có phải chuỗi chỉ gồm khoảng trắng được xem là trống sau trim không?
2. `GET /api/categories` có yêu cầu đăng nhập/role admin không, hay danh sách có thể xem công khai? FR-12/API spec chưa xác định rõ endpoint GET dùng chung này.
3. Khi xóa ID không tồn tại, expected response/status là gì?
4. Có thể xóa danh mục đang được sản phẩm tham chiếu không? Nếu không, expected behavior là gì? Chưa được tự thử xóa danh mục đang có tham chiếu nếu có nguy cơ ảnh hưởng dữ liệu mẫu.
5. Response/status nào được quy ước cho thêm/xóa thành công, tên rỗng và lỗi quyền? API specification hiện không nêu.

Tài liệu này chỉ là phân hoạch miền. Chưa tạo test case, chưa chạy SUT, chưa chấm kết quả và chưa ghi nhận human review.

#### 03-domain-cases — C-FR14

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### Quy ước chung

- **Nguồn expected:** SRS `eshop-sut/README.md` FR-14 (Thêm/Xem/Xóa; tên bắt buộc, không để trống) và FR-12 (Admin role; API POST/DELETE cần JWT hợp lệ và role admin); endpoint `GET/POST/DELETE /api/categories` theo `eshop-sut/api_specification.md` mục 3.4.
- Dùng tài khoản test có role admin và user thường; không ghi password/JWT vào evidence. API request/response phải che token. Nếu không có sẵn tài khoản với đúng role, chuẩn bị qua quy trình an toàn được phép trước khi bắt đầu; không sửa role của tài khoản mẫu.
- Tên cho category test: thay `<RunID>` bằng mã riêng cho lần chạy, ví dụ `R20261015-01`. Các ví dụ đầy đủ như `C14-DT-R20261015-01-ASCII` hoặc `C14-DT-R20261015-01-Đồ uống` là dữ liệu test cụ thể; hậu tố chỉ để nhận diện/dọn đúng dữ liệu của ca, không kiểm tra tính duy nhất.
- Trước mỗi ca ghi danh sách hiện tại; khi so sánh chỉ xét các dòng test do ca tạo. Không sửa/xóa category mẫu. Nếu không thể phân biệt dòng test hoặc target có tham chiếu sản phẩm và thao tác có rủi ro, dừng ca.
- Lưu ảnh giao diện trước/sau; với API lưu request/response JSON đã che token, thời điểm, và snapshot `GET /api/categories` trước/sau. Evidence sau này đặt tại `evidence/C-FR14/<TC-ID>/<Run-ID>/`.
- **Dọn dẹp:** sau khi evidence được lưu, xóa qua Admin UI/API chỉ những category ID do chính ca đó tạo và đã đối chiếu tên/ID. Ghi thao tác dọn vào execution log. Không xóa tự động trong các ca thiết kế này. Không xóa dữ liệu mẫu.
- Không đặt HTTP status/body, trim, uniqueness, độ dài tên, dialog bắt buộc hoặc chính sách xóa category đang được sản phẩm tham chiếu.

##### C-DT-001 — Admin thêm tên ASCII và thấy đúng tên trong danh sách

- **Mục tiêu / requirement:** Thêm và xem danh mục mới; C-R02, C-R03, C-R05.
- **Loại:** Admin Web UI.
- **Role/tài khoản, trạng thái đầu:** Tài khoản test role `admin` đã đăng nhập; ghi snapshot danh sách trước; không dùng lại tên test đã tạo ở Run trước nếu còn tồn tại.
- **Dữ liệu:** Tên `C14-DT-<RunID>-Do uong test` (ASCII, không rỗng).
- **EC:** C-EC-02, C-EC-06, C-EC-10.
- **Thao tác:** 1) Mở khu vực **Danh mục** trong Admin. 2) Chụp danh sách trước. 3) Nhập đúng tên vào ô tên danh mục. 4) Bấm **Thêm mới** một lần. 5) Quan sát phản hồi. 6) Chụp danh sách và tìm chính xác tên vừa nhập; ghi ID hiển thị nếu có.
- **Expected:** Admin có thể thêm danh mục; tên test xuất hiện trong danh sách đúng như nhập. Không chấm thông báo/status cụ thể.
- **Quan sát/evidence:** ảnh form trước submit, ảnh sau submit có tên và ID/dòng; ghi danh sách trước/sau. Ghi ID category test để dọn sau khi lưu evidence.

##### C-DT-002 — Admin thêm tên Unicode có dấu và thấy đúng tên

- **Mục tiêu / requirement:** Kiểm tra tên không rỗng có dấu; C-R02, C-R03, C-R05.
- **Loại:** Admin Web UI.
- **Role/tài khoản, trạng thái đầu:** Tài khoản role `admin`; danh sách trước đã ghi; dùng tên mới cho ca.
- **Dữ liệu:** `C14-DT-<RunID>-Đồ uống thử` (Unicode có dấu, không rỗng).
- **EC:** C-EC-03, C-EC-06, C-EC-10.
- **Thao tác:** 1) Mở **Danh mục**. 2) Nhập tên nguyên văn vào ô tên. 3) Bấm **Thêm mới**. 4) Quan sát danh sách sau thao tác, không sửa lại ký tự. 5) So sánh chuỗi hiển thị với input.
- **Expected:** FR-14 yêu cầu tên không để trống và không nêu giới hạn ký tự; category được thêm và tên nhập được hiển thị đúng. Không đặt expected về Unicode normalization.
- **Quan sát/evidence:** ảnh input và danh sách sau; ghi chính xác tên và ID. Dọn chỉ category ID do ca tạo sau khi lưu evidence.

##### C-DT-003 — Tên rỗng bị từ chối, danh sách không đổi

- **Mục tiêu / requirement:** Tên bắt buộc; C-R05.
- **Loại:** Admin Web UI.
- **Role/tài khoản, trạng thái đầu:** Admin đã đăng nhập; ghi snapshot danh sách trước.
- **Dữ liệu:** trường tên rỗng `""`; không nhập giá trị khác.
- **EC:** C-EC-01, C-EC-10.
- **Thao tác:** 1) Mở **Danh mục**. 2) Chụp/ghi danh sách trước. 3) Để trống ô tên. 4) Bấm **Thêm mới** một lần. 5) Quan sát validation và danh sách sau; không nhập tên thay thế trong cùng ca.
- **Expected:** Không tạo category có tên rỗng theo FR-14. Câu chữ/thời điểm validation không được quy định.
- **Quan sát/evidence:** ảnh ô trống và danh sách sau; xác nhận không xuất hiện dòng mới bằng cách đối chiếu snapshot. Không gán expected cho nội dung cảnh báo.

##### C-DT-004 — Probe tên chỉ có ba dấu cách

- **Mục tiêu / requirement:** Tìm hiểu cách xử lý whitespace-only; C-R05 nhưng oracle chưa chốt.
- **Loại:** Admin Web UI; probe, không kết luận Pass/Fail.
- **Role/tài khoản, trạng thái đầu:** Admin đã đăng nhập; ghi snapshot danh sách trước.
- **Dữ liệu:** đúng ba dấu cách `"   "`; không thêm ký tự khác.
- **EC:** C-EC-04.
- **Thao tác:** 1) Mở **Danh mục**. 2) Nhập ba dấu cách. 3) Chụp giá trị hiển thị trong ô. 4) Bấm **Thêm mới** một lần nếu UI cho phép. 5) Quan sát response/danh sách sau và ghi chính xác input/output.
- **Expected:** **Chưa chốt.** SRS không định nghĩa trim hoặc whitespace-only có phải “để trống”. Không đánh Pass/Fail cho việc nhận/từ chối chuỗi này; nếu category được tạo, chỉ dọn đúng ID test sau khi evidence được lưu.
- **Quan sát/evidence:** ảnh ô input trước submit và trạng thái sau; nếu có category mới ghi ID/name/API GET observation. Ghi kết quả là probe để hỏi review.

##### C-DT-005 — Admin xem danh sách đang có dữ liệu

- **Mục tiêu / requirement:** Xem danh sách; C-R03.
- **Loại:** Admin Web UI.
- **Role/tài khoản, trạng thái đầu:** Admin đã đăng nhập; danh sách có ít nhất một category hiện có hoặc category test do ca trước tạo; ghi ID/tên trước.
- **Dữ liệu:** không thay đổi tên/ID; không có request ghi.
- **EC:** C-EC-06, C-EC-10.
- **Thao tác:** 1) Mở **Danh mục**. 2) Quan sát và chụp các dòng. 3) Đối chiếu tên/ID với snapshot trước; không click Xóa/Thêm.
- **Expected:** Admin xem được danh sách danh mục. Không đặt thứ tự, schema field hoặc nội dung giao diện ngoài việc danh sách được hiển thị.
- **Quan sát/evidence:** ảnh danh sách đủ rõ; ghi các ID/tên đã quan sát và xác nhận trạng thái dữ liệu không bị thay đổi.

##### C-DT-006 — GET danh mục riêng, không suy rộng quyền truy cập

- **Mục tiêu / requirement:** Quan sát GET độc lập với kiểm thử quyền POST/DELETE; C-R03, C-R06 (điểm chưa rõ).
- **Loại:** API read-only probe.
- **Role/tài khoản, trạng thái đầu:** Chuẩn bị lần lượt token admin, token user thường và request không có token; nếu không có một dạng credential thì ghi Not run cho biến thể đó. Chụp/ghi trạng thái category ban đầu.
- **Dữ liệu:** `GET /api/categories`; không có body và không làm thay đổi state.
- **EC:** C-EC-05/C-EC-06 tùy danh sách; C-EC-15.
- **Thao tác:** 1) Gọi GET với token admin; lưu response đã che token. 2) Gọi GET với token user; lưu response. 3) Gọi GET không Authorization; lưu response. 4) Đối chiếu dữ liệu và xác nhận không có thay đổi sau các GET.
- **Expected:** FR-14 yêu cầu chức năng xem danh sách; API có endpoint GET. **Chưa có expected cho việc từ chối/cho phép từng nhóm credential** vì FR-12/API spec không chốt quyền của GET dùng chung. Không yêu cầu user/khách bị từ chối; không gán Fail nếu GET trả danh sách cho họ.
- **Quan sát/evidence:** request/response từng biến thể đã che token, timestamp; danh sách trước/sau. Gắn nhãn probe/observation-only.

##### C-DT-007 — Admin xóa đúng category test vừa tạo

- **Mục tiêu / requirement:** Xóa đúng target và giữ các dòng khác; C-R04.
- **Loại:** Admin Web UI.
- **Role/tài khoản, trạng thái đầu:** Admin đã đăng nhập. Tạo mới một category test riêng qua UI với tên `C14-DT-<RunID>-delete-target`; ghi ID/tên sau khi tạo. Ghi thêm một category khác đang có để so sánh, không sửa/xóa category đó. Nếu target có liên quan sản phẩm hoặc không thể phân biệt, dừng.
- **Dữ liệu:** chỉ xóa ID vừa tạo trong cùng ca; giữ nguyên category khác.
- **EC:** C-EC-06, C-EC-07, C-EC-10.
- **Thao tác:** 1) Chụp danh sách có target và dòng so sánh. 2) Tại đúng dòng target bấm **Xóa**. 3) Nếu UI hiện dialog, chụp lại và chỉ chọn nút xác nhận có nhãn rõ; nếu không có dialog, ghi nhận rồi tiếp tục luồng xóa UI đang có. 4) Sau khi thao tác hoàn tất, chụp danh sách. 5) Đối chiếu target ID và dòng so sánh.
- **Expected:** Sau khi thao tác xóa target test thành công, ID/tên target không còn trong danh sách; dòng so sánh và category khác giữ nguyên. Không yêu cầu dialog/status cụ thể.
- **Quan sát/evidence:** ảnh trước/sau thể hiện target và dòng khác; ghi ID test, thao tác và mọi feedback. Evidence phải được lưu trước khi cleanup bổ sung.

##### C-DT-008 — Dialog xóa và Hủy (chỉ khi UI có dialog)

- **Mục tiêu / requirement:** Probe hành vi dialog; C-R04 nhưng dialog không phải yêu cầu SRS.
- **Loại:** Admin Web UI; phụ thuộc giao diện có dialog.
- **Role/tài khoản, trạng thái đầu:** Admin đã đăng nhập; tạo một category test riêng `C14-DT-<RunID>-cancel-target`; ghi ID/name và xác nhận category khác hiện diện. Không dùng category mẫu làm target.
- **Dữ liệu:** ID category test vừa tạo.
- **EC:** C-EC-07, C-EC-10.
- **Thao tác:** 1) Tại dòng category test bấm **Xóa**. 2) Nếu dialog xuất hiện, chụp nội dung/nút. 3) Chọn nút Hủy/Cancel nếu hiện rõ. 4) Chụp danh sách và kiểm tra ID test còn tồn tại. Nếu không có dialog, ghi “dialog không quan sát thấy” và dừng nhánh tương tác; không tạo thao tác Hủy giả định.
- **Expected:** **Chưa có oracle SRS cho việc phải có dialog hoặc ngữ nghĩa/nội dung nút Hủy.** Candidate để review: chọn Hủy không xóa category; chỉ ghi observation, không gán Pass/Fail cho dialog/cancel.
- **Quan sát/evidence:** ảnh dialog (nếu có), nút đã chọn, danh sách sau; ghi status “probe”. Dọn chỉ ID test riêng sau khi lưu evidence.

##### C-DT-009 — API POST với JWT admin hợp lệ

- **Mục tiêu / requirement:** API thêm và quyền admin hợp lệ; C-R02/C-R06.
- **Loại:** API.
- **Role/tài khoản, trạng thái đầu:** Tài khoản test role admin; token hợp lệ còn hiệu lực; danh sách trước đã lưu. Không ghi token vào file/log.
- **Dữ liệu:** `POST /api/categories`, body `{"name":"C14-DT-<RunID>-api-post"}`.
- **EC:** C-EC-02, C-EC-06, C-EC-10.
- **Thao tác:** 1) Lưu snapshot GET trước. 2) Gửi POST với `Authorization: Bearer <admin-token>` và body tên trên. 3) Lưu response đã che token. 4) Gọi GET danh sách. 5) Tìm category mới, ghi ID/tên.
- **Expected:** Admin có thể thêm danh mục; tên hợp lệ xuất hiện trong danh sách sau POST. HTTP status/body thành công chưa được quy định.
- **Quan sát/evidence:** request/response redacted, timestamps, GET trước/sesudah; ghi ID test để dọn sau khi evidence được lưu.

##### C-DT-010 — API DELETE với JWT admin hợp lệ

- **Mục tiêu / requirement:** API xóa đúng category test bằng quyền admin; C-R04/C-R06.
- **Loại:** API.
- **Role/tài khoản, trạng thái đầu:** Admin token hợp lệ. Trong setup, tạo một category test riêng bằng POST admin với tên `C14-DT-<RunID>-api-delete`, nhận ID và xác nhận ID/name tồn tại qua GET. Có thể có category khác làm đối chứng; tuyệt đối không dùng ID mẫu làm target.
- **Dữ liệu:** `DELETE /api/categories/<ID vừa tạo>`.
- **EC:** C-EC-06, C-EC-07, C-EC-10.
- **Thao tác:** 1) Lưu GET trước, gồm target và dòng khác. 2) Gửi DELETE bằng admin token. 3) Lưu response redacted. 4) Gọi GET sau. 5) Đối chiếu: target mất, dòng khác vẫn còn.
- **Expected:** category test được chọn bị xóa khỏi danh sách; category khác không bị thay đổi. HTTP status/body không quy định.
- **Quan sát/evidence:** POST setup, ID/name, DELETE request/response, GET trước/sau đã lưu; token luôn che. Dọn chỉ ID test nếu còn tồn tại sau ca và chỉ sau khi lưu evidence.

##### C-DT-011 — API POST thiếu token

- **Mục tiêu / requirement:** FR-12 chặn ghi khi không có JWT; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái đầu:** Không gửi token; danh sách category trước đã snapshot. Endpoint/body/name hợp lệ; không có field nghiệp vụ sai.
- **Dữ liệu:** `POST /api/categories`, body `{"name":"C14-DT-<RunID>-post-no-token"}`; không có Authorization header.
- **EC:** C-EC-02, C-EC-12.
- **Thao tác:** 1) GET snapshot trước. 2) Gửi đúng POST/body, bỏ Authorization. 3) Lưu response. 4) GET snapshot sau và tìm tên test.
- **Expected:** Thiếu JWT hợp lệ nên không được thêm category; danh sách không đổi. Không đặt HTTP status/body lỗi.
- **Quan sát/evidence:** request headers (xác nhận không có Authorization), body, response, GET trước/sau. Chỉ một yếu tố sai là quyền/xác thực.

##### C-DT-012 — API POST token sai/không hợp lệ

- **Mục tiêu / requirement:** FR-12 chặn JWT không hợp lệ; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái đầu:** Không dùng credential thật; danh sách trước đã snapshot; body và tên hợp lệ.
- **Dữ liệu:** POST body `{"name":"C14-DT-<RunID>-post-bad-token"}`; header `Authorization: Bearer not-a-valid-token`.
- **EC:** C-EC-02, C-EC-13.
- **Thao tác:** GET trước → gửi POST với token giả ở trên → lưu response → GET sau, tìm tên test.
- **Expected:** Token không hợp lệ không đáp ứng FR-12; category không được tạo và danh sách không đổi. Status/message chưa quy định.
- **Quan sát/evidence:** request/response đã lưu, token giả hiển thị đúng literal, GET trước/sau. Chỉ yếu tố token sai.

##### C-DT-013 — API POST token hết hạn

- **Mục tiêu / requirement:** FR-12 yêu cầu JWT hợp lệ; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái đầu:** Có token test hết hạn đã chuẩn bị an toàn; danh sách trước snapshot; token role admin nhưng hết hạn để chỉ thời hạn là yếu tố sai. Không ghi giá trị token.
- **Dữ liệu:** POST body `{"name":"C14-DT-<RunID>-post-expired"}`.
- **EC:** C-EC-02, C-EC-14.
- **Thao tác:** GET trước → POST với Bearer token hết hạn → lưu response redacted → GET sau và tìm tên.
- **Expected:** JWT hết hạn không hợp lệ nên không được tạo category; danh sách không đổi. Status/message chưa quy định. Nếu không thể tạo/xác minh token hết hạn mà không đổi hệ thống, đánh dấu ca chưa chạy thay vì thay bằng token khác.
- **Quan sát/evidence:** token metadata redacted (role/expiry test), request/response và GET trước/sau. Chỉ yếu tố thời hạn token sai.

##### C-DT-014 — API POST token user thường hợp lệ

- **Mục tiêu / requirement:** FR-12 chặn role không phải admin; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái đầu:** User test có token hợp lệ còn hạn và role user; danh sách trước snapshot. Body hợp lệ; không dùng admin token.
- **Dữ liệu:** POST body `{"name":"C14-DT-<RunID>-post-user"}`.
- **EC:** C-EC-02, C-EC-11.
- **Thao tác:** GET trước → POST với Bearer user token → lưu response redacted → GET sau và tìm tên.
- **Expected:** Token hợp lệ nhưng role không phải admin nên không được thêm category theo FR-12; danh sách không đổi. Status/message không quy định.
- **Quan sát/evidence:** xác nhận role của test account từ nguồn an toàn (không lưu token), request/response, GET trước/sau. Chỉ role là yếu tố không đạt.

##### C-DT-015 — API DELETE thiếu token

- **Mục tiêu / requirement:** FR-12 chặn DELETE không có JWT; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái chuẩn bị:** Setup bằng admin tạo một category test riêng `C14-DT-<RunID>-delete-no-token`; lưu ID/name qua GET. Token bị thiếu chỉ ở request DELETE; không đụng category khác.
- **Dữ liệu:** `DELETE /api/categories/<ID test>` không Authorization header.
- **EC:** C-EC-07, C-EC-12.
- **Thao tác:** GET trước xác nhận target tồn tại → DELETE không token → lưu response → GET sau xác nhận target còn và các dòng khác không đổi.
- **Expected:** Không có JWT hợp lệ nên FR-12 yêu cầu không cho ghi; target không bị xóa, danh sách không đổi. Không đặt status/body.
- **Quan sát/evidence:** POST setup, target ID, DELETE headers không Authorization, response, GET trước/sau. Chỉ yếu tố token thiếu.

##### C-DT-016 — API DELETE token không hợp lệ

- **Mục tiêu / requirement:** FR-12 chặn DELETE với JWT sai; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái chuẩn bị:** Tạo category test riêng bằng setup admin; xác nhận target tồn tại và ghi ID. DELETE request dùng token giả; target và mọi input khác hợp lệ.
- **Dữ liệu:** `DELETE /api/categories/<ID test>`; header `Authorization: Bearer not-a-valid-token`.
- **EC:** C-EC-07, C-EC-13.
- **Thao tác:** GET trước → DELETE với literal token giả → lưu response → GET sau, xác nhận target còn.
- **Expected:** JWT không hợp lệ không được phép xóa; danh sách giữ nguyên. Không đặt status/message.
- **Quan sát/evidence:** request/response, GET trước/sau và ID test. Chỉ yếu tố token sai.

##### C-DT-017 — API DELETE token hết hạn

- **Mục tiêu / requirement:** FR-12 chặn DELETE khi JWT không còn hợp lệ; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái chuẩn bị:** Admin setup tạo category test riêng; token test có role admin nhưng hết hạn; xác nhận target còn tồn tại. Không ghi token.
- **Dữ liệu:** `DELETE /api/categories/<ID test>` bằng Bearer token hết hạn.
- **EC:** C-EC-07, C-EC-14.
- **Thao tác:** GET trước → DELETE với token hết hạn → lưu response redacted → GET sau, xác nhận target còn.
- **Expected:** JWT hết hạn không hợp lệ, không được xóa category; danh sách không đổi. Nếu không chuẩn bị được token an toàn, ghi Not run thay vì dùng token giả làm cùng lớp.
- **Quan sát/evidence:** metadata token test đã che, request/response và GET trước/sau.

##### C-DT-018 — API DELETE token user thường hợp lệ

- **Mục tiêu / requirement:** FR-12 chặn role user thường khỏi DELETE; C-R06.
- **Loại:** API âm.
- **Role/tài khoản, trạng thái chuẩn bị:** Admin setup tạo target test riêng và xác nhận tồn tại; request DELETE dùng JWT hợp lệ của role user. Không dùng category mẫu.
- **Dữ liệu:** `DELETE /api/categories/<ID test>` với Bearer user token còn hạn.
- **EC:** C-EC-07, C-EC-11.
- **Thao tác:** GET trước → DELETE bằng user token → lưu response redacted → GET sau, xác nhận target test vẫn tồn tại.
- **Expected:** Role user không thỏa FR-12, nên thao tác ghi bị từ chối và target không bị xóa. Status/message không được đặc tả.
- **Quan sát/evidence:** role test account được xác nhận an toàn, request/response, GET trước/sau. Chỉ yếu tố role không đủ quyền.

##### Giới hạn thiết kế

- Mỗi ca âm POST/DELETE chỉ có một yếu tố không hợp lệ: tên rỗng (C-DT-003) hoặc một điều kiện xác thực/quyền (C-DT-011–018). Body, endpoint và target ID còn lại phải hợp lệ.
- POST/DELETE chỉ dùng tên/ID do ca tạo. Nếu request âm bị xử lý sai và tạo/xóa nhầm dữ liệu, dừng thao tác tiếp theo, giữ lại evidence và không dọn dữ liệu ngoài phạm vi.
- C-DT-004 và C-DT-008 là probe có expected chưa chốt; C-DT-006 là probe quyền GET. Không chấm Pass/Fail trước khi có oracle.
- Không có expected cho ID không tồn tại; không đưa thành ca kết luận trong bộ này. Không có ca edit/PUT vì FR-14 không yêu cầu sửa danh mục.
- Tài liệu chỉ là thiết kế. Chưa chạy test, chưa ghi actual/status hoặc kết quả.

#### 04-boundary-cases — C-FR14

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

##### 1. Căn cứ và cách chọn biên

- SRS `eshop-sut/README.md`, FR-14: tên danh mục **bắt buộc, không được để trống**. Miền có căn cứ là độ dài tên ở biên dưới: `LB = 1 ký tự`, `δ = 1 ký tự`; các điểm là `LB−δ = 0`, `LB = 1`, `LB+δ = 2`.
- Dùng ký tự ASCII cho các ca 1/2 ký tự để phép đếm độ dài rõ ràng. Expected chỉ dựa trên rỗng/không rỗng; không thêm yêu cầu về uniqueness, trim hoặc giới hạn độ dài.
- **Không có upper bound (UB) trong SRS/API specification.** Không đặt giá trị max hoặc tạo ca `UB−1/UB/UB+1`.
- ID danh mục là định danh, không có khoảng giá trị hoặc giới hạn min/max được nêu. Hai ca ID bên dưới là **state-boundary probes** cho tồn tại/không tồn tại, không phải BVA số học; không bịa ID cực đại. ID không tồn tại có expected xử lý chưa rõ.
- Unicode có dấu và whitespace-only là các probe Domain ở `03-domain-cases.md`, không phải điểm BVA theo thứ tự độ dài; không lặp lại như ca biên. Trạng thái danh sách rỗng/có dữ liệu và role/token cũng là các lớp Domain, không phải biên số.
- Slide Domain/BVA dùng điều kiện đặc tả để chọn điểm sát biên và đại diện; nếu nguồn không nêu giới hạn thì không tự tạo biên.

##### 2. Quy ước chuẩn bị và bảo toàn dữ liệu

- Mỗi ca dùng phiên Admin Web có tài khoản role admin và JWT hợp lệ; token không chụp/ghi vào evidence. Đây là điều kiện quyền theo FR-12, không phải biến biên của các ca tên.
- Thay `<RunID>` bằng mã riêng lần chạy, ví dụ `R20261015-01`, để tên category test nhận diện được; hậu tố không kiểm tra uniqueness.
- Trước mỗi ca chụp/ghi danh sách hiện tại. Positive case chỉ tạo category test qua UI, ghi ID/name do hệ thống trả/hiển thị. Không sửa hoặc xóa category mẫu.
- Chỉ dọn category ID do chính ca tạo sau khi lưu bằng chứng; thao tác dọn ghi trong execution log. Không tự chạy trong tài liệu này.
- Ảnh lưu dự kiến tại `evidence/C-FR14/<TC-ID>/<Run-ID>/`; lưu ảnh input và list trước/sau. Với API probe, lưu request/response đã che token và snapshot GET.

##### 3. Các ca BVA tên danh mục

###### C-BV-001 — Biên dưới ngoài miền: tên 0 ký tự

- **Mục tiêu:** Kiểm tra ngay dưới lower bound bắt buộc.
- **Biên:** `LB=1`, `δ=1`, input length `0 = LB−δ`.
- **Loại:** Admin Web UI.
- **Role/tài khoản, setup:** Tài khoản test role admin đã đăng nhập; ghi snapshot danh sách category trước. Không dùng danh mục mẫu làm target. Không cần tạo category cho input rỗng; nếu cần fixture để so sánh, chỉ dùng một category test riêng do ca tạo trước và ghi ID.
- **Input:** ô tên để trống `""` (0 ký tự); không nhập ký tự khác.
- **C-EC / requirement / liên quan:** C-EC-01; C-R02/C-R05; liên quan C-DT-003.
- **Thao tác:** 1) Mở Admin → **Danh mục**. 2) Ghi/chụp danh sách trước. 3) Để ô tên hoàn toàn rỗng. 4) Bấm **Thêm mới** một lần. 5) Quan sát validation và danh sách sau, không điền tên khác trong cùng ca.
- **Expected:** Không có danh mục mới với tên rỗng, theo FR-14 “tên bắt buộc, không được để trống”. Cách báo lỗi/UI behavior cụ thể chưa quy định.
- **Quan sát/evidence:** ảnh ô input rỗng, thao tác submit nếu có thể, danh sách trước/sau; ghi số/ID của các dòng test. Không chấm wording/status HTTP.

###### C-BV-002 — Lower bound: tên 1 ký tự

- **Mục tiêu:** Kiểm tra giá trị nhỏ nhất không rỗng.
- **Biên:** `LB=1`, input length `1 = LB`.
- **Loại:** Admin Web UI.
- **Role/tài khoản, setup:** Admin đã đăng nhập; danh sách trước đã ghi. Category cần tạo là dữ liệu test của ca; không xóa dữ liệu khác.
- **Input:** tên đúng một ký tự ASCII: `Q` (length=1), sau khi xác nhận trước test chưa có tên đúng `Q`. Nếu `Q` đã có, chọn và ghi một ký tự ASCII khác chưa có trong danh sách. Việc chọn tên vắng mặt chỉ tránh đụng dữ liệu; không kiểm tra uniqueness.
- **C-EC / requirement / liên quan:** C-EC-02; C-R02/C-R05; liên quan C-DT-001.
- **Thao tác:** 1) Mở **Danh mục**. 2) Nhập đúng ký tự đã chọn ở setup (ví dụ `Q`; đúng 1 ký tự ASCII). 3) Bấm **Thêm mới** một lần. 4) Quan sát danh sách, đối chiếu theo ID/dòng category được thêm và ghi chính xác tên.
- **Expected:** Tên đã chọn không rỗng, vì vậy đáp ứng điều kiện tên bắt buộc hiện có; category test được thêm và xuất hiện chính xác trong danh sách. Không chấm uniqueness hay format thông báo.
- **Quan sát/evidence:** ảnh input của ký tự đã chọn, danh sách trước/sau, tên và ID test. Sau khi evidence lưu, chỉ dọn ID do ca này tạo.

###### C-BV-003 — Ngay phía trên lower bound: tên 2 ký tự

- **Mục tiêu:** Kiểm tra điểm kề phía trong miền sau LB.
- **Biên:** `LB=1`, `δ=1`, input length `2 = LB+δ`.
- **Loại:** Admin Web UI.
- **Role/tài khoản, setup:** Admin đã đăng nhập; danh sách trước đã ghi; category mới là dữ liệu test riêng.
- **Input:** tên đúng hai ký tự ASCII: `QZ` (length=2), sau khi xác nhận trước test chưa có tên đúng `QZ`. Nếu đã có, chọn và ghi một chuỗi hai ký tự ASCII khác chưa có trong danh sách; không kiểm tra uniqueness.
- **C-EC / requirement / liên quan:** C-EC-02; C-R02/C-R05; liên quan C-DT-001.
- **Thao tác:** 1) Mở **Danh mục**. 2) Nhập đúng chuỗi đã chọn ở setup (ví dụ `QZ`; đúng 2 ký tự ASCII). 3) Bấm **Thêm mới** một lần. 4) Quan sát dòng mới và so sánh chính xác chuỗi tên với input.
- **Expected:** Tên đã chọn không rỗng và không vi phạm điều kiện bắt buộc hiện có; category test được thêm và tên được hiển thị chính xác. Không áp đặt uniqueness/UB.
- **Quan sát/evidence:** ảnh input và danh sách trước/sau, ID test; chỉ dọn ID do ca tạo sau khi lưu bằng chứng.

##### 4. Probe trạng thái ID (không phải BVA số học)

###### C-BV-004 — ID tồn tại của category test

- **Mục tiêu:** Kiểm tra state target đang ở phía “tồn tại” khi xóa; đây là state transition probe, không phải biên số.
- **Loại:** Admin Web UI hoặc API `DELETE` (chọn một cách và ghi rõ trong lần chạy).
- **Role/token, setup:** Admin role với phiên/JWT hợp lệ. Tạo một category test riêng bằng C-DT-001/C-DT-009 hoặc setup tương đương; ghi ID cụ thể được hệ thống cấp, tên và xác nhận target hiện trong GET/list. Không dùng ID mẫu.
- **Input:** category ID đang tồn tại vừa tạo; ví dụ khi thực hiện sẽ ghi `ID=<giá trị được trả/hiển thị>`; không hard-code ID giả.
- **C-EC / requirement / liên quan:** C-EC-07; C-R04/C-R06; liên quan C-DT-007/C-DT-010.
- **Thao tác:** 1) Chụp/ghi danh sách có target và dòng đối chứng. 2) Gửi thao tác xóa đúng ID target bằng UI hoặc `DELETE /api/categories/:id` với admin JWT. 3) Ghi response/feedback. 4) Xem lại danh sách và đối chiếu ID target cùng các dòng khác.
- **Expected:** Category test được chọn không còn trong danh sách sau khi xóa thành công; dòng không phải target giữ nguyên. SRS/API không định nghĩa HTTP status/body hoặc dialog.
- **Quan sát/evidence:** ID/name trước xóa; ảnh UI hoặc request/response đã che token; GET/list trước/sau. Đây là category do ca tạo nên có thể dọn/hoàn tất xóa sau khi evidence đã lưu.

###### C-BV-005 — ID không tồn tại (probe, expected chưa chốt)

- **Mục tiêu:** Quan sát request xóa với ID không có trong danh sách; không gọi đây là UB ID.
- **Loại:** API probe `DELETE`.
- **Role/token, setup:** Admin role với JWT hợp lệ. Tạo một category test riêng làm đối chứng, ghi ID/name và xác nhận nó còn trong danh sách. Dùng GET chỉ đọc để chọn một candidate ID được xác nhận hiện không tồn tại; ghi chính xác candidate trong log trước khi gửi DELETE. Không dùng số cực đại hoặc ID của dữ liệu khác.
- **Input:** category ID candidate không có trong snapshot GET; kiểu/format phải tương thích với ID quan sát được trong hệ thống. Nếu không xác định được một candidate vắng mặt với format phù hợp, không gửi request và ghi ca chưa chạy.
- **C-EC / requirement / liên quan:** C-EC-09; C-R04/C-R06; liên quan phân hoạch ID không tồn tại ở `02-domains.md`.
- **Thao tác:** 1) Lưu GET snapshot trước, xác nhận candidate không xuất hiện và category test đối chứng vẫn tồn tại. 2) Gửi `DELETE /api/categories/<candidate>` bằng admin JWT. 3) Lưu response đã che token. 4) Lấy GET snapshot sau; xác nhận category đối chứng và các dòng khác còn nguyên.
- **Expected:** **Chưa có oracle** cho phản hồi/status khi ID không tồn tại. Chỉ kiểm tra observation và đảm bảo không có dòng hiện có nào bị xóa; không gán Pass/Fail theo response.
- **Quan sát/evidence:** candidate ID, snapshot trước/sau, request/response redacted, ID/name của category đối chứng. Không xóa category đối chứng trong ca này; thủ tục dọn chỉ áp dụng ID test do ca tạo sau khi evidence được lưu.

##### 5. Tổng hợp biên và phạm vi

| Input | Điểm/biên | Expected |
|---|---|---|
| Tên danh mục | `0` ký tự = `LB−δ`, `LB=1`, `δ=1` | 0 không được thêm; 1 và 2 ký tự không rỗng được thêm theo điều kiện FR-14. |
| Tên tối đa | **Không có UB được nêu** | Không tạo giá trị lớn tùy ý hoặc kết luận vượt max. |
| Category ID | Tồn tại / không tồn tại | Tồn tại dùng ID test mới tạo để xác minh xóa; ID vắng mặt chỉ là probe chưa có expected phản hồi. Không xem ID là miền số có min/max. |
| Unicode / whitespace-only | Không phải điểm biên thứ tự trong bộ này | Đã để trong Domain cases C-DT-002/C-DT-004; whitespace expected chưa chốt. |

Không có biên khác được SRS/API hoặc phân công nêu rõ cho tên danh mục. Auth role/token là các lớp tương đương, không phải BVA. Không tạo test result, actual, Pass/Fail hay human review.

### D-MREG — thiết kế đầy đủ

#### 01-requirements — D-MREG

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2  
**Phạm vi:** đăng ký tài khoản trong ứng dụng Mobile. FR-20 yêu cầu tính năng Đăng ký có trên Mobile; quy tắc đăng ký được lấy từ FR-01. Không mở rộng sang đăng nhập, quên mật khẩu hay các chức năng Mobile khác.

##### 1. Yêu cầu và expected result

Expected result bên dưới lấy từ SRS và API specification, không lấy từ cách SUT đang cài đặt. Khi tài liệu không chốt thông báo hoặc phản hồi lỗi, ghi rõ là chưa quy định thay vì tự đặt câu chữ/status.

| ID | Yêu cầu | Input | Trạng thái trước → sau | Đầu ra cần quan sát trên Mobile/API | Nguồn expected result |
|---|---|---|---|---|---|
| **D-R01** | Người dùng phải cung cấp họ tên khi đăng ký. | Trường **Họ Tên**; ví dụ đại diện hợp lệ: `Nguyen Le The Vinh`. | Trước: chưa gửi đăng ký. Khi họ tên có giá trị và các input khác hợp lệ: có thể tiếp tục đăng ký. Khi thiếu họ tên: không được đăng ký thành công. | Mobile: trường họ tên và kết quả từ chối/cho tiếp tục. API: body đăng ký có `name`, nhưng API spec không mô tả cách báo lỗi khi thiếu. | SRS `README.md`, FR-01 (dòng 32); API specification §1.1 (dòng 12–21) có trường `name`; phân công thành viên 2, Pool D (dòng 50–52) xác định kiểm tra form Mobile. |
| **D-R02** | Người dùng phải cung cấp email. | Trường **Email**; ví dụ `vinh.test@example.com`. | Trước: email chưa gửi. Email có giá trị: đủ điều kiện xét format/trùng. Email thiếu: không được đăng ký thành công. | Mobile: giá trị nhập và phản hồi đăng ký. API: trường `email` trong body; cách báo lỗi khi thiếu chưa được nêu. | SRS `README.md`, FR-01 (dòng 32–33); API specification §1.1 (dòng 12–21). |
| **D-R03** | Email phải đúng định dạng hợp lệ, ví dụ `user@domain.com`. | Trường **Email**; ví dụ hợp lệ `vinh.test@example.com`; định dạng sai là input không thỏa điều kiện. | Trước: chưa gửi. Email hợp lệ: được xét tiếp điều kiện duy nhất. Email sai định dạng: không được đăng ký thành công. | Mobile: trường email và phản hồi validation. API: trường `email`; API spec không nêu ví dụ phản hồi lỗi cho format sai. | SRS `README.md`, FR-01 (dòng 33); API specification §1.1 (dòng 12–21) xác định field email, nhưng không định nghĩa format/error response chi tiết. |
| **D-R04** | Email phải là duy nhất trong hệ thống. | Email hợp lệ có trạng thái **chưa tồn tại** hoặc **đã tồn tại**. | Chưa tồn tại → đăng ký thành công có thể tạo một tài khoản. Đã tồn tại → từ chối tạo bản ghi trùng; tài khoản cũ vẫn tồn tại. | Mobile: kết quả đăng ký. API: phản hồi `POST /api/register`; quan sát trạng thái tài khoản bằng cách phù hợp nếu có. Status/body cụ thể khi trùng chưa được quy định. | SRS `README.md`, FR-01 (dòng 33); API specification §1.1 (dòng 12–21) xác định endpoint đăng ký nhưng không nêu response khi email trùng. |
| **D-R05** | Người dùng phải cung cấp mật khẩu. | Trường **Mật khẩu**. | Trước: chưa gửi. Có mật khẩu thì xét tiếp các điều kiện mạnh; thiếu mật khẩu thì không được đăng ký thành công. | Mobile: trường mật khẩu và phản hồi validation. API: body có `password`; API spec không mô tả lỗi khi thiếu. | SRS `README.md`, FR-01 (dòng 32, 34); API specification §1.1 (dòng 12–21). |
| **D-R06** | Mật khẩu phải dài ít nhất 8 ký tự, có ít nhất một chữ hoa, một chữ thường, một chữ số, và ít nhất một ký tự thuộc tập `@$!%*?&`. | Trường **Mật khẩu**; ví dụ hợp lệ đại diện `VinhTest8!` (dài hơn 8, có đủ các nhóm và `!` thuộc tập cho phép). | Trước: chưa gửi. Mật khẩu thỏa mọi điều kiện: đủ điều kiện xét đăng ký. Thiếu bất kỳ điều kiện nào: không được đăng ký thành công. | Mobile: phản hồi validation. API: trường `password` được gửi khi đăng ký; phản hồi lỗi cụ thể chưa được API spec quy định. | SRS `README.md`, FR-01 (dòng 34); API specification §1.1 (dòng 12–21) xác định field password nhưng không nhắc quy tắc/response lỗi. |
| **D-R07** | Form Mobile phải có trường **Xác nhận mật khẩu** và hệ thống phải từ chối khi mật khẩu với xác nhận không khớp. Giá trị xác nhận phải được cung cấp trong luồng form. | Hai input trên Mobile: **Mật khẩu** và **Xác nhận mật khẩu**; cần so sánh hai giá trị. | Trước: chưa gửi. Hai giá trị được cung cấp và khớp → đủ điều kiện tiếp tục. Xác nhận thiếu hoặc không khớp → không được đăng ký thành công. | Mobile: trường xác nhận hiện diện, giá trị được nhập và thông báo/kết quả khi submit. API: API specification không có `confirmPassword` trong body mẫu; không coi đây là field của endpoint nếu hợp đồng chưa cập nhật. | SRS `README.md`, FR-01 (dòng 35) yêu cầu trường xác nhận và từ chối khi không khớp; phân công thành viên 2, Pool D (dòng 50–52) yêu cầu kiểm tra form trên Mobile. API specification §1.1 (dòng 12–21) chỉ liệt kê `name`, `email`, `password`. |
| **D-R08** | Khi mọi điều kiện đăng ký hợp lệ và email chưa tồn tại, hệ thống tạo tài khoản. | Họ tên, email mới hợp lệ, mật khẩu hợp lệ; form xác nhận khớp. | Trước: email chưa có tài khoản. Sau thành công: tài khoản với email đó tồn tại một lần. | Mobile: thông báo/kết quả thành công. API: `POST /api/register`, JSON body gồm `name`, `email`, `password`; thành công trả `200 OK` với `message: "User registered successfully"` và `id`. | SRS `README.md`, FR-01 (dòng 32–35); API specification §1.1 (dòng 12–21) cho endpoint, body và response thành công; FR-20 (dòng 233–235) đặt Đăng ký trong phạm vi Mobile. |
| **D-R09** | Sau đăng ký thành công, Mobile chuyển người dùng tới màn hình Đăng nhập. | Thao tác submit bộ dữ liệu đăng ký hợp lệ. | Trước: đang ở form Đăng ký. Sau thành công: ở màn hình Đăng nhập. | Mobile: màn hình sau submit là Đăng nhập. API: không có API response riêng cho điều hướng. | SRS `README.md`, FR-01 (dòng 36); FR-20 (dòng 233–235) xác định ứng dụng Mobile có chức năng Đăng ký và Đăng nhập. |

##### 2. Ranh giới Mobile UI và API

- FR-20 xác định Đăng ký là một chức năng phải có trong ứng dụng Mobile. Do đó, expected về trường nhập, xác nhận mật khẩu và chuyển màn hình phải được quan sát trên Mobile UI; chỉ gọi API không chứng minh các hành vi giao diện này.
- API specification định nghĩa `POST /api/register` với `name`, `email`, `password`, và phản hồi thành công `200 OK` gồm `message` và `id`. Tài liệu không định nghĩa mã HTTP, body lỗi hay câu chữ lỗi cho các trường hợp bị từ chối.
- `confirmPassword` có trong yêu cầu form FR-01 nhưng không có trong body API mẫu. Trong phạm vi tài liệu hiện tại, xác nhận mật khẩu là điều kiện của Mobile UI; không tự thêm field vào hợp đồng API.
- Các lỗi về input được mô tả là **không được đăng ký thành công** theo yêu cầu bắt buộc/từ chối. Câu chữ, vị trí lỗi, status HTTP và cấu trúc body lỗi vẫn chưa có oracle cụ thể.

##### 3. Điểm cần xác minh, chưa tự đặt expected

1. **Trim và khoảng trắng:** họ tên/email chỉ gồm dấu cách có được coi là rỗng không? Hệ thống có trim khoảng trắng đầu/cuối trước khi kiểm tra hay lưu không?
2. **Email:** phạm vi chính xác của định dạng hợp lệ ngoài ví dụ `user@domain.com`; email trùng được so sánh phân biệt hoa/thường hay chuẩn hóa chữ thường?
3. **Giới hạn độ dài:** SRS không nêu độ dài tối đa của họ tên, email, mật khẩu hoặc xác nhận mật khẩu.
4. **Mật khẩu:** tài liệu yêu cầu tối thiểu 8 ký tự và ít nhất một ký tự thuộc `@$!%*?&`; chưa nói cách đếm ký tự Unicode, các chữ số/hoa/thường ngoài ASCII, hoặc có cấm thêm ký tự đặc biệt khác hay không.
5. **Xác nhận mật khẩu:** API spec không có field này. Cần xác nhận đây chỉ là kiểm tra ở Mobile hay có hợp đồng API khác được lớp yêu cầu.
6. **Thông báo lỗi:** chưa có câu chữ, vị trí hiển thị, thứ tự ưu tiên khi nhiều input sai, hoặc status/body lỗi API được quy định cho đăng ký thất bại.
7. **Lỗi mạng và gửi lặp:** chưa nói khi mất mạng, timeout, bấm submit nhiều lần, hoặc response bị mất sau khi server đã tạo tài khoản thì app phải hiển thị/tránh tạo trùng thế nào.
8. **Giữ dữ liệu form:** chưa quy định form giữ hay xóa các giá trị sau khi đăng ký thất bại.

##### 4. Phạm vi và trạng thái tài liệu

- Thành viên 2 được phân công **Mobile FR-01: Đăng ký trên Mobile**; đây là phạm vi D-MREG.
- Slide Domain Testing hướng dẫn xác định input/output, phân hoạch lớp tương đương hợp lệ/không hợp lệ và chọn đại diện. Slide BVA áp dụng cho input có thứ tự/điểm biên. File này mới trích yêu cầu và nguồn expected; chưa tạo EC, test case Domain/BVA hoặc coverage.
- Chưa chạy test; chưa ghi actual, Pass/Fail, human review hay trạng thái phê duyệt.

##### Nguồn

- SRS: `eshop-sut/README.md`, FR-01 dòng 30–36; FR-20 dòng 233–235.
- API: `eshop-sut/api_specification.md`, Authentication §1.1, dòng 11–21.
- Phân công: `group_feature_assignment.md`, thành viên 2 Pool D, dòng 15 và 50–52.
- Slide: [`slide/domain-testing-vn.pdf`](../slide/domain-testing-vn.pdf), Domain Testing bước xác định input/output, phân lớp và chọn đại diện (trang 6–10); BVA và giá trị lân cận (trang 19–23). [`slide/domain-testing-en.pdf`](../slide/domain-testing-en.pdf), tương ứng phần Domain Testing (trang 13–19) và BVA (trang 20–24).

#### 02-domains — D-MREG

**Nguồn oracle:** 01-requirements.md, dựa trên FR-01/FR-20, API specification và phân công thành viên 2. Đây là thiết kế lớp dữ liệu, chưa phải test case hay kết quả chạy. Expected không lấy từ mã nguồn SUT.

##### 1. Quy ước khi đọc các lớp

- Mỗi **D-EC** là một nhóm input/trạng thái có cùng expected theo yêu cầu. Các đại diện chỉ minh họa miền; chưa được chạy.
- Khi xét một trường, giữ các trường khác hợp lệ để lỗi có thể quy về điều kiện đang xét. Với password thiếu một nhóm ký tự, vẫn giữ độ dài từ 8 trở lên và đủ các nhóm còn lại.
- **Không được đăng ký thành công** là oracle từ yêu cầu bắt buộc/điều kiện từ chối. Câu chữ báo lỗi, HTTP status và body lỗi chưa được đặc tả nên không được tự đặt.
- Confirmation password là input của Mobile UI; API spec không đưa field này vào JSON đăng ký. Lớp xác nhận chỉ có expected ở Mobile.
- Các lớp network/error nơi chưa có oracle được ghi là **chưa chốt / observation**, không gán Pass/Fail.

##### 2. Họ tên — D-R01

| D-EC | Điều kiện lớp | Đại diện cụ thể | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|
| **D-EC-01** | Không cung cấp họ tên | `name = ""`; các input còn lại hợp lệ | Không được đăng ký thành công vì họ tên bắt buộc. Không tự đặt status/body hoặc câu báo lỗi. | Mobile: phản hồi trên form và có chuyển màn hình thành công hay không. API: không có lỗi thiếu name được định nghĩa trong API spec. | D-R01 |
| **D-EC-02** | Họ tên có giá trị thông thường | `Nguyen Le The Vinh`; các input khác hợp lệ | Đạt điều kiện “phải cung cấp họ tên”; đăng ký chỉ thành công nếu các điều kiện còn lại cũng đạt. | Mobile: giá trị nhập; API: field `name` trong body nếu request được gửi. | D-R01, D-R08 |

Khoảng trắng-only và cách trim họ tên chưa được xếp valid/invalid vì yêu cầu chưa định nghĩa cách xử lý; xem câu hỏi Q-01.

##### 3. Email — D-R02, D-R03, D-R04

| D-EC | Điều kiện lớp | Đại diện cụ thể | Trạng thái trước | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|---|
| **D-EC-03** | Bỏ trống email | `email = ""`; các input khác hợp lệ | Chưa gửi request | Không được đăng ký thành công vì email bắt buộc. Lỗi/status cụ thể chưa có oracle. | Mobile: phản hồi. API: request/body và phản hồi nếu gửi; API spec không quy định lỗi này. | D-R02 |
| **D-EC-04** | Email sai định dạng | `vinh.example.com`; họ tên/mật khẩu/confirm hợp lệ | Email này không được dùng làm tài khoản test đã tồn tại | Không được đăng ký thành công vì email không đúng ví dụ định dạng yêu cầu. Quy tắc grammar chi tiết và lỗi cụ thể chưa chốt. | Mobile/API: kết quả từ chối hay tiếp tục; không tự đặt thông báo/status. | D-R03 |
| **D-EC-05** | Email đúng định dạng, chưa có tài khoản | `vinh.new@example.com` (dùng địa chỉ test duy nhất); email chưa tồn tại | Tìm được trạng thái chưa có account | Email thỏa format và uniqueness; với các input khác hợp lệ, có thể đăng ký thành công. | Mobile: kết quả submit. API: thành công theo response contract nếu request thành công. | D-R03, D-R04, D-R08 |
| **D-EC-06** | Email đúng định dạng, đã có tài khoản | `existing.user@example.com`; tạo/chuẩn bị account trước bằng fixture test | Đã có đúng một account với email này | Phải từ chối tạo account trùng; account cũ vẫn tồn tại. Status/body lỗi chưa được quy định. | Mobile: phản hồi. API: response và state account nếu đọc được an toàn. | D-R03, D-R04 |

Không gộp D-EC-04 với D-EC-06: một lớp vi phạm format, lớp kia có format hợp lệ nhưng vi phạm uniqueness. Không giả định email phân biệt hoa/thường hoặc được trim; xem Q-02/Q-03.

##### 4. Mật khẩu — D-R05, D-R06

Các đại diện dưới đây chỉ xét mật khẩu; họ tên, email mới hợp lệ và confirm được đặt hợp lệ. Tập ký tự đặc biệt cần có **ít nhất một ký tự thuộc `@$!%*?&`**; không yêu cầu chuỗi chứa tất cả ký tự trong tập.

| D-EC | Điều kiện lớp | Đại diện cụ thể | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|
| **D-EC-07** | Mật khẩu rỗng | `""` | Không được đăng ký thành công vì password bắt buộc. | Mobile: phản hồi validation. API: lỗi cụ thể chưa được nêu. | D-R05 |
| **D-EC-08** | Dài dưới 8, nhưng đủ mọi nhóm ký tự | `Aa1!bbb` (7 ký tự: hoa, thường, số, ký tự thuộc tập đều có) | Không được đăng ký thành công do không đạt tối thiểu 8; các điều kiện nhóm ký tự khác vẫn đạt. | Mobile: validation; không tự đặt câu chữ. API: status/body lỗi chưa có oracle. | D-R06 |
| **D-EC-09** | Dài đúng 8 và đủ mọi nhóm | `Aa1!bbbb` (8 ký tự) | Đạt điều kiện độ dài và nhóm ký tự. Đăng ký có thể thành công nếu các input/trạng thái khác hợp lệ. | Mobile: kết quả validation/submit. API: response success nếu request hợp lệ. | D-R06, D-R08 |
| **D-EC-10** | Dài trên 8 và đủ mọi nhóm | `Aa1!bbbbb` (9 ký tự) | Đạt điều kiện độ dài tối thiểu và nhóm ký tự. Không có upper bound được nêu. | Mobile/API: kết quả; không suy diễn giới hạn trên. | D-R06 |
| **D-EC-11** | Thiếu chữ hoa; các điều kiện còn lại đạt | `aa1!bbbb` (8 ký tự, có thường/số/`!`) | Không được đăng ký thành công do thiếu chữ hoa. | Mobile: validation. | D-R06 |
| **D-EC-12** | Thiếu chữ thường; các điều kiện còn lại đạt | `AA1!BBBB` (8 ký tự, có hoa/số/`!`) | Không được đăng ký thành công do thiếu chữ thường. | Mobile: validation. | D-R06 |
| **D-EC-13** | Thiếu chữ số; các điều kiện còn lại đạt | `Aa!!bbbb` (8 ký tự, có hoa/thường/`!`) | Không được đăng ký thành công do thiếu chữ số. | Mobile: validation. | D-R06 |
| **D-EC-14** | Thiếu ký tự thuộc tập đặc biệt cho phép; các điều kiện còn lại đạt | `Aa12bbbb` (8 ký tự, có hoa/thường/số, không có ký tự nào thuộc tập) | Không được đăng ký thành công do thiếu ký tự thuộc `@$!%*?&`. | Mobile: validation. | D-R06 |

Unicode, cách đếm ký tự, và việc chấp nhận các ký tự đặc biệt khác ngoài tập khi chúng xuất hiện thêm chưa được quy định; không phân loại chúng thành valid/invalid ở đây (Q-04).

##### 5. Xác nhận mật khẩu — D-R07

Các lớp này chỉ áp dụng cho Mobile UI. Password chính dùng đại diện hợp lệ `Aa1!bbbb`; các input khác hợp lệ và email chưa tồn tại.

| D-EC | Điều kiện lớp | Đại diện cụ thể | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|
| **D-EC-15** | Confirm khớp password | `password = Aa1!bbbb`; `confirm = Aa1!bbbb` | Đạt điều kiện so khớp; các điều kiện khác vẫn phải đạt để đăng ký thành công. | Mobile: hai giá trị nhập và kết quả submit. Không gửi confirm lên API theo contract hiện tại. | D-R07, D-R08 |
| **D-EC-16** | Confirm không khớp | `password = Aa1!bbbb`; `confirm = Aa1!bbbc` | Hệ thống từ chối đăng ký khi hai giá trị không khớp. Không tự đặt câu chữ lỗi. | Mobile: phản hồi và việc có chuyển Login/đăng ký thành công hay không. API spec không có confirm field. | D-R07 |
| **D-EC-17** | Confirm bỏ trống | `password = Aa1!bbbb`; `confirm = ""` | Theo yêu cầu form, confirmation phải được cung cấp và khớp; không được đăng ký thành công. Câu chữ/status chưa chốt. | Mobile: phản hồi. Không thể kiểm tra input này bằng request API trực tiếp theo contract hiện tại. | D-R07 |

##### 6. Trạng thái API và kết nối

Các trạng thái này là đầu ra/môi trường, không phải input người dùng. Chỗ tài liệu không định nghĩa lỗi được giữ ở mức câu hỏi/probe.

| D-EC | Trạng thái | Ví dụ/điều kiện | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|
| **D-EC-18** | API nhận đăng ký hợp lệ và trả thành công | `POST /api/register`, body có `name`, email mới, `password`; các điều kiện FR-01 đạt | API spec nêu `200 OK` và JSON gồm `message: "User registered successfully"`, `id`. Account được tạo. | HTTP status/body; state account nếu có cách kiểm tra chỉ đọc. | D-R08 |
| **D-EC-19** | API nhận request nhưng từ chối input không hợp lệ/trùng email | Ví dụ email hợp lệ đã tồn tại hoặc field bắt buộc thiếu; mỗi lần xét chỉ có một điều kiện sai | FR-01 yêu cầu không đăng ký thành công đối với điều kiện sai. API spec không nêu status/body lỗi hoặc cách map validation UI/API. | Ghi response và state; không đánh giá status/message theo oracle chưa có. | D-R01–D-R06, D-R08 |
| **D-EC-20** | Network/API hoạt động, có thể trao đổi request-response | Backend reachable; một request đăng ký có kết quả trả về | Khi đăng ký hợp lệ, áp dụng contract success D-EC-18; khả năng kết nối tự thân không phải kết quả chức năng. | Timestamp, request/response đã che mật khẩu/token. | D-R08; API §1.1 |
| **D-EC-21** | Network/API không truy cập được hoặc request timeout | Backend không reachable, mất kết nối hoặc timeout | **Chưa có expected result** trong SRS/API cho thông báo, giữ form, retry hay trạng thái account. Không gán pass/fail; chỉ ghi observation khi được thiết kế/chạy sau. | Lỗi kết nối trên Mobile, trạng thái form và trạng thái account nếu xác minh được. | Q-06; D-R08 |

##### 7. Trạng thái màn hình Mobile

| D-EC | Trạng thái app | Điều kiện/đại diện | Expected | Quan sát | Liên quan |
|---|---|---|---|---|---|
| **D-EC-22** | Đang ở form Register trước khi submit | Mở luồng Đăng ký, form sẵn sàng nhận input | Trạng thái bắt đầu hợp lệ; form cần có họ tên, email, mật khẩu và xác nhận mật khẩu theo FR-01. Chi tiết bố cục/thông báo chưa định nghĩa ở nguồn đang dùng. | Màn hình và sự hiện diện/có thể nhập của bốn trường; dữ liệu sau khi nhập. | D-R01–D-R07; FR-01, FR-20 |
| **D-EC-23** | Chuyển sang Login sau đăng ký thành công | Chỉ sau một đăng ký hợp lệ được chấp nhận | Mobile chuyển tới màn hình Đăng nhập. Đây là trạng thái sau hợp lệ được FR-01 nêu. | Màn hình hiện tại sau submit; API không thể chứng minh điều hướng. | D-R08, D-R09 |
| **D-EC-24** | Kết quả thất bại khi app vẫn ở Register hay chuyển màn khác | Submit dữ liệu sai hoặc gặp lỗi mạng | **Chưa có oracle điều hướng/giữ dữ liệu khi thất bại**; không giả định app phải ở lại Register dù đó là hành vi thường gặp. | Ghi màn hình thực tế và dữ liệu form nếu sau này chạy; không gán expected. | D-R01–D-R07, câu hỏi D-R08 |

Login trước khi bắt đầu đăng ký là một trạng thái workflow khác, không tự xem là invalid: cần đi vào luồng Register trước khi nhập form. Nguồn hiện tại chưa nêu cách điều hướng cụ thể từ Login sang Register; ghi nhận ở Q-05.

##### 8. Câu hỏi/miền thăm dò chưa có expected

- **Q-01 — Họ tên/khoảng trắng:** `name = "   "` có được coi là thiếu không? Có trim đầu/cuối không?
- **Q-02 — Email có khoảng trắng:** `" vinh.new@example.com "` có được trim trước khi validate/lưu không?
- **Q-03 — Email normalization:** format hợp lệ ngoài ví dụ nào được chấp nhận? So uniqueness có phân biệt hoa/thường không?
- **Q-04 — Unicode/password:** Unicode được tính độ dài như thế nào? Chữ hoa/thường và chữ số Unicode có được tính? Nếu password có thêm ký tự đặc biệt ngoài `@$!%*?&`, nó được chấp nhận hay từ chối?
- **Q-05 — Navigation:** cách mở Register từ Home/Login và hành vi form sau failure chưa được mô tả đầy đủ.
- **Q-06 — Error contract:** message, HTTP status/body, thứ tự ưu tiên khi nhiều field sai, network retry và gửi lặp chưa được nêu.
- **Q-07 — Email uniqueness race:** hai request đồng thời cho cùng email sẽ được xử lý thế nào chưa có oracle.

Các probe Q-01–Q-07 chưa được xếp vào lớp valid/invalid có expected; chúng cần clarification hoặc chỉ được ghi observation, không dùng để kết luận bug.

##### 9. Lý do phân lớp

- Mỗi điều kiện bắt buộc hoặc định dạng/uniqueness có nhóm đạt và nhóm vi phạm riêng; đại diện sai email format và email đã tồn tại tách biệt để không nhập nhằng giữa cú pháp và trạng thái hệ thống.
- Password được chia theo điểm dưới/đúng/trên ngưỡng tối thiểu và theo từng nhóm ký tự bắt buộc. Các mẫu thiếu một nhóm vẫn dài 8 ký tự và có các nhóm khác để cô lập nguyên nhân.
- Confirm được chia khớp/không khớp/rỗng vì các trạng thái có expected khác nhau ở UI. Không tạo lớp API riêng cho confirm vì endpoint không nhận field này trong contract.
- API success, API rejection và network failure là các trạng thái đầu ra khác nhau. Chỉ response success có status/body rõ trong API spec; lỗi API/network thiếu oracle nên không được gán kết quả cụ thể.
- Register/Login được mô tả như trạng thái workflow trước/sau. Chỉ chuyển sang Login sau success là expected rõ; điều hướng/error state sau failure còn cần xác minh.

##### Trạng thái

Chưa tạo test case Domain/BVA, chưa chạy SUT, chưa ghi actual/Pass/Fail, chưa có human review hay phê duyệt.

##### Nguồn

- 01-requirements.md, D-R01–D-R09.
- SRS: eshop-sut/README.md, FR-01 và FR-20.
- API: eshop-sut/api_specification.md, §1.1.
- Phân công: group_feature_assignment.md, thành viên 2, Pool D.
- Slide Domain/BVA: [domain-testing-vn.pdf](../slide/domain-testing-vn.pdf), trang 6–10 và 19–23; [domain-testing-en.pdf](../slide/domain-testing-en.pdf), trang 13–19 và 20–24.

#### 03-domain-cases — D-MREG

**Thiết bị thiết kế:** Android Emulator AVD `Pixel 9`, Android 15 / API 35, Expo Go SDK 54 (hoặc thiết bị Android thật; khi chạy phải ghi model và Android version thực tế). Baseline app và backend ghi theo `reports/environment.md` tại thời điểm thực thi.

**Phạm vi:** kiểm tra form đăng ký bằng thao tác trên Mobile UI. Không gọi API riêng để thay thế kiểm tra giao diện. API response và trạng thái account chỉ là bằng chứng bổ sung cho hành động submit từ app. File này chỉ thiết kế ca: chưa chạy, chưa điền actual/status và chưa có human review.

##### Cách dùng chung cho từng ca

- **Bắt đầu độc lập:** mở app trên emulator/thiết bị, từ Home chạm **Đăng nhập**, rồi dùng liên kết trên màn hình Login để mở **Đăng ký**. Ghi đúng nhãn UI nếu khác. Không xóa database, account mẫu hoặc account test cũ. Nếu chưa vào được Register, lưu ảnh màn hình và đánh dấu các ca phụ thuộc form là Blocked khi thực thi; vẫn chạy các ca độc lập có thể làm.
- **Làm sạch form:** bắt đầu mỗi ca ở Register mới. Với từng ô cần nhập, chạm ô, nhấn giữ nội dung → **Chọn tất cả** → Backspace; nếu ô trống thì để nguyên. Nhập dữ liệu theo thứ tự họ tên, email, mật khẩu, xác nhận. Trường mật khẩu phải để chế độ ẩn; không bấm nút hiện mật khẩu. Sau khi nhập, chạm vùng tiêu đề để ẩn bàn phím, chụp checkpoint form, cuộn nếu cần để thấy nút submit, rồi chạm nút đăng ký một lần. Ghi nhãn nút thực tế nếu khác.
- **Dữ liệu:** mọi chuỗi mật khẩu dưới đây là dữ liệu giả dành riêng cho kiểm thử, không phải mật khẩu thật. Không ghi password vào tên ảnh, log công khai hoặc AI Audit. Ảnh chụp phải giữ trường mật khẩu được che.
- **Email chưa tồn tại:** với ca cần email mới, kiểm tra trước bằng truy vấn chỉ đọc trên database của backend test (nếu được phép): `SELECT COUNT(*) FROM users WHERE email = ?` với email cụ thể làm bind parameter; kết quả tiền điều kiện phải là 0. Nếu không có quyền đọc DB, ghi rõ cách xác minh khác và không tuyên bố chắc chắn email mới.
- **Xác nhận không tạo account khi bị từ chối:** sau mỗi submit âm, dùng kết nối DB chỉ đọc tới database của backend test và truy vấn cùng bảng/field bằng bind parameter; expected là số account theo email vẫn 0 (ca trùng email phải còn đúng 1). Không chạy lệnh ghi/xóa. Lưu query đã bỏ bí mật và kết quả count trong evidence. Nếu không thể truy vấn an toàn, ghi phần account state là chưa xác minh; không suy ra từ việc UI báo lỗi.
- **Expected lỗi:** “bị từ chối/không đăng ký thành công” nghĩa là không tạo account mới và không có điều hướng thành công tới Login. Không yêu cầu câu chữ, màu sắc hay vị trí thông báo cụ thể vì SRS/API không quy định. Có thể chụp thông báo thực tế nhưng không chấm câu chữ.
- **Evidence:** lưu ảnh checkpoint trước submit và sau submit dưới `evidence/D-MREG/` theo tên nêu ở mỗi ca. Đối với ca có kết quả account, lưu thêm redacted response/request hoặc kết quả DB read-only nếu quan sát được. Không chụp bàn phím nếu làm lộ dữ liệu nhạy cảm; dùng dữ liệu giả.
- **Ký hiệu:** `[điền khi chạy]` là thông tin môi trường cần ghi vào execution log; không phải actual của file thiết kế. Một ca chưa được chạy không được đánh dấu Pass/Fail.

##### Danh sách ca

###### D-DT-001 — Form đăng ký có đủ bốn trường

- **Mục tiêu:** kiểm tra hiện diện và khả năng nhập của họ tên, email, mật khẩu, xác nhận mật khẩu.
- **Loại:** Mobile UI — kiểm tra sự hiện diện.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi model/OS/API thực tế khi dùng thiết bị thật.
- **Trạng thái app:** mở app → Home → Login → Register; chưa submit, form mới.
- **Account/email:** không cần account; chưa nhập email.
- **Dữ liệu:** không nhập.
- **Thao tác:** (1) mở Register theo quy trình chung; (2) quan sát từng ô; (3) chạm lần lượt từng ô và xác nhận bàn phím/nhập liệu có thể sử dụng; (4) ẩn bàn phím bằng cách chạm vùng tiêu đề; (5) chụp toàn bộ form, cuộn để quan sát phần dưới nếu form dài.
- **Expected:** form Mobile có đủ bốn trường theo D-R01, D-R02, D-R05, D-R07. Không có yêu cầu về bố cục hay nhãn chính xác ngoài ý nghĩa trường.
- **EC / requirement:** D-EC-22; D-R01, D-R02, D-R05, D-R07.
- **Phụ thuộc:** nếu thiếu trường, lưu ảnh và khi thực thi đánh dấu các ca cần trường đó là Blocked; vẫn tiếp tục ca không phụ thuộc được.
- **Evidence:** `evidence/D-MREG/D-DT-001-form-four-fields.png` (có thể thêm ảnh riêng sau cuộn nếu không thấy đủ bốn ô trong một ảnh).

###### D-DT-002 — Đăng ký thành công với email mới

- **Mục tiêu:** xác nhận một bộ dữ liệu hợp lệ được chấp nhận, tạo account và đưa app về Login.
- **Loại:** Mobile UI; API/DB chỉ bổ sung bằng chứng.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; backend test sẵn sàng; email chưa tồn tại.
- **Account/email:** email `vinh.dmreg.success01@example.com`, cần count 0 trước ca; sau thành công kỳ vọng count 1.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email `vinh.dmreg.success01@example.com`; mật khẩu giả `Aa1!bbbb`; xác nhận `Aa1!bbbb`.
- **Thao tác:** (1) nhập họ tên; (2) nhập email; (3) nhập password trong ô đang ẩn; (4) nhập confirm giống hệt; (5) chạm tiêu đề để ẩn bàn phím; (6) kiểm tra các ô đã được điền, chụp ảnh trước submit (password được che); (7) cuộn tới nút nếu cần và chạm submit đúng một lần; (8) chụp màn hình sau phản hồi; (9) quan sát màn hình hiện tại; (10) kiểm tra account bằng DB read-only hoặc response API của request do app gửi.
- **Expected:** với các điều kiện hợp lệ và email mới, account được tạo; API success contract nếu quan sát được là 200 với `message` và `id`; Mobile chuyển tới Login. Không đặt câu chữ thông báo thành công vì chưa được quy định.
- **EC / requirement:** D-EC-02, D-EC-05, D-EC-09, D-EC-15, D-EC-18, D-EC-22, D-EC-23; D-R01–D-R09.
- **Evidence:** `evidence/D-MREG/D-DT-002-before-submit.png`, `evidence/D-MREG/D-DT-002-login-after-success.png`, và bản ghi redacted response/count. Không lưu mật khẩu.

###### D-DT-003 — Họ tên để trống

- **Mục tiêu:** cô lập kiểm tra họ tên bắt buộc.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới, email chưa tồn tại.
- **Account/email:** `vinh.dmreg.nameempty@example.com`, count 0 trước và sau khi bị từ chối.
- **Dữ liệu:** họ tên rỗng; email `vinh.dmreg.nameempty@example.com`; password `Aa1!bbbb`; confirm `Aa1!bbbb`.
- **Thao tác:** để trống họ tên; nhập ba trường còn lại; chạm vùng tiêu đề để ẩn bàn phím; chụp trước submit; chạm submit một lần; chụp phản hồi; xác minh count email bằng DB chỉ đọc.
- **Expected:** không được đăng ký thành công vì họ tên bắt buộc; không tạo account. Không kết luận cách xử lý họ tên chỉ có khoảng trắng.
- **EC / requirement:** D-EC-01, D-EC-05, D-EC-09, D-EC-15, D-EC-19; D-R01, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-003-name-empty-before.png`, `evidence/D-MREG/D-DT-003-name-empty-after.png`, read-only count.

###### D-DT-004 — Email để trống

- **Mục tiêu:** cô lập kiểm tra email bắt buộc.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới.
- **Account/email:** không có email để truy vấn; các input khác hợp lệ. Trước submit, ghi tổng số account trong DB test bằng `SELECT COUNT(*) FROM users`; sau phản hồi đối chiếu tổng số này trong cùng DB.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email rỗng; password `Aa1!bbbb`; confirm `Aa1!bbbb`.
- **Thao tác:** nhập họ tên; để trống email; nhập hai trường password; ẩn bàn phím; chụp trước submit; chạm submit một lần; chụp kết quả và quan sát có chuyển Login không.
- **Expected:** không đăng ký thành công do email bắt buộc; không tạo account mới, nên tổng số account trong DB test không tăng trong khoảng ca. Dùng DB test riêng và ghi thời điểm chụp count để tránh nhầm với đăng ký đồng thời. SRS/API không chốt phản hồi cụ thể cho email rỗng. Lưu request/response đã che nếu app gửi request; không tự tạo expected mới.
- **EC / requirement:** D-EC-03, D-EC-09, D-EC-15, D-EC-19; D-R02, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-004-email-empty-before.png`, `evidence/D-MREG/D-DT-004-email-empty-after.png`, tổng count read-only trước/sau và redacted request/response nếu có.

###### D-DT-005 — Email sai định dạng

- **Mục tiêu:** kiểm tra một đại diện email sai định dạng, giữ các điều kiện khác hợp lệ.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới.
- **Account/email:** `vinh.dmreg.badformat@example` (không có phần domain dạng `domain.com`); trước ca chưa được dùng làm account test.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email `vinh.dmreg.badformat@example`; password/confirm `Aa1!bbbb`.
- **Thao tác:** nhập bốn trường như trên; ẩn bàn phím; chụp trước submit; chạm submit; chụp phản hồi; nếu app gửi request thì lưu redacted response; kiểm tra account state theo khóa email bằng DB chỉ đọc nếu field cho phép.
- **Expected:** không được đăng ký thành công vì email không theo dạng ví dụ hợp lệ `user@domain.com`; không tạo account mới. Quy tắc email chi tiết và câu chữ lỗi chưa được quy định.
- **EC / requirement:** D-EC-04, D-EC-09, D-EC-15, D-EC-19; D-R03, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-005-email-format-before.png`, `evidence/D-MREG/D-DT-005-email-format-after.png`, redacted response/count nếu quan sát được.

###### D-DT-006 — Email hợp lệ nhưng đã tồn tại

- **Mục tiêu:** kiểm tra tính duy nhất của email, không gộp với lỗi định dạng.
- **Loại:** Mobile UI; DB read-only trước/sau.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** trước test phải có đúng một account fixture do kiểm thử tạo; sau khi chuẩn bị fixture, mở Register mới.
- **Account/email:** fixture test `vinh.dmreg.fixture@example.com`, count 1. Nếu chưa có fixture, tạo trước bằng luồng UI với bộ dữ liệu hợp lệ dành riêng cho fixture và ghi evidence/setup riêng; không dùng account mẫu hoặc email của người thật. Không xóa fixture.
- **Dữ liệu mục tiêu:** họ tên `Nguyen Le The Vinh Duplicate`; email fixture `vinh.dmreg.fixture@example.com`; password `Aa1!bbbb`; confirm `Aa1!bbbb`.
- **Thao tác:** xác minh count fixture là 1; mở Register mới; nhập dữ liệu mục tiêu; ẩn bàn phím; chụp trước submit; chạm submit một lần; chụp phản hồi; kiểm tra count vẫn bằng 1 và account fixture vẫn tồn tại bằng DB read-only.
- **Expected:** từ chối tạo account trùng theo yêu cầu uniqueness; account ban đầu vẫn còn đúng một bản ghi. Không tự đặt status/body/câu thông báo.
- **EC / requirement:** D-EC-06, D-EC-09, D-EC-15, D-EC-19; D-R03, D-R04, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-006-existing-email-before.png`, `evidence/D-MREG/D-DT-006-existing-email-after.png`, fixture setup reference, read-only count trước/sau, redacted response nếu có.

###### D-DT-007 — Mật khẩu để trống

- **Mục tiêu:** cô lập điều kiện password bắt buộc.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.pass-empty@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password rỗng; confirm rỗng.
- **Thao tác:** nhập họ tên/email; để password và confirm rỗng; ẩn bàn phím; chụp trước submit; chạm submit một lần; chụp phản hồi; kiểm tra count email bằng DB read-only.
- **Expected:** không đăng ký thành công vì password bắt buộc; không tạo account. Confirm cũng rỗng nhưng D-R07 yêu cầu confirm bắt buộc, do đó để đảm bảo ca âm chỉ có một điều kiện sai, **không dùng ca này để kết luận hành vi confirm rỗng**. Confirm cần được điền hợp lệ nếu UI cho phép mà password rỗng không; nếu form bắt buộc so khớp để nhận confirm, ghi rõ ràng buộc tương tác và không kết luận riêng phần confirm.
- **EC / requirement:** D-EC-07, D-EC-15 (confirm được cung cấp cùng giá trị rỗng không thể khớp password rỗng; xem ghi chú độc lập bên dưới), D-EC-19; D-R05, D-R08.
- **Giới hạn cô lập:** password rỗng khiến không thể có confirm khác rỗng mà vẫn khớp. Đây là ràng buộc dữ liệu giữa hai trường; ca kiểm tra password rỗng đồng thời làm confirm rỗng. Không tính đây là bằng chứng riêng cho D-R07. Nếu SUT cho confirm rỗng nhưng có validation độc lập, ghi observation.
- **Evidence:** `evidence/D-MREG/D-DT-007-password-empty-before.png`, `evidence/D-MREG/D-DT-007-password-empty-after.png`, count nếu quan sát được.

###### D-DT-008 — Mật khẩu thiếu chữ hoa

- **Mục tiêu:** cô lập điều kiện chữ hoa; độ dài, chữ thường, chữ số và ký tự thuộc tập đều hợp lệ.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.no-upper@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `aa1!bbbb` (8 ký tự); không có chữ hoa, có chữ thường, số và `!`.
- **Thao tác:** nhập từng trường; với password dùng bàn phím hiện lên, giữ ô secure text; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; query count chỉ đọc.
- **Expected:** từ chối do thiếu chữ hoa; không tạo account. Không chấm câu chữ lỗi.
- **EC / requirement:** D-EC-11, D-EC-05, D-EC-15, D-EC-19; D-R06, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-008-no-uppercase-before.png`, `evidence/D-MREG/D-DT-008-no-uppercase-after.png`, count/response nếu có.

###### D-DT-009 — Mật khẩu thiếu chữ thường

- **Mục tiêu:** cô lập điều kiện chữ thường; các điều kiện password khác hợp lệ.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.no-lower@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `AA1!BBBB` (8 ký tự).
- **Thao tác:** nhập dữ liệu; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; kiểm tra count chỉ đọc.
- **Expected:** từ chối do thiếu chữ thường; không tạo account.
- **EC / requirement:** D-EC-12, D-EC-05, D-EC-15, D-EC-19; D-R06, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-009-no-lowercase-before.png`, `evidence/D-MREG/D-DT-009-no-lowercase-after.png`, count/response nếu có.

###### D-DT-010 — Mật khẩu thiếu chữ số

- **Mục tiêu:** cô lập điều kiện chữ số; độ dài và ba nhóm còn lại đạt.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.no-digit@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `Aa!!bbbb` (8 ký tự).
- **Thao tác:** nhập dữ liệu; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; query count chỉ đọc.
- **Expected:** từ chối do thiếu chữ số; không tạo account.
- **EC / requirement:** D-EC-13, D-EC-05, D-EC-15, D-EC-19; D-R06, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-010-no-digit-before.png`, `evidence/D-MREG/D-DT-010-no-digit-after.png`, count/response nếu có.

###### D-DT-011 — Mật khẩu thiếu ký tự thuộc tập cho phép

- **Mục tiêu:** kiểm tra membership của ít nhất một ký tự trong `@$!%*?&`; không yêu cầu có toàn bộ ký tự trong tập.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.no-special@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `Aa12bbbb` (8 ký tự; hoa/thường/số có mặt, không có ký tự thuộc tập yêu cầu).
- **Thao tác:** nhập dữ liệu; nếu ký tự cần nhập không có trên bàn phím hiện tại, chuyển layout ký hiệu rồi nhập; quay lại layout chữ nếu cần; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; query count chỉ đọc.
- **Expected:** từ chối do không có ký tự nào thuộc `@$!%*?&`; không tạo account. Không suy ra rằng ký tự đặc biệt khác bị cấm trong trường hợp password có chứa ký tự hợp lệ.
- **EC / requirement:** D-EC-14, D-EC-05, D-EC-15, D-EC-19; D-R06, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-011-no-allowed-special-before.png`, `evidence/D-MREG/D-DT-011-no-allowed-special-after.png`, count/response nếu có.

###### D-DT-012 — Xác nhận mật khẩu không khớp

- **Mục tiêu:** cô lập điều kiện hai trường password không khớp.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.confirm-mismatch@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password `Aa1!bbbb`; confirm `Aa1!bbbc`. Cả hai dài 8 và thỏa password policy; chỉ khác một ký tự nên mismatch là điều kiện sai duy nhất.
- **Thao tác:** nhập dữ liệu; sau mỗi ô password ẩn bàn phím/chuyển focus theo UI; nhập confirm khác một ký tự; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; query count chỉ đọc.
- **Expected:** từ chối đăng ký vì confirm không khớp; không tạo account. Không có kỳ vọng về câu chữ cụ thể hoặc API field `confirmPassword`.
- **EC / requirement:** D-EC-16, D-EC-05, D-EC-09, D-EC-19; D-R07, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-012-confirm-mismatch-before.png`, `evidence/D-MREG/D-DT-012-confirm-mismatch-after.png`, count/response nếu có.

###### D-DT-013 — Xác nhận mật khẩu để trống

- **Mục tiêu:** cô lập yêu cầu xác nhận phải được cung cấp trong form.
- **Loại:** Mobile UI; DB read-only hậu kiểm.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi thiết bị thật.
- **Trạng thái app:** Register mới; email chưa tồn tại.
- **Account/email:** `vinh.dmreg.confirm-empty@example.com`, count 0 trước/sau.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password `Aa1!bbbb`; confirm rỗng.
- **Thao tác:** nhập họ tên/email/password; để trống confirm; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; query count chỉ đọc.
- **Expected:** không đăng ký thành công vì confirm là trường bắt buộc theo yêu cầu form; không tạo account. Không yêu cầu thông báo cụ thể.
- **EC / requirement:** D-EC-17, D-EC-05, D-EC-09, D-EC-19; D-R07, D-R08.
- **Evidence:** `evidence/D-MREG/D-DT-013-confirm-empty-before.png`, `evidence/D-MREG/D-DT-013-confirm-empty-after.png`, count/response nếu có.

##### Phụ thuộc và giới hạn thiết kế

- D-DT-002 và fixture của D-DT-006 là các thao tác thành công riêng, mỗi lần dùng một email riêng. Không dùng lại email thành công cho ca thành công khác; D-DT-006 chỉ tái sử dụng email fixture đã tạo để kiểm tra uniqueness.
- Phụ thuộc trường: D-DT-002 cần đủ cả bốn trường; D-DT-003 cần họ tên; D-DT-004–D-DT-006 cần email; D-DT-007–D-DT-011 cần mật khẩu; D-DT-012–D-DT-013 cần xác nhận mật khẩu. Nếu field cần cho một ca không hiện diện/không thao tác được, lưu ảnh ở D-DT-001 và đánh dấu đúng ca phụ thuộc đó Blocked khi chạy. Tiếp tục các ca không phụ thuộc field vắng mặt.
- D-DT-003–D-DT-013 là các ca âm; trong từng ca chỉ một điều kiện nghiệp vụ bị vi phạm, ngoại trừ ràng buộc password rỗng/confirm rỗng đã giải thích ở D-DT-007. Ca D-DT-007 không được dùng làm bằng chứng cho hành vi confirm rỗng; D-DT-013 kiểm tra riêng confirm rỗng với password hợp lệ.
- Nếu không có đủ bốn trường, lưu bằng chứng ở D-DT-001. Ca cần trường vắng mặt phụ thuộc trường đó và khi thực thi phải ghi Blocked; ca độc lập vẫn tiếp tục. Không giả định có thể điền hoặc tương tác với control không tồn tại.
- Các câu hỏi về trim, Unicode, giới hạn độ dài, thông báo cụ thể, lỗi mạng, retry/gửi lặp và race condition vẫn là oracle chưa chốt trong `01-requirements.md`/`02-domains.md`; các ca trên không kết luận những hành vi đó.
- Không bao gồm BVA riêng; các boundary cases thuộc file BVA tiếp theo. Không điền actual, status hoặc kết luận bug trong tài liệu thiết kế này.

##### Nguồn

- 01-requirements.md, D-R01–D-R09.
- 02-domains.md, D-EC-01–D-EC-24.
- SRS `eshop-sut/README.md`, FR-01 và FR-20; API `eshop-sut/api_specification.md`, §1.1.
- Slide Domain Testing: [`slide/domain-testing-vn.pdf`](../slide/domain-testing-vn.pdf), trang 6–10; [`slide/domain-testing-en.pdf`](../slide/domain-testing-en.pdf), trang 13–19.

#### 04-boundary-cases — D-MREG

**Thiết bị thiết kế:** Android Emulator AVD `Pixel 9`, Android 15 / API 35, Expo Go SDK 54. Có thể dùng thiết bị Android thật; khi chạy phải ghi model và phiên bản OS/API thực tế.

**Nguồn:** `01-requirements.md` D-R01–D-R09; `02-domains.md` D-EC-08–D-EC-14; `03-domain-cases.md` D-DT-008–D-DT-011; SRS FR-01/FR-20 và slide Domain/BVA. Chỉ độ dài tối thiểu password có giới hạn số được nêu nên mới áp dụng BVA số học. Thiếu từng nhóm ký tự là ca robustness/EC riêng, không gọi là điểm biên độ dài.


##### Quy ước thực hiện và setup

- Mỗi ca chạy độc lập từ Home → **Đăng nhập** → liên kết mở **Đăng ký**; ghi lại nhãn UI nếu khác. Đảm bảo form mới. Nếu app không mở được Register, chụp ảnh và đánh dấu ca phụ thuộc là Blocked khi thực thi; tiếp tục ca độc lập có thể làm.
- Thiết bị mặc định là Pixel 9 / Android 15 / API 35 / Expo Go SDK 54. Khi dùng máy thật, thay bằng thông tin thiết bị thực tế trong execution log; không ghi giá trị dự kiến như môi trường đã chạy.
- Trước mỗi lần submit, kiểm tra email trong **DB backend test** bằng truy vấn chỉ đọc và bind parameter `SELECT COUNT(*) FROM users WHERE email = ?`. Email phải có count 0. Không dùng database mẫu để tạo account và không xóa account test sau khi chạy.
- Nhập họ tên `Nguyen Le The Vinh`; email theo từng ca; nhập password và confirm giống nhau. Giữ password ở chế độ ẩn. Sau nhập, chạm vùng tiêu đề để ẩn bàn phím, chụp ảnh form, cuộn nếu cần tới nút submit rồi chạm một lần. Sau submit chụp màn hình hiện tại và kiểm tra account state bằng DB read-only hoặc response của request do app gửi.
- Dùng các mật khẩu giả được nêu dưới đây, không phải mật khẩu thật. Không ghi password vào tên ảnh, AI Audit hay log chia sẻ; ảnh phải cho thấy password đã che.
- Tất cả D-BV-001–D-BV-007 cần thao tác được bốn trường của form. Nếu thiếu bất kỳ trường cần thiết nào, chụp bằng chứng hiện diện theo D-DT-001 và đánh dấu ca phụ thuộc đó Blocked khi chạy; tiếp tục ca nào vẫn có thể thực hiện mà không cần control bị thiếu.
- Với ca bị từ chối, hậu kiểm email có count 0. Với ca được chấp nhận, count dự kiến là 1 và Mobile tới màn hình Login. Không tự đặt câu chữ thông báo. Lỗi cụ thể, màu sắc hay vị trí báo lỗi không có expected trong SRS/API.
- `δ` là khoảng cách đến ngưỡng theo số ký tự: với ngưỡng tối thiểu 8, các giá trị `7, 8, 9` lần lượt là `LB−1`, `LB`, `LB+1`. Không có UB password được nêu.
- Lưu evidence dưới `evidence/D-MREG/`. Không điền actual/status vào thiết kế.

##### A. BVA độ dài password

###### D-BV-001 — Độ dài 7 (LB−1)

- **Phân loại:** BVA — điểm ngay dưới lower bound `LB=8`, `δ=1`.
- **Mục tiêu:** cô lập điều kiện độ dài tối thiểu. Password vẫn có chữ hoa, chữ thường, chữ số và ký tự thuộc tập cho phép.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới, chưa submit.
- **Account/email trước:** email `vinh.dmreg.len7@example.com` chưa tồn tại; DB test count 0.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email `vinh.dmreg.len7@example.com`; password `Aa1!bbb` (7 ký tự; hoa, thường, số và `!` đều có); confirm `Aa1!bbb`.
- **Thao tác:** (1) mở Register; (2) nhập tên/email; (3) nhập password 7 ký tự trong secure field; (4) nhập confirm trùng khớp; (5) ẩn bàn phím; (6) chụp form trước submit; (7) submit một lần; (8) chụp kết quả; (9) truy vấn count email chỉ đọc.
- **Expected:** bị từ chối vì password ngắn hơn 8; không tạo account, email vẫn count 0. Không gán expected cho câu chữ lỗi hay status/body API.
- **D-EC / D-R / TC liên quan:** D-EC-08 (dưới 8, đủ nhóm ký tự), D-EC-05, D-EC-15, D-R06, D-R08; liên hệ D-DT-008–D-DT-011 về từng nhóm ký tự nhưng đây không thay thế chúng.
- **Evidence:** `evidence/D-MREG/D-BV-001-len7-before.png`, `evidence/D-MREG/D-BV-001-len7-after.png`, DB count trước/sau và redacted response nếu app gửi request.

###### D-BV-002 — Độ dài 8 (LB)

- **Phân loại:** BVA — lower bound `LB=8`, `δ=0`.
- **Mục tiêu:** xác nhận giá trị đúng tại độ dài tối thiểu, đồng thời các nhóm ký tự khác đều đạt.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới, backend test sẵn sàng.
- **Account/email trước:** email `vinh.dmreg.len8@example.com` chưa tồn tại; DB test count 0. Đây là email riêng cho ca thành công này.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email `vinh.dmreg.len8@example.com`; password `Aa1!bbbb` (8 ký tự); confirm `Aa1!bbbb`.
- **Thao tác:** (1) vào Register mới; (2) nhập họ tên/email; (3) nhập mật khẩu 8 ký tự và confirm khớp; (4) ẩn bàn phím; (5) chụp form trước submit; (6) bấm submit một lần; (7) chụp màn hình sau phản hồi; (8) quan sát điều hướng; (9) xác minh account count.
- **Expected:** độ dài 8 đạt riêng điều kiện D-R06. Với các input còn lại hợp lệ và email mới, kỳ vọng đăng ký được chấp nhận, account count 1, API success contract nếu quan sát được là 200 với `message` và `id`, app chuyển tới Login. Kết quả tổng thể vẫn phụ thuộc các trường khác và kết nối/backend hoạt động.
- **D-EC / D-R / TC liên quan:** D-EC-09, D-EC-05, D-EC-15, D-EC-18, D-EC-23; D-R01–D-R09; D-DT-002 là ca thành công Domain với email khác.
- **Evidence:** `evidence/D-MREG/D-BV-002-len8-before.png`, `evidence/D-MREG/D-BV-002-len8-login.png`, read-only count trước/sau và redacted response.

###### D-BV-003 — Độ dài 9 (LB+1)

- **Phân loại:** BVA — ngay trên lower bound `LB=8`, `δ=1`. SRS không nêu upper bound.
- **Mục tiêu:** xác nhận độ dài trên ngưỡng vẫn đạt điều kiện tối thiểu; không suy ra giới hạn trên.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới, backend test sẵn sàng.
- **Account/email trước:** email `vinh.dmreg.len9@example.com` chưa tồn tại; DB test count 0. Dùng email riêng, không tái sử dụng email của D-BV-002.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email `vinh.dmreg.len9@example.com`; password `Aa1!bbbbb` (9 ký tự); confirm `Aa1!bbbbb`.
- **Thao tác:** (1) vào Register mới; (2) nhập họ tên/email; (3) nhập mật khẩu 9 ký tự và confirm khớp; (4) ẩn bàn phím; (5) chụp form trước submit; (6) bấm submit một lần; (7) chụp phản hồi; (8) quan sát màn Login; (9) xác minh account count.
- **Expected:** độ dài 9 đạt điều kiện “tối thiểu 8”; với các trường khác hợp lệ và email mới, kỳ vọng đăng ký thành công, account count 1 và điều hướng Login. Đây không phải kiểm tra UB; không kỳ vọng từ chối ở 9.
- **D-EC / D-R / TC liên quan:** D-EC-10, D-EC-05, D-EC-15, D-EC-18, D-EC-23; D-R01–D-R09; D-DT-002 là ca thành công Domain với email khác.
- **Evidence:** `evidence/D-MREG/D-BV-003-len9-before.png`, `evidence/D-MREG/D-BV-003-len9-login.png`, read-only count trước/sau và redacted response.

##### B. Ca robustness/EC — thiếu một nhóm ký tự

Các ca dưới đây không phải điểm BVA theo thứ tự. Mỗi password có độ dài 8 và giữ các điều kiện còn lại hợp lệ, chỉ thiếu một nhóm ký tự. Đây là các ca tương đương/robustness được liên kết tới D-DT-008–D-DT-011.

###### D-BV-004 — Robustness: thiếu chữ hoa

- **Phân loại:** EC/robustness, không phải BVA độ dài.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới.
- **Account/email trước:** `vinh.dmreg.rb-no-upper@example.com`, count 0.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `aa1!bbbb` (8 ký tự, thiếu chữ hoa duy nhất).
- **Thao tác:** mở Register; nhập bốn trường; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; kiểm tra email count read-only.
- **Expected:** bị từ chối vì thiếu chữ hoa theo D-R06; không tạo account. Không chấm câu chữ lỗi.
- **D-EC / D-R / TC liên quan:** D-EC-11; D-R06, D-R08; ca Domain D-DT-008.
- **Evidence:** `evidence/D-MREG/D-BV-004-no-uppercase-before.png`, `evidence/D-MREG/D-BV-004-no-uppercase-after.png`, count/response nếu có.

###### D-BV-005 — Robustness: thiếu chữ thường

- **Phân loại:** EC/robustness, không phải BVA độ dài.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới.
- **Account/email trước:** `vinh.dmreg.rb-no-lower@example.com`, count 0.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `AA1!BBBB` (8 ký tự, thiếu chữ thường duy nhất).
- **Thao tác:** mở Register; nhập bốn trường; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; kiểm tra email count read-only.
- **Expected:** bị từ chối vì thiếu chữ thường theo D-R06; không tạo account.
- **D-EC / D-R / TC liên quan:** D-EC-12; D-R06, D-R08; ca Domain D-DT-009.
- **Evidence:** `evidence/D-MREG/D-BV-005-no-lowercase-before.png`, `evidence/D-MREG/D-BV-005-no-lowercase-after.png`, count/response nếu có.

###### D-BV-006 — Robustness: thiếu chữ số

- **Phân loại:** EC/robustness, không phải BVA độ dài.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới.
- **Account/email trước:** `vinh.dmreg.rb-no-digit@example.com`, count 0.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `Aa!!bbbb` (8 ký tự, thiếu chữ số duy nhất).
- **Thao tác:** mở Register; nhập bốn trường; ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; kiểm tra email count read-only.
- **Expected:** bị từ chối vì thiếu chữ số theo D-R06; không tạo account.
- **D-EC / D-R / TC liên quan:** D-EC-13; D-R06, D-R08; ca Domain D-DT-010.
- **Evidence:** `evidence/D-MREG/D-BV-006-no-digit-before.png`, `evidence/D-MREG/D-BV-006-no-digit-after.png`, count/response nếu có.

###### D-BV-007 — Robustness: thiếu ký tự thuộc tập `@$!%*?&`

- **Phân loại:** EC/robustness, không phải BVA độ dài. Kiểm tra membership trong tập, không yêu cầu chuỗi có mọi ký tự trong tập.
- **Thiết bị/OS:** Android Emulator `Pixel 9`, Android 15/API 35, Expo Go SDK 54; hoặc ghi Android device thực tế.
- **Trạng thái app:** Register mới.
- **Account/email trước:** `vinh.dmreg.rb-no-allowed-special@example.com`, count 0.
- **Dữ liệu:** họ tên `Nguyen Le The Vinh`; email trên; password/confirm `Aa12bbbb` (8 ký tự, có hoa/thường/số nhưng không có ký tự nào trong tập yêu cầu).
- **Thao tác:** mở Register; nhập tên/email; nhập password và confirm (chuyển bàn phím sang ký hiệu khi cần); ẩn bàn phím; chụp trước submit; submit một lần; chụp phản hồi; kiểm tra email count read-only.
- **Expected:** bị từ chối vì password thiếu ký tự thuộc `@$!%*?&`; không tạo account. Không kết luận về việc có chấp nhận ký tự đặc biệt ngoài tập khi chuỗi đã có ký tự hợp lệ.
- **D-EC / D-R / TC liên quan:** D-EC-14; D-R06, D-R08; ca Domain D-DT-011.
- **Evidence:** `evidence/D-MREG/D-BV-007-no-allowed-special-before.png`, `evidence/D-MREG/D-BV-007-no-allowed-special-after.png`, count/response nếu có.

##### Biên không thiết kế

- **Họ tên, email, xác nhận mật khẩu:** SRS không nêu giới hạn min/max số ký tự để áp dụng BVA độ dài. Không đặt max giả; ca rỗng/format/khớp là các lớp Domain ở `03-domain-cases.md`.
- **Password upper bound:** không có UB được nêu. D-BV-003 tại 9 ký tự chỉ là `LB+1`, không đại diện cho giới hạn trên.
- **Password length 0:** password rỗng đã là lớp bắt buộc D-EC-07 và ca D-DT-007; ca này không dùng để thay thế điểm `LB−1` có các nhóm ký tự hợp lệ.
- **Mạng, email race, trim/Unicode:** chưa có biên/expected đủ rõ; không tạo thêm BVA.

##### Nguồn

- 01-requirements.md, D-R01–D-R09; password policy D-R06.
- 02-domains.md, D-EC-08–D-EC-14.
- 03-domain-cases.md, D-DT-002, D-DT-007–D-DT-011.
- SRS `eshop-sut/README.md`, FR-01 và FR-20; API `eshop-sut/api_specification.md`, §1.1.
- Slide Domain/BVA: [`slide/domain-testing-vn.pdf`](../slide/domain-testing-vn.pdf), BVA trang 19–23; [`slide/domain-testing-en.pdf`](../slide/domain-testing-en.pdf), BVA trang 20–24.


## Phụ lục — Nhật ký thực thi mới nhất theo từng chức năng

Các runtime mô tả theo thời điểm run, không khẳng định dịch vụ hiện còn đang chạy.

### A-FR02 — Nhật ký thực thi

**Sinh viên:** Nguyễn Lê Thế Vinh — 23120190 — Thành viên 2.

#### Run 001 — A-DT-001: Đăng nhập Web đúng; lưu và gửi token

- **TC ID:** A-DT-001.
- **Thời điểm:** 15/10/2026; giờ/phút người chạy chưa cung cấp.
- **Môi trường:** Web tại `http://localhost:5173`; OS của workspace là Ubuntu 26.04.1 LTS, nhưng chưa xác nhận trình duyệt/phiên bản thực sự dùng cho run. SUT baseline dự kiến `85af3ba875c88283615e22cb108f13e2fccaf0e9`; chưa ghi nhận commit runtime riêng cho lần chạy.
- **Tiền điều kiện:** Theo mô tả thực thi, người chạy đã vào trang login và nếu cần đã đăng xuất trước đó. Việc đăng nhập thành công cho thấy tài khoản được chấp nhận ở lần đó; counter n=0, chưa khóa và client không token cũ chưa có ảnh/log xác nhận riêng.
- **Dữ liệu:** Email `test@eshop.com`; mật khẩu test `Test1234!`.
- **Thao tác đã làm:** Theo người chạy, đã mở `/login`, nhập email/mật khẩu, bấm **Sign In** một lần và quan sát chuyển về trang chủ với người dùng đăng nhập.
- **Expected:** Request login thành công; có JWT token và thông tin user; client lưu token và gửi `Authorization: Bearer <token>` khi phát request cần xác thực. Xem A-DT-001.
- **Actual:** Người chạy báo “mọi thứ đều pass”. Phần chi tiết được xác nhận trong hội thoại là đăng nhập thành công, chuyển về trang chủ và thấy người dùng đã đăng nhập. Chưa có response/network log hoặc quan sát storage/header để xác nhận riêng các checkpoint token.
- **Status:** **Chưa hoàn tất toàn bộ A-DT-001.** UI login được người chạy báo thành công; checkpoint token được lưu/gửi chưa được ghi nhận. Không đánh dấu toàn TC là Pass cho tới khi xác nhận checkpoint còn lại.
- **Bằng chứng:** Chưa có screenshot login được lưu. Sau khi chụp, đặt tại `evidence/A-FR02/A-DT-001-login-success.png` hoặc cập nhật path đúng. Ảnh hiện có trong hội thoại là trang Admin, không dùng làm bằng chứng cho ca login.

##### Còn cần ghi để đóng A-DT-001

1. Chụp trang sau đăng nhập và lưu screenshot với TC ID.
2. Trong DevTools → Network, mở `POST /api/login`, xác nhận response có token/user; không đưa nguyên token vào ảnh công khai.
3. Kiểm tra client đã lưu token ở nơi implementation dùng.
4. Mở request cần xác thực do client gửi (ví dụ `GET /api/users/me`) và xác nhận request header Bearer khớp token vừa nhận. Không tự thêm header bằng tay.
5. Nếu đã làm các bước 2–4, gửi đúng quan sát và log/ảnh để cập nhật Actual/Status. Nếu chưa làm, phần đó còn Not run.

Đây là ghi nhận theo lời người chạy; không tạo thêm kết quả nào ngoài thông tin đã cung cấp. Không sửa SUT.


#### Run 002 — API; hai lần sai liên tiếp (phủ một phần A-BV-003 / A-DT-011)

- **TC ID:** `A-BV-003` được chạy một phần: chỉ hai lần sai, chưa thực hiện bước nhập mật khẩu đúng cuối ca. Cũng là hai bước đầu của `A-DT-011`; lần sai thứ ba và kiểm tra khóa chưa chạy.
- **Run ID:** `20261014T173755Z-47a40399`.
- **Thời điểm:** 2026-10-14 17:37:55–17:37:55 UTC (2026-10-15 00:37:55–00:37:55 Asia/Ho_Chi_Minh), lấy từ log JSONL.
- **Môi trường:** API `http://localhost:3000/api`; database SQLite được đọc chỉ để quan sát state. Baseline SUT của bài là `85af3ba875c88283615e22cb108f13e2fccaf0e9`; commit runtime lúc chạy chưa được xác nhận riêng.
- **Tiền điều kiện:** Tài khoản mới tạo qua `/register`, user id 3; trước đăng ký chưa có tài khoản cùng email. State sau đăng ký trước lần sai đầu: counter/lock chưa được lưu riêng trong log. Mỗi lần sai gửi tuần tự, request trước đã hoàn tất.
- **Dữ liệu:** `a-fr02-20261014t173755z-47a40399@example.test`; password sai `Wrong123!` (đã che trong log).
- **Thao tác:** Đăng ký tài khoản mới (HTTP 200); gửi POST `/login` sai hai lần tuần tự.
- **Expected:** Theo `A-R04`/`A-R05` và expected của A-BV-003, sau hai lần sai counter phải là 1 rồi 2, tài khoản chưa khóa. A-BV-003 còn có bước nhập mật khẩu đúng sau đó; bước này chưa làm.
- **Actual:** Hai response đều HTTP 401. Sau lần 1 DB cho thấy `login_attempts=2`, `locked_until=null`. Sau lần 2 DB cho thấy `login_attempts=4`, `locked_until=2026-10-14T17:40:55.185Z`. Đây là sai khác trực tiếp với expected về counter và ngưỡng khóa, quan sát được sau cả hai request.
- **Status:** **Fail cho checkpoint counter sau lần 1 và lần 2**; bằng chứng cũng cho thấy khóa đã phát sinh trước ngưỡng 3. `A-BV-003` tổng thể **chưa hoàn tất** vì bước password đúng sau hai lần sai chưa chạy. `A-DT-011` **chưa hoàn tất** vì mới gửi hai trong ba lần sai. Không kết luận về 30 giây từ lần chạy này.
- **Bằng chứng:** [JSONL đã che password](../evidence/A-FR02/api-runs/20261014T173755Z-47a40399/login-sequence.jsonl). Log ghi thời gian monotonic client và round-trip; không đo chính xác thời điểm server so sánh `locked_until`.
- **Tài khoản còn lại:** Tài khoản test user id 3 vẫn ở database local và đang có `locked_until` theo log; không xóa hoặc restart DB trong bước này.

#### Run 003 — API Domain/BVA và các chuỗi trạng thái

- **Run ID:** `20261014T180523Z-fa50f52b` (2026-10-15 01:05:23+07:00 bắt đầu; 272.39 giây).
- **TC liên quan:** A-DT-005–010, A-DT-011–014, A-DT-018–019, A-DT-021–022; A-BV-001–006, A-BV-008–010. Xem bảng coverage bên dưới để biết ca nào chỉ phủ một phần.
- **Môi trường:** API `localhost:3000`; Web `localhost:5173`; Ubuntu 26.04.1; baseline và runtime SUT commit `85af3ba875c88283615e22cb108f13e2fccaf0e9`. Backend đã chạy sẵn; không restart. Database chỉ được đọc qua kết nối SQLite `mode=ro`.
- **Cách chạy:** Harness [A-FR02-full-execution.mjs](../scripts/A-FR02-full-execution.mjs) tạo tài khoản độc lập qua API đăng ký, gửi request tuần tự, ghi response đã che password/token và state DB trước/sau. Không có kết luận Pass/Fail tự động.
- **Bằng chứng thô:** [execution.jsonl](../evidence/A-FR02/full-runs/20261014T180523Z-fa50f52b/execution.jsonl). Run có 33 tài khoản test mới; không xóa.
- **Kết quả nổi bật:** request sai đầu tiên làm `login_attempts` thành 2; request sai thứ hai làm counter thành 4 và đặt `locked_until` trước khi đến lần sai thứ ba. Lần thứ ba trả HTTP 403 do đã khóa. Các chuỗi độc lập cho A-BV-002/003/004/005 và A-DT-011 tái hiện điều này. Sau lần sai thứ hai, probe đúng ở A-BV-003 cũng bị 403.
- **Thời gian:** các khoảng đo client được ghi ở JSONL. A-BV-006: toàn request nằm khoảng 29.0598–29.0711 giây sau khoảng request kích hoạt khóa; trả 403. A-BV-008: 31.0707–31.0814 giây; trả 403. A-BV-009: 10.0610–10.0706 giây; trả 403. A-BV-010: 40.0876–40.0969 giây; trả 403. A-DT-012 ở khoảng 10.0344–10.0458 giây trả 403; A-DT-013 ở 40.0787–40.0881 giây trả 403. Mỗi khoảng được tính bảo thủ từ thời điểm gửi/nhận request kích hoạt và probe. Setup khóa bắt đầu sau lần sai thứ hai (sai ngưỡng); các ca thời gian là quan sát chẩn đoán trên trạng thái khóa thực tế, không chứng minh luồng chuẩn bắt đầu khóa ở lần thứ ba. Đo client không kiểm soát clock tại điểm server so sánh.
- **A-DT-014:** chuỗi sai → đúng → sai trả 401 → 200 → 401; DB lần lượt cho thấy counter 2 → 0 → 2. Việc đăng nhập đúng reset counter được quan sát; mỗi lần sai vẫn tăng 2 thay vì 1.
- **A-DT-021:** probe đúng ở khoảng 10 giây và khoảng 40 giây đều trả 403; `locked_until` không đổi sau probe 10 giây. Q5 chưa được đặc tả nên không kết luận chính sách gia hạn nói chung.
- **A-DT-022:** password sai gửi sau hơn 40 giây kể từ response kích hoạt khóa vẫn trả 403; counter/locked state được giữ. Đây là bằng chứng thời lượng thực tế vượt 30 giây.
- **API input thăm dò:** A-DT-006 trả 401 cho email không tồn tại; A-DT-007 (thiếu email), A-DT-008 (email số), A-DT-009 (thiếu password), A-DT-010 (email null) đều không đăng nhập thành công. Riêng A-DT-009 làm counter thành 2; quy tắc đếm cho payload thiếu password chưa chốt nên không chấm counter. A-DT-018 (email uppercase) và A-DT-019 (email có khoảng trắng) trả 401; chuẩn hóa email chưa được SRS định nghĩa nên chỉ ghi observation.
- **A-DT-005/A-BV-001:** đăng nhập đúng tài khoản mới trả HTTP 200, có token và user.

#### Run 004 — UI Web bằng Chrome headless cô lập

- **Run ID:** `20261014T181147Z-0f7e1361` (2026-10-15 01:11:47+07:00 bắt đầu; 176.54 giây).
- **Môi trường:** Chrome 154.0.8037.57 headless, profile tạm riêng; Web `localhost:5173`, API `localhost:3000`; cùng baseline/runtime SUT như Run 003.
- **Bằng chứng:** [execution.jsonl](../evidence/A-FR02/full-runs/20261014T181147Z-0f7e1361/execution.jsonl) và [ảnh UI theo TC](../evidence/A-FR02/full-runs/20261014T181147Z-0f7e1361/screenshots/). 13 tài khoản test được tạo; không xóa.
- **A-DT-001:** tài khoản test đăng nhập thành công; trang chủ chào đúng user; localStorage có token. Có request `/api/users/me` mang `Authorization: Bearer` và trả 200 trong profile sạch; một OPTIONS preflight trả 204 không có Authorization. Không ghi token thô vào log/ảnh.
- **A-DT-002/A-DT-003:** sai password và email không tồn tại đều ở lại trang login, hiển thị thông báo thất bại, không có token mới; ảnh được chụp sau khi xóa giá trị khỏi ô nhập.
- **A-DT-004:** nhập `not-an-email` được form gửi tới API thay vì HTML5 chặn; input quan sát được là `type="text"`, request trả 401. Đây là Fail với A-R10. A-DT-020 cũng gửi request cho email sai format xen giữa hai lần sai password; không có chặn HTML5.
- **A-DT-015/016:** email rỗng/password rỗng bị browser chặn bởi thuộc tính required; không có request login. Đây là observation phù hợp checkpoint không đăng nhập thành công; SRS chưa quy định validation required cụ thể.
- **A-DT-017:** ba dấu cách trong password được submit và bị từ chối; DB sau đó có counter 2. Không chấm quy tắc đếm vì Q2 chưa giải quyết kiểu input này.
- **A-DT-011:** ba lần submit sai password trên UI; hai request đầu bị từ chối, trạng thái server đã khóa từ lần thứ hai; request thứ ba bị từ chối do đang khóa. UI hiển thị thông báo tổng quát. Fail ngưỡng ở A-R04/A-R05.
- **A-DT-014:** UI chạy sai → đúng → sai; chuyển trang chủ sau lần đúng, quay lại login và từ chối lần sai cuối. DB cuối có counter 2; xem Run 003 để biết counter sau từng bước API tương ứng.
- **A-DT-023:** sau login đúng, gửi login sai; thông báo thất bại, token cũ vẫn còn nguyên. Kết quả không nhầm token phiên cũ với token mới từ login sai.
- **A-DT-024:** client được đặt token sai dạng trong profile test; login với credentials đúng vẫn thành công và token mới hiện diện.
- **A-DT-012/013/021/022:** thao tác UI chạy; request đầu vào và response đã ghi trong JSONL. UI timing lần lượt ở khoảng 10s, 40s, 10/40s và 40s; chi tiết bounds được suy ra từ timestamp monotonic request/response trong log ở mục coverage. Không dùng UI screenshot để khẳng định chính xác thời điểm server so sánh.

#### Lưu ý về lần tự động hóa UI đầu tiên

Run 003 JSONL cũng chứa một lượt UI ban đầu bị nhiễm state: profile dùng lại token từ A-DT-001 giữa các ca và harness truyền email fixture thay vì `not-an-email`/email rỗng cho một số ca. Phát hiện từ `tokenPresent=true` ở ca âm và điều hướng thành công ở ca sai format. Không dùng các kết quả/screenshot UI trong Run 003 để chấm. Run 004 dùng profile sạch, xóa token giữa các ca và nhập đúng dữ liệu; chỉ kết quả Run 004 được dùng cho UI coverage. API observations ở Run 003 vẫn độc lập và hợp lệ.

#### Coverage từng TC sau Run 003/004

| TC ID | Kênh/thực tế và kết quả chính | Trạng thái |
|---|---|---|
| A-DT-001 | UI login 200, token lưu; protected request Bearer trả 200 | Pass |
| A-DT-002 | UI sai password bị từ chối; counter sau một lần sai = 2 | Fail — A-R04 |
| A-DT-003 | UI email chưa đăng ký bị từ chối, không token mới | Pass |
| A-DT-004 | UI gửi email sai format; input `type=text`, HTML5 không chặn | Fail — A-R10 |
| A-DT-005 | API login đúng trả 200/token/user | Pass |
| A-DT-006 | API và UI email không tồn tại bị từ chối | Pass |
| A-DT-007 | API thiếu email: không login thành công; status chi tiết không oracle | Pass cho checkpoint không thành công; status không chấm |
| A-DT-008 | API email là số: không login thành công | Pass cho checkpoint; ép kiểu/status không chấm |
| A-DT-009 | API thiếu password: bị từ chối; counter 0→2 | Pass cho từ chối; counter là Q2, không chấm |
| A-DT-010 | API email null: bị từ chối, không login thành công | Pass cho checkpoint; status chi tiết không chấm |
| A-DT-011 | UI/API chuỗi sai; counter 0→2→4, khóa ở lần sai thứ hai | Fail — A-R04/A-R05 |
| A-DT-012 | Password đúng khoảng 10s bị khóa; setup đã khóa sớm ở lần sai thứ hai | Fail — setup ngưỡng; checkpoint khóa 10s bị quan sát |
| A-DT-013 | Password đúng >40s vẫn bị khóa; setup sớm, thời lượng cũng lệch 30s | Fail — A-R06; setup threshold cũng fail |
| A-DT-014 | Sai→đúng→sai; counter 0→2→0→2, login đúng reset chuỗi | Fail — A-R04; reset A-R11 được quan sát |
| A-DT-015 | Email rỗng bị required chặn, không request/không login | Pass cho checkpoint không thành công; cách validation chưa đặc tả |
| A-DT-016 | Password rỗng bị required chặn, không request/không login | Pass cho checkpoint không thành công; cách validation chưa đặc tả |
| A-DT-017 | Password ba dấu cách bị từ chối; counter 0→2 | Pass cho từ chối; phân loại/counter chưa chấm (Q2/Q7) |
| A-DT-018 | API uppercase email trả 401; email normalization chưa rõ | Observation only — không verdict (Q7) |
| A-DT-019 | API email có khoảng trắng trả 401; trim chưa rõ | Observation only — không verdict (Q7) |
| A-DT-020 | Email sai format được gửi API; HTML5 không chặn; counter sai password 0→2→4 | Fail — A-R10 và A-R04 |
| A-DT-021 | UI/API đúng ở khoảng 10s và khoảng 40s đều bị khóa; lần 10s không đổi locked_until; setup khóa sớm | Fail — setup A-R05; 40s vi phạm A-R06; Q5 không suy rộng |
| A-DT-022 | Password sai >40s sau khóa vẫn nhận lỗi đang khóa | Fail — A-R06; setup threshold fail |
| A-DT-023 | UI login sai bị từ chối; token hợp lệ cũ vẫn còn, không phải token mới | Pass |
| A-DT-024 | UI login đúng thành công dù client ban đầu có token sai dạng | Pass |
| A-BV-001 | API login đúng với n=0 thành công | Pass |
| A-BV-002 | Một lần sai làm counter 0→2 thay vì 1 | Fail — A-R04 |
| A-BV-003 | Hai lần sai làm 0→2→4/khóa; password đúng probe bị 403 | Fail — A-R04/A-R05 |
| A-BV-004 | Khóa ở lần sai thứ hai; lần ba và probe đều 403 | Fail — A-R04/A-R05 |
| A-BV-005 | Khóa trước lần ba; lần sai thứ tư bị 403 khi đang khóa | Fail — ngưỡng/setup; request thứ tư bị từ chối |
| A-BV-006 | Clock fixture tại elapsed 29s trả 403; natural setup thực tế khóa sớm ở lần sai thứ hai | Partial: time checkpoint khớp expected; setup chuỗi 3 lần sai chưa đạt |
| A-BV-007 | Clock fixture tại đúng 30.000s ở phép so sánh; login đúng trả 200 | Pass cho checkpoint toán tử; fixture không kiểm chứng thời lượng khóa tự nhiên |
| A-BV-008 | 31.0707–31.0814s, probe vẫn 403; locked_until cho thấy khoảng khóa runtime 180s | Fail — A-R06 (kèm setup threshold fail) |
| A-BV-009 | Clock fixture tại elapsed 10s trả 403; natural setup thực tế khóa sớm ở lần sai thứ hai | Partial: time checkpoint khớp expected; setup chuỗi 3 lần sai chưa đạt |
| A-BV-010 | 40.0876–40.0969s, probe vẫn 403; khóa phát sinh sớm và còn hiệu lực | Fail — A-R06 (kèm setup threshold fail) |
| A-BV-011 | Clock fixture tại 29.999s; login bị chặn 403 | Pass cho checkpoint toán tử trước mốc |
| A-BV-012 | Clock fixture tại 30.001s; login đúng trả 200 | Pass cho checkpoint toán tử sau mốc |

“Pass” ở hàng có ghi checkpoint nghĩa là chỉ checkpoint expected đã nêu được chứng minh; phần oracle đang mở không được suy ra. Với các ca trạng thái/timing, bảng ghi Fail/Blocked ở cả setup lẫn phần phụ thuộc khi cần, không coi lỗi setup là bằng chứng cho mọi checkpoint.

#### Tài khoản và dữ liệu test

Run 003/004 đã tạo 46 tài khoản test mới với tiền tố email `a-fr02-`; tài khoản user ID 3 từ Run 002 cũng còn trong SQLite local. Không xóa tài khoản hoặc database. Tài khoản test được ghi trong các JSONL. Backend vẫn chạy; không restart.

#### Run 005 — Chụp bổ sung bằng chứng giao diện cho bug

- **Run ID:** `20261014T183925Z-fa22ee4e`; Chrome 154.0.8037.57 trong profile riêng, màn hình 1280×1100; backend/Web đang chạy, không restart.
- **Mục đích:** chụp lại UI cho A-DT-002/A-BV-002 (A-BUG-001), A-DT-013/A-BV-008 (A-BUG-002) và A-DT-004 (A-BUG-003), kèm log riêng trong [capture.jsonl](../evidence/A-FR02/issue-evidence/20261014T183925Z-fa22ee4e/capture.jsonl). Đây là bằng chứng bổ sung cho Run 003/004, không thay đổi verdict.
- **A-BUG-001:** một lần nhập sai trên UI trả 401; ảnh cho thấy thông báo từ chối. SQLite chỉ đọc ghi counter `0→2`, chưa khóa. Ảnh: [A-BUG-001](../evidence/A-FR02/issue-evidence/20261014T183925Z-fa22ee4e/A-BUG-001-counter-after-one-wrong.png).
- **A-BUG-002:** hai lần sai qua API kích hoạt khóa; sau khoảng 40 giây, nhập mật khẩu đúng trên UI vẫn bị từ chối, request trả 403. Ảnh: [A-BUG-002](../evidence/A-FR02/issue-evidence/20261014T183925Z-fa22ee4e/A-BUG-002-correct-after-40s.png). Phép đo thời gian chi tiết lấy từ các Run trước trong [timing analysis](../features/A-FR02/timing-analysis.md).
- **A-BUG-003:** email `not-an-email` được gửi từ form Web; validity của input `type=text` là true và POST login trả 401. Ảnh: [A-BUG-003](../evidence/A-FR02/issue-evidence/20261014T183925Z-fa22ee4e/A-BUG-003-invalid-email-submitted.png).
- Ảnh chỉ giữ email test và kết quả giao diện; ô mật khẩu được xóa trước khi chụp. Không có token/mật khẩu trong ảnh hoặc log. Một lượt chụp sơ bộ trước đó bị hủy vì ô mật khẩu của SUT thực tế là `type=text`; ảnh lượt đó đã xóa và không được dùng làm bằng chứng.
- Sau khi xác minh ảnh, ba lỗi đã được đăng riêng với ảnh đính kèm: [A-BUG-001 #1](https://github.com/tzin1401/testing-hw02/issues/1), [A-BUG-002 #2](https://github.com/tzin1401/testing-hw02/issues/2), [A-BUG-003 #3](https://github.com/tzin1401/testing-hw02/issues/3).


#### Run 006 — Clock fixture cho ba điểm biên

- **Run ID:** `20261016T-clock-A-FR02`; baseline `85af3ba875c88283615e22cb108f13e2fccaf0e9`.
- **Môi trường:** bản clone cô lập trong `/tmp/hw02-a-clock-20261016`, backend riêng port 3001. Business source từ baseline; chỉ preload ngoài repo thay `Date.now()`/`new Date()` bằng clock fixture đọc từ file. Không sửa source SUT. Mỗi điểm dùng tài khoản fixture riêng, `login_attempts=3`, `locked_until=2026-10-16T08:00:30.000Z`; gửi đúng password.
- **Kết quả:** A-BV-011 tại 29.999s trả 403 và trạng thái khóa còn; A-BV-007 tại đúng 30.000s trả 200, DB read-only sau request cho `locked_until=null`; A-BV-012 tại 30.001s trả 200, DB read-only sau request cho `locked_until=null`. Các lần request độc lập, UTC/monotonic round-trip được ghi trong JSON.
- **Verdict:** Pass cho các checkpoint so sánh thời gian của fixture ở 29.999/30.000/30.001 giây. Bằng chứng kiểm tra toán tử thời hạn của baseline với clock điều khiển; không chứng minh luồng tạo khóa tự nhiên bắt đầu đúng thời điểm, cũng không thay đổi finding khóa 180 giây do logic baseline.
- **Bằng chứng:** [clock fixture JSON đã che bí mật](../evidence/A-FR02/full-runs/20261016T-clock-A-FR02.json). Response password và token đã loại/che; SQLite clone chỉ đọc sau từng request.


#### Run 007 — Clock fixture cho mốc 10s và 29s

- **Run ID:** `20261016T-clock-A-FR02-midpoints`; clone và preload clock ngoài source như Run 006, baseline giữ nguyên. Hai user fixture riêng có `locked_until=08:00:30.000Z`, `login_attempts=3`; clock tại phép so sánh lần lượt đặt elapsed 10s (A-BV-009) và 29s (A-BV-006).
- **Actual:** cả hai request password đúng trả 403; trạng thái DB clone read-only sau request vẫn khóa. Hai mốc nằm hẳn trước 30s theo clock fixture.
- **Verdict:** Partial cho từng TC: expected về active lock được xác nhận bằng fixture, nhưng không hoàn tất chuỗi tự nhiên ba lần sai vì baseline thực tế kích hoạt khóa ở lần sai thứ hai (đã ghi Fail threshold ở các TC khác).
- **Evidence:** [clock midpoints JSON](../evidence/A-FR02/full-runs/20261016T-clock-A-FR02-midpoints.json). Mật khẩu/token đã che; timestamp UTC và monotonic ghi trong file.


### B-FR07 — Nhật ký thực thi Domain và BVA

**SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`
**Run chính:** `20261014T191645Z-BFR07-UI` — Chrome Headless 154/Linux, Web `127.0.0.1:5173`, backend `127.0.0.1:3000`; dịch vụ đã chạy sẵn, không restart. Sản phẩm test P1 ID 1 (30.000.000 VND), P2 ID 2 (28.000.000 VND), không sửa/xóa catalog.
**Run bổ sung:** `20261015T154202360Z-supp`, thư mục `evidence/B-FR07/supplement-runs/20261015T154202360Z-supp/`.

#### Kết quả cho 26 ca đã thiết kế

| Trạng thái TC thiết kế | Số lượng | Ghi chú |
|---|---:|---|
| Pass | 4 | B-DT-003, 014; B-BV-002, 003. |
| Fail | 12 | B-DT-001, 002, 004, 006, 008, 011, 015–019; B-BV-001. |
| Observation | 2 | B-DT-005 tổng cộng chưa có oracle đã review; B-DT-020 API exploratory chưa có oracle. |
| Blocked | 8 | B-DT-007, 009, 010, 012, 013 và B-BV-004–006 do nút +/- hoặc dialog/xác nhận không tồn tại; Fail sự hiện diện được ghi riêng. |
| **Tổng thiết kế** | **26** | 20 Domain + 6 BVA. |

Các kết quả pass/fail này có evidence UI trong run chính hoặc run supplementary nêu bên dưới; supplementary không dùng API để seed cart. B-DT-016–019 được chạy lại bằng thao tác UI đủ hai lần bấm cần thiết tại trang chi tiết, sau khi reset giỏ bằng UI. B-DT-020 vẫn là probe API riêng, không chấm theo policy chưa có trong SRS. Không có UB được nêu.

#### Run bổ sung: evidence UI và mapping vào TC thiết kế

Run bổ sung lập được giỏ bằng đường Home hoặc thao tác setup riêng. Run 20261016 xác nhận B-DT-002 vẫn Fail khi chỉ bấm một lần tại trang chi tiết; các hành vi độc lập có UI evidence được cập nhật verdict trong bảng 26 ca. TC cần thao tác nút/dialog không tồn tại vẫn Blocked sau khi ghi Fail riêng cho sự hiện diện.

| ID bổ sung | Quan sát | Kết luận giới hạn |
|---|---|---|
| B-DT-001-SUP | Giỏ rỗng có dòng “Giỏ hàng của bạn đang trống”, không thấy minh họa. | Xác nhận Fail B-R01. Ảnh `B-DT-001-empty.png`. |
| B-DT-002-SUP | Thêm từ chi tiết một lần vẫn để giỏ rỗng. | Cùng hiện tượng B-DT-002; ảnh `B-DT-002-first-click.png`, `B-DT-002-cart-after-one-click.png`. |
| B-DT-003-SUP | P1 và P2 hiển thị thành hai dòng riêng. | Hành vi đúng được quan sát; bảng cập nhật đầu file ghi B-DT-003 Pass theo evidence supplementary, giữ khác biệt setup đã khai báo. |
| B-DT-004-SUP | Thêm P1 lần hai tạo hai dòng P1 riêng, mỗi dòng quantity 1. | Fail B-R04; bằng chứng `B-DT-004-SUP-duplicate-product.png`. |
| B-DT-005-SUP | P1: 30.000.000 × 2 = 60.000.000; P2: 28.000.000 × 1 = 28.000.000; tổng hiển thị 88.000.000. | Thành tiền dòng khớp; tổng hiển thị bằng phép cộng nhưng expected tổng vẫn candidate chưa được review, nên cả TC là Observation. Checkpoint `B-DT-005-SUP-amounts.png`. |
| B-DT-006/007/008/009/010-SUP và B-BV-004/005/006-SUP | Trên dòng giỏ không có nút `+` hoặc `−`; chỉ có “Xóa”. | Fail yêu cầu sự hiện diện của điều khiển; thao tác phụ thuộc không thể thực hiện nên Blocked. Không giả lập nút. |
| B-DT-011/012/013-SUP | “Xóa” gỡ dòng ngay; không xuất hiện dialog. | Fail B-DT-011 về dialog; B-DT-012/013 Blocked ở nhánh xác nhận. Việc xóa trực tiếp được ghi observation riêng. Các dòng là fixture do run tạo và đã dọn bằng UI. |
| B-DT-014-SUP | “← Mua tiếp” về Home. | Pass B-DT-014. |
| B-DT-015-SUP | Hiển thị “Tổng tạm tính” thay vì nhãn yêu cầu “Tổng cộng”. | Fail nhãn theo B-R; ảnh `B-DT-015-SUP-total-label.png`. |
| B-DT-016/017/018/019-SUP; B-BV-001/002/003-SUP | Run 20261016 lặp thao tác nhập rồi bấm nút chi tiết hai lần. Giá trị 0 tạo quantity 0; -1 tạo quantity -1; 1.5 hiện thành 1; `abc` bị input number loại thành rỗng nhưng vẫn tạo dòng quantity/amount `NaN`; 1 và 2 tạo quantity tương ứng. | Fail B-DT-016/017/018/019 và B-BV-001 theo FR-06 quantity nguyên dương tối thiểu 1; Pass B-BV-002/003. Đây là actual của TC thiết kế, không chỉ probe. Ảnh/event theo run 20261016T074533896Z-supp. |

Run bổ sung đã dọn các dòng giỏ test qua UI; event log ghi rõ fixture và cleanup. Số ảnh trong thư mục run không phải số ca đã chạy.

#### Evidence và side effect

- Run chính: `evidence/B-FR07/full-runs/20261014T191645Z-BFR07-UI/` gồm metadata, summary, case observations, checkpoint index, ảnh và ghi chú.
- Run bổ sung: `evidence/B-FR07/supplement-runs/20261015T154202360Z-supp/events.jsonl` cùng ảnh checkpoint.
- Run chính có hai API POST exploratory quantity 1.5 (một ở lần thử helper hỏng và một ở probe); GET sau đó thấy hai entry nhưng không có snapshot API cart trước đó nên không thể gán từng entry. Web không hiển thị để dọn; không gọi API delete hoặc sửa DB. Side effect và giới hạn được ghi trong execution notes/audit.

#### Kết luận

Evidence UI hiện cho phép chấm các TC độc lập về duplicate line, số học, xóa dòng, tiếp tục mua sắm, quantity và nhãn. 8 TC còn Blocked chỉ là thao tác phụ thuộc nút +/-/dialog vắng mặt; finding sự hiện diện được chấm Fail riêng. B-R04 và các yêu cầu điều khiển/dialog/nhãn có issue tương ứng #9–#12; Issue #4/#5 giữ cho hai finding của run chính. Liên kết và tình trạng ảnh được ghi trong `07-bugs-and-ai-gaps.md`. Không kết luận về UB, tồn kho, persistence, hay validation quantity phía ứng dụng khi setup không chứng minh được.


#### Run bổ sung ngày 16/10 — kiểm tra lại UI trên clone

**Run ID:** `20261016T072910588Z-supp`; Chrome headless, Web UI trên backend clone cô lập từ baseline `85af3ba875c88283615e22cb108f13e2fccaf0e9`. Không dùng API để seed cart; chỉ tạo account test riêng và thao tác UI. Sản phẩm mẫu không bị sửa/xóa. Bằng chứng ảnh/event nằm trong `evidence/B-FR07/supplement-runs/20261016T072910588Z-supp/`.

Run này tái hiện các checkpoint UI cho giỏ rỗng, mở chi tiết/thêm sản phẩm, hai sản phẩm khác nhau, thêm lại cùng sản phẩm, phép tính thành tiền/tổng, sự hiện diện nút +/- và dialog xóa, xóa dòng, tiếp tục mua sắm, nhãn tổng. Kết quả khớp các quan sát đã có: route chi tiết thêm một lần không thêm dòng; cách thêm từ Home tạo được dòng; thêm trùng tạo hai dòng; giá × quantity và tổng số học hiển thị; +/- và dialog không hiện; xóa xảy ra ngay; tiếp tục mua sắm quay Home; nhãn là “Tổng tạm tính”. Các ca input số lượng chưa có setup giỏ hợp lệ để đánh giá chính sách input.

Các checkpoint supplementary được lưu theo Run ID và ảnh gắn TC ID để giữ nguồn gốc. Bảng 26 TC thiết kế đầu file phản ánh verdict cuối theo toàn bộ UI evidence: các hành vi độc lập đã chạy được chấm theo expected; ca tương tác thực sự phụ thuộc control/dialog vắng mặt vẫn Blocked sau khi ghi Fail riêng cho sự hiện diện.


#### Run quantity bổ sung 20261016T074533896Z

Từng ca bắt đầu bằng giỏ rỗng được xác nhận trên UI và reset bằng UI; dùng account test của run trên bản clone. Ở trang chi tiết, sau khi nhập quantity, lần bấm thứ nhất không thêm; lần bấm thứ hai thêm vào cart. Điều này được ghi lại, không bỏ qua thao tác cần thiết.

| TC | Input UI | Actual trên cart sau thao tác | Kết luận theo FR-06 | Evidence |
|---|---|---|---|---|
| B-DT-016 / B-BV-001 | `0` | Dòng P1 quantity `0`, thành tiền `0 ₫` | Fail: quantity phải là số nguyên dương tối thiểu 1. | `B-DT-016-after.png`, `B-BV-001-after.png` |
| B-DT-017 | `-1` | Dòng P1 quantity `-1`, thành tiền `-30.000.000 ₫` | Fail theo cùng quy tắc. | `B-DT-017-after.png` |
| B-DT-018 | `1.5` | Control nhận chuỗi; cart lưu/hiển thị quantity `1`, thành tiền `30.000.000 ₫`. | Fail: nhập thập phân bị chuyển ngầm thành integer thay vì bị từ chối. | `B-DT-018-input.png`, `B-DT-018-after.png` |
| B-DT-019 | `abc` | `input[type=number]` không giữ được `abc`, thành trường rỗng; submit vẫn tạo dòng quantity/amount `NaN`. | Fail: trường rỗng tạo cart item không hợp lệ; không kết luận endpoint API. | `B-DT-019-input.png`, `B-DT-019-after.png` |
| B-BV-002 | `1` | Quantity `1`, thành tiền `30.000.000 ₫`. | Pass tại LB. | `B-BV-002-after.png` |
| B-BV-003 | `2` | Quantity `2`, thành tiền `60.000.000 ₫`. | Pass tại LB+δ. | `B-BV-003-after.png` |

B-DT-013 được giữ **Blocked** vì ca thiết kế yêu cầu xác nhận dialog trước khi kết luận nhánh xóa cuối; chỉ quan sát được nút Xóa xóa ngay và màn hình rỗng. Empty state thiếu minh họa đã được Fail ở B-DT-001. B-DT-005 là **Observation** do tổng cộng 88.000.000 khớp phép cộng số học nhưng công thức tổng chưa có oracle được review; thành tiền từng dòng đã quan sát khớp giá × quantity.

Nguồn event có input validity, URL, cart row, timestamp UTC/monotonic và trạng thái từng checkpoint trong `evidence/B-FR07/supplement-runs/20261016T074533896Z-supp/events.jsonl`. Đây là lần thực thi hợp lệ; kết quả không dùng API thay UI.


### C-FR14 — Nhật ký thực thi Domain và BVA

**Run chính:** `20261015T055119Z-CFR14`
**Run bổ sung:** `20261015T154202360Z-supp` (checkpoint phụ, không thay thế các 23 TC thiết kế)
**SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`. Linux x86_64, Node 22.22.1, Chrome Headless 154.0.8037.57; Admin `127.0.0.1:5174`, backend `127.0.0.1:3000`. Danh mục mẫu ID 1–3 được giữ nguyên; các bản ghi test được dọn theo ID sau khi lưu bằng chứng.

#### Kết quả 23 ca thiết kế

| TC ID | Kết quả | Actual có căn cứ | Evidence |
|---|---|---|---|
| C-DT-001 | Pass | Admin thêm tên ASCII test; dòng xuất hiện. | `ui-evidence.json`, `C-DT-001-after.png` |
| C-DT-002 | Pass | Admin thêm tên Unicode có dấu; hiển thị đúng. | `ui-evidence.json`, `C-DT-002-after.png` |
| C-DT-003 | Fail | Tên rỗng tạo được danh mục test; ID được dọn sau khi lưu evidence. | Trước/sau trong `ui-evidence.json`, `issue-empty-name-evidence.json` |
| C-DT-004 | Observation | Ba dấu cách được nhận; SRS không chốt trim/whitespace-only. | `ui-evidence.json`, ảnh input/after |
| C-DT-005 | Pass | Danh sách có dữ liệu test hiển thị được. | `ui-evidence.json`, `C-DT-005-list.png` |
| C-DT-006 | Observation | GET trả danh sách cho admin/user/không token; quyền GET không được suy rộng. | `api-evidence.json` |
| C-DT-007 | Pass | Xóa đúng category test ID 24; các mục khác còn. Lần click ngoài viewport ban đầu không tính; lần retry có target nhìn thấy. | `C-DT-007-retry.json`, ảnh retry |
| C-DT-008 | Blocked | Không có dialog; dòng test bị xóa ngay. Không có nhánh Hủy để chạy. FR-14 không bắt buộc dialog nên không ghi bug. | `C-DT-008-final.json`, ảnh trước/sau |
| C-DT-009 | Pass | POST với JWT admin tạo category test; GET thấy tên. | `api-evidence.json` |
| C-DT-010 | Pass | DELETE với JWT admin xóa đúng target test. | `api-evidence.json` |
| C-DT-011 | Pass | POST thiếu token bị từ chối, không tạo category. | `api-evidence.json` |
| C-DT-012 | Pass | POST token giả bị từ chối, state không đổi. | `api-evidence.json` |
| C-DT-013 | Pass | POST token hết hạn bị từ chối, state không đổi. | `api-evidence.json` |
| C-DT-014 | Fail | POST JWT role user tạo category ID test 6; đã dọn đúng target. | `api-evidence.json`, cleanup evidence |
| C-DT-015 | Pass | DELETE thiếu token bị từ chối; target test còn. | `api-evidence.json` |
| C-DT-016 | Pass | DELETE token giả bị từ chối; target test còn. | `api-evidence.json` |
| C-DT-017 | Pass | DELETE token hết hạn bị từ chối; target test còn. | `api-evidence.json` |
| C-DT-018 | Fail | DELETE JWT role user xóa target test ID 10. | `api-evidence.json` |
| C-BV-001 | Fail | Biên 0 ký tự tạo được tên rỗng. | Ảnh trước/sau, `issue-empty-name-evidence.json` |
| C-BV-002 | Pass | Tên 1 ký tự `Q` được tạo và hiển thị. | `ui-evidence.json`, ảnh input/after |
| C-BV-003 | Pass | Tên 2 ký tự `QZ` được tạo và hiển thị. | `ui-evidence.json`, ảnh input/after |
| C-BV-004 | Pass | DELETE đúng ID đang tồn tại do test tạo; target biến mất. | `api-evidence.json` |
| C-BV-005 | Observation | ID 0 vắng mặt; DELETE trả HTTP 200, đối chứng còn. Expected cho ID không tồn tại chưa được quy định. | `api-evidence.json` |

**Tổng:** 15 Pass, 4 Fail, 1 Blocked, 3 Observation-only. HTTP status ở bảng là actual, không được nâng thành expected nếu hợp đồng không nêu.

#### Checkpoint bổ sung về giao diện Admin

Run bổ sung có hai record nhưng chỉ guest có evidence checkpoint đủ để nói trang mở ra form Admin Login, không hiển thị dashboard (`C-SUP-UI-GUEST-guest.png`). Record user role cho biết fixture được tạo là `supp-...@example.com`, nhưng checkpoint login lại dùng `test@eshop.com` và chỉ ghi alert “Đăng nhập thất bại”; không có request/response chứng minh credentials hợp lệ hoặc nguyên nhân là role. Vì vậy **không** kết luận C-R01 UI role-user đã được kiểm tra thành công. User UI role test còn chưa đủ bằng chứng; API role user POST/DELETE trong C-DT-014/018 vẫn là hai kết quả riêng.

#### Cleanup và giới hạn

Các danh mục test do run tạo đã được dọn theo ID; category mẫu ID 1–3 không bị sửa/xóa. Bằng chứng gốc nằm tại `evidence/C-FR14/full-runs/20261015T055119Z-CFR14/` và checkpoint phụ tại `evidence/C-FR14/supplement-runs/20261015T154202360Z-supp/`.

Không kết luận uniqueness, whitespace policy, max length, hành vi xóa ID không tồn tại, HTTP error status/body, hoặc quyền xem danh sách. Không có cơ sở để ghi dialog xóa là bug theo FR-14. Issue #6 và #7 đã được đăng. Kiểm tra 17/10/2026 xác nhận body #7 có ảnh tải được; ảnh được dựng từ log API, không phải screenshot Admin UI.

#### Bổ sung C-R01 — Login UI với user fixture hợp lệ

**Run ID:** `20261016T003500Z-CUI-user`; Admin UI vẫn chạy tại `127.0.0.1:5174`, backend PID 620916 chạy từ bản sao `/tmp/hw02-dmreg-isolated-run` (không phải DB SUT). Fixture user được tạo trong run bổ sung trước đó: ID 11, `supp-20261015t154202360z-supp@example.com`, role `user`; password chỉ ghi `[REDACTED]`. DB clone xác minh bằng truy vấn read-only; lần login gọi API trả HTTP 200 (preflight 204).

| Checkpoint | Thao tác/Expected | Actual | Kết luận | Evidence |
|---|---|---|---|---|
| C-SUP-UI-USER-VALID | Dùng credentials hợp lệ của account role user ở trang Admin Login; không cấp dashboard/token Admin. | Login API HTTP 200; giao diện hiện alert “Bạn không phải là admin!”, vẫn ở Admin Login; `adminTokenPresent=false`. | Pass cho việc user thường không vào được Admin UI. Đây là kiểm tra bổ sung C-R01, tách khỏi API POST/DELETE C-DT-014/018. | `supplement-runs/20261016T003500Z-CUI-user/{before,credentials-entered,after-submit}.png`, `result.json`, `events.jsonl`, `fixture-state-readonly.json`. |

Lần thử trước trong `20261015T154202360Z-supp` nhập `test@eshop.com` và nhận alert generic “Đăng nhập thất bại”; lần đó vẫn là inconclusive, không dùng làm evidence Pass. Run mới này dùng đúng fixture `supp-…` đã xác minh role và credentials thành công qua login API. Database dùng là clone cô lập; không restart backend, không thay đổi DB trong repo.


#### Run bổ sung 20261016 — đối chiếu API role-user

Trên backend clone cô lập (baseline `85af3ba875c88283615e22cb108f13e2fccaf0e9`), tạo fixture role `user`, đăng nhập để lấy JWT trong bộ nhớ, đồng thời dùng JWT admin chỉ để chuẩn bị target test. Hai lượt automation Admin UI cùng giờ không hoàn tất user login vì selector không tìm thấy form field; không dùng các lượt đó cho UI verdict; log/screenshot guest nằm trong `evidence/C-FR14/supplement-runs/20261016T072910588Z-supp/` và `.../20261016T074533896Z-supp/`. POST `/api/categories` với JWT user trả HTTP 200, tạo ID 4; truy vấn SQLite chỉ đọc xác nhận tên test xuất hiện. Sau khi lưu response, ID 4 được dọn bằng JWT admin. DELETE `/api/categories/5` với JWT user trả HTTP 200 và xóa category ID 5 do test vừa tạo bằng admin. GET danh sách trả HTTP 200 cho guest/user, không gán quyền cấm GET. Target ID 5 đã bị xóa đúng theo ca; category mẫu ID 1–3 vẫn nguyên.

Đây là run API bổ sung củng cố C-DT-014/C-DT-018; verdict vẫn Fail. Token/mật khẩu không ghi vào artifact. Xem [api-role-check.json](../evidence/C-FR14/supplement-runs/20261016T-user-role-api/api-role-check.json). Không dùng kết quả API để suy ra Admin UI.


### D-MREG — Nhật ký thực thi Domain và BVA

**SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`
**Run Mobile:** `20261015T153620Z-57c022`, Android Emulator Pixel 9 / Android 15 / API 35 / x86_64, Expo Go SDK 54. Bằng chứng trong `evidence/D-MREG/supplement-runs/20261015T153620Z-57c022/`.
**Run API phụ trợ:** `20261015T1303Z-DMREG`, chạy trên bản sao DB cô lập vì backend ban đầu không có listener; không restart backend cũ, không dùng API thay cho Mobile UI.

#### Điểm giới hạn chung

Form Mobile quan sát được chỉ có ba trường: Họ tên, Email, Mật khẩu; thiếu trường Xác nhận mật khẩu theo D-R07. Vì thế các ca được thiết kế với đủ bốn trường không thể hoàn thành đúng setup. Bảng “ca thiết kế” ghi verdict cho toàn ca; kết quả thao tác trên ba trường hiện có ghi riêng là **probe biến thể**, không được tính Pass/Fail cho full test case.

#### Trạng thái 20 ca thiết kế

| TC | Trạng thái full TC | Lý do / bằng chứng |
|---|---|---|
| D-DT-001 | Fail | Form chỉ có 3 trường; thiếu xác nhận mật khẩu. `D-DT-001` presence record và `D-DT-001-register-form.png`. |
| D-DT-002–D-DT-011 | Partial / setup không đạt | Có submit các biến thể 3 trường và ghi kết quả riêng bên dưới; không thể nhập confirmation nên không hoàn tất ca thiết kế. |
| D-DT-012–D-DT-013 | Blocked | Ca phụ thuộc trường xác nhận không tồn tại. |
| D-BV-001–D-BV-005 | Partial / setup không đạt | Password được thử qua Mobile UI nhưng confirmation field thiếu. D-BV-002 còn gặp network request failed. Chi tiết bên dưới. |
| D-BV-006–D-BV-007 | Not run | Không có lượt submit hợp lệ đủ để đánh giá hai ca này. Các lượt tự động hóa bổ sung ngày 16/10 đều bị dừng trước submit do nhập sai/lệch trường; một lượt chụp màn hình trước submit rồi thoát Expo Go về Home. Không dùng các ảnh đó để kết luận chức năng. |

Không cộng 15 partial thành 15 TC hoàn tất; không có Pass/Fail đầy đủ cho 19 ca phụ thuộc form 4 trường.

#### Kết quả probe biến thể trên ba trường hiện có

| Probe liên quan | Input chính (password luôn được che trong log) | Actual UI và state | Đánh giá |
|---|---|---|---|
| D-DT-002 | Tên hợp lệ, email mới, password dài 8; confirmation absent | Alert đăng ký thành công, DB test count 0→1, chuyển về Login. | Biến thể 3 trường thành công; không phải Pass full TC D-DT-002. |
| D-DT-003 | Họ tên rỗng; email mới; password dài 8 | Alert thành công, count 0→1, chuyển Login. | Finding D-R01: validation tên bắt buộc không quan sát được. |
| D-DT-004 | Email rỗng; tên/password hợp lệ | Alert thành công, count 0→1, chuyển Login. | Finding D-R02: email rỗng được chấp nhận. |
| D-DT-005 | Email `bad-20261015t153620z-57c022` (không có `@`) | Alert thành công, count 0→1, chuyển Login. | Finding D-R03: đại diện sai format được chấp nhận. |
| D-DT-006 | Email đã tạo ở biến thể D-DT-002 | Alert thành công, count 1→2. | Finding D-R04 trên Mobile UI; cùng loại uniqueness issue API-only D-MREG run. |
| D-DT-007–011 | Password rỗng, thiếu hoa, thiếu thường, thiếu số, thiếu ký tự thuộc tập tương ứng | Form hiện lỗi password; count email 0→0. | Probe cho quy tắc password hiện có; do confirmation absent, không tính Pass full TC. |
| D-BV-001 | Password length 7 | Lỗi password hiện; count 0→0. | Đúng hướng rejection quan sát được; ca full TC còn confirmation absent. |
| D-BV-002 | Password length 8 | Hiện “Network request failed”; count 0→0. | Không kết luận độ dài tại biên; network failure chặn oracle. |
| D-BV-003 | Password length 9 | Alert thành công; count 0→1; chuyển Login. | Biến thể 3 trường thành công; chưa phải Pass full TC. |
| D-BV-004–005 | Thiếu hoa / thiếu thường, length 8 trong event | Form hiện lỗi password; count 0→0. | Probe robustness; không tính Pass full TC. |

`events.jsonl` là nguồn timestamp/state; các ảnh trước/phản hồi/điều hướng tương ứng nằm cùng thư mục run. Mỗi password chỉ ghi `[REDACTED]` và độ dài, không ghi giá trị.

#### Kết quả API-only bổ trợ uniqueness

Trên bản sao cô lập `/tmp/hw02-dmreg-isolated-run`, hai POST tuần tự cùng email trả HTTP 200, lần lượt tạo ID 3 và 4, count 0→1→2. `server.js` khớp hash với baseline; database thuộc bản sao, không phải DB SUT. Evidence: `evidence/D-MREG/full-runs/20261015T1303Z-DMREG/api-registration-duplicate-isolated.json`. Đây là lỗi API D-R04; nó không đại diện cho Mobile UI. Run bổ sung Mobile D-DT-006 sau đó cũng ghi biến thể UI tạo trùng, như ở bảng trên.

#### Requirement-level findings

- D-R01, D-R02, D-R03: probe Mobile cho thấy họ tên rỗng, email rỗng và email không có `@` đều được chấp nhận trên form ba trường; ba TC full setup chưa hoàn thành vì confirm thiếu.
- D-R04: API-only duplicate được xác nhận; biến thể UI cũng tạo bản ghi thứ hai. Không thử race condition.
- D-R05/D-R06: password policies có các probe bị từ chối/được chấp nhận; không chấm Pass cho full registration flow vì thiếu confirmation. Password length 8 có network failure.
- D-R07: Fail về sự hiện diện trường confirmation (D-DT-001); khớp/mismatch/rỗng không thể thử.
- D-R08/D-R09: có bằng chứng success alert, DB count và điều hướng trong biến thể 3 trường, nhưng không coi là Pass cho ca có bốn trường.

#### AI/execution gap và giới hạn

Run đầu `20261015T1303Z-DMREG` bị chặn khi tap header, sau đó run bổ sung mở được Register qua Login và liên kết đăng ký. Giới hạn ban đầu được khắc phục. Không dùng kết quả “Blocked” của run đầu để phủ nhận evidence run sau.

Không có evidence cho D-BV-006/007 trong run; không dùng ảnh từ ca Domain tương tự thay thế. Chưa xác minh xử lý mạng lỗi, trim, Unicode, giới hạn chiều dài, câu chữ expected, hay race email. Account test được tạo trong DB clone; không xóa DB/account test. Không restart backend SUT.

#### Lượt automation không hợp lệ ngày 16/10/2026

Các lượt sau được giữ lại để minh bạch về lỗi công cụ nhưng không tính vào 20 TC hoặc probe có kết quả:

- `20261016T003700Z-DMREG-BV67`: hai process chạy chồng; trường tên bị nhập thành `Nguyen` thay vì giá trị dự kiến và dữ liệu trường bị lệch. Không dùng kết quả hiển thị để chấm ca.
- `20261015T174041Z-DMREG-BV67-clean`, `20261015T174117Z-DMREG-BV67-clean`, `20261015T174221Z-DMREG-BV67-clean`: xác minh trường đầu vào thất bại trước khi submit; không tạo account theo các lượt này.
- `20261015T174259Z-D-MREG-manual-probe`: ảnh trước submit xác nhận tên `V`, email riêng và password được che; thao tác tiếp theo rời Expo Go về màn hình Home, không lưu được response UI đáng tin cậy. DB clone được truy vấn chỉ đọc và không thấy account email fixture (`0`), nhưng không có checkpoint response của app nên không kết luận rejection.

Đây là lỗi thao tác/điều khiển của AI, không phải lỗi SUT. D-BV-006/007 vẫn **Not run**. Cần mở lại app, làm từng trường và xác nhận response trên app trước khi gọi lượt mới là test.


#### GitHub Issues đã đăng/cập nhật

- [Issue #8](https://github.com/tzin1401/testing-hw02/issues/8): API duplicate email; cập nhật mô tả Mobile variant có giới hạn và đính kèm ảnh trích từ API run log.
- [Issue #13](https://github.com/tzin1401/testing-hw02/issues/13): form thiếu trường confirmation; ảnh form UI đã đính kèm.
- [Issue #14](https://github.com/tzin1401/testing-hw02/issues/14): ba probe name/email invalid được gộp trong cùng nhóm validation; ảnh before/response riêng cho từng probe đã đính kèm. Full TC bốn trường vẫn Partial/Fail/Blocked như bảng trên, không đổi verdict do issue được tạo.

Issue #8 ảnh là bản trình bày từ JSON API log, không phải screenshot Mobile UI. Mobile variant vẫn là observation bổ sung, không thay thế full D-DT-006.


#### Run 20261016 — emulator navigation retry

Pixel 9 / Android 15 API 35 / Expo Go SDK 54 successfully opened the baseline Mobile app from a temporary clone. The product list loaded. “Đăng nhập” is drawn under/overlapped by Android status-bar icons; repeated ADB taps in its visible area did not open Login, while a tap on the product detail control did navigate. Therefore this attempt did not reach Register or submit a Mobile test. It is a tooling/UI navigation blocker, not a pass/fail for registration requirements. D-BV-006/007 remain Not run; D-DT cases requiring Register remain Blocked/Partial as already recorded. Diagnostic screenshot and note: `evidence/D-MREG/supplement-runs/20261016T-emulator-navigation-blocked/`. Backend was the isolated clone; no SUT DB or logic was modified.



## Lượt skill-demo A-FR02 — 17/10/2026

Sau khi bộ chính được tổng hợp, thực hiện một lượt demo mới theo `skills/domain-bva/SKILL.md` trên bộ thiết kế `reports/domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/`. Đây là 24 Domain + 12 BVA riêng, không cộng vào 105 TC chính và không thay verdict lịch sử. Kết quả lượt mới: **12 Pass, 8 Fail, 16 Blocked, 0 Not run**.

Runtime dùng backend/Web đang chạy trên bản sao DB riêng; DB SUT trong repo không đổi. Lỗi counter tăng hai lần và khóa sớm khớp issue #1; input email Web `type=text` khớp issue #3. Không tạo issue trùng. Các ca timer không hoàn tất: setup khóa tự nhiên bị chặn bởi counter sai; không kết luận 29/31 giây nếu khoảng đo không nằm hẳn một phía ngưỡng; đúng 30 giây bị Blocked vì không kiểm soát clock tại điểm server so sánh.

Run ID mới: `20261017T154711Z-914d632e` và continuation `20261017T154857Z-1a064665`. Ma trận từng TC, log và ảnh ở [execution demo](domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/06-execution.md); bug/AI gaps ở [báo cáo demo](domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/07-bugs-and-ai-gaps.md).
