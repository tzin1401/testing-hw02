# HW02 — Domain Testing on EShop

- **Sinh viên:** Nguyễn Lê Thế Vinh — **MSSV:** 23120190
- **Phân công:** Thành viên 2
- **Repo bài làm:** [tzin1401/testing-hw02](https://github.com/tzin1401/testing-hw02)
- **SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`

## Phạm vi và nguồn

| Mã | Chức năng | Cơ sở yêu cầu |
|---|---|---|
| A-FR02 | Đăng nhập/khóa tài khoản Web | SRS FR-02 |
| B-FR07 | Giỏ hàng Web | SRS FR-07; quantity tham chiếu FR-06 |
| C-FR14 | Thêm/xem/xóa danh mục Admin | SRS FR-14; quyền ghi tham chiếu FR-12 |
| D-MREG | Đăng ký Mobile | FR-20 và quy tắc FR-01 |

Chi tiết nguồn, môi trường và các yêu cầu chưa rõ: [reports/environment.md](reports/environment.md), [LAM_HW02_TUNG_BUOC.md](LAM_HW02_TUNG_BUOC.md), cùng các file `features/<mã>/01-requirements.md`.

## Bảng tự đánh giá

Điểm do sinh viên tự chấm sau khi đối chiếu toàn diện với rubric và hồ sơ kiểm thử:

| Hạng mục | Tối đa | Tự chấm | Dẫn chứng |
|---|---:|---:|---|
| A-FR02 — Domain/BVA | 25 | 25 | [Thiết kế và execution](features/A-FR02/) |
| B-FR07 — Domain/BVA | 25 | 25 | [Thiết kế và execution](features/B-FR07/) |
| C-FR14 — Domain/BVA | 25 | 25 | [Thiết kế và execution](features/C-FR14/) |
| D-MREG — Mobile Domain/BVA | 15 | 15 | [Thiết kế và execution](features/D-MREG/) |
| Skill/video theo rubric lớp | 10 | 10 | Skill đã nộp kèm demo YouTube tại bảng video bên dưới. |
| **Tổng** | **100** | **100** | Sinh viên tự chấm 100/100 theo toàn bộ hồ sơ và rubric. |

## Test summary — cập nhật 17/10/2026

Bốn chức năng; 105 TC chính (75 Domain + 30 BVA), cộng lượt skill-demo A-FR02 riêng gồm 36 TC. Demo riêng không thay hoặc đếm trùng vào 105 TC chính. Số liệu bộ chính tại [test-summary.csv](reports/test-summary.csv); kết quả demo mới ở [06-execution](reports/domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/06-execution.md).

| Chức năng | Thiết kế | Đã thử (kể cả setup Blocked) | Pass* | Fail | Partial | Observation | Blocked | Not run |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| A-FR02 (bộ chính) | 36 | 36 | 17 | 15 | 2 | 2 | 0 | 0 |
| B-FR07 | 26 | 26 | 4 | 12 | 0 | 2 | 8 | 0 |
| C-FR14 | 23 | 23 | 15 | 4 | 0 | 3 | 1 | 0 |
| D-MREG | 20 | 18 | 0 | 1 | 15 | 0 | 2 | 2 |
| **Tổng bộ chính** | **105** | **103** | **36** | **32** | **17** | **7** | **11** | **2** |

“Đã thử” = TC có ít nhất một thao tác/checkpoint, gồm các ca chỉ đạt tới prerequisite Blocked. Trong 103 ca đã thử, 68 có verdict Pass/Fail theo checkpoint, 24 Partial/Observation chưa có verdict đầy đủ, 11 Blocked chưa hoàn tất; 2 Not run chưa bắt đầu. Con số này không có nghĩa 103 full TC đã hoàn tất. Không đếm ID skill-demo riêng vào 105.

**Phạm vi của Pass bộ chính:** A-BV-007/011/012 chỉ Pass checkpoint toán tử thời gian trên clock fixture cô lập, không chứng minh toàn bộ luồng khóa tự nhiên. Các Pass khác cũng giữ giới hạn checkpoint/oracle trong execution; không nâng thành full-flow coverage. D chưa có full TC Pass: 15 Partial là variant trên form 3 trường thiếu confirmation.

**Skill-demo mới:** 24 Domain + 12 BVA = 36 ca; 12 Pass, 8 Fail, 16 Blocked, 0 Not run. Counter tăng 2/khóa sớm tái hiện issue #1; Web email `type=text` tái hiện issue #3. Timing setup tự nhiên không đạt nên không có kết luận 29/31s; đúng 30s bị Blocked vì không kiểm soát clock server. Xem [execution](reports/domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/06-execution.md) và [bugs/AI gaps](reports/domain-bva-demos/A-FR02/20261017T153630Z-4c29d1/07-bugs-and-ai-gaps.md).

## Bugs và GitHub

Đã kiểm tra GitHub ngày 17/10/2026: **14 issue (#1–#14), đều OPEN**, body đều có liên kết ảnh. [Bug report](reports/bug-report.md) có mô tả issue và bản sao ảnh tải về để đọc offline; [snapshot](reports/github-evidence/issues-snapshot.json) ghi thời điểm kiểm tra và kết quả tải.

Phân bố issue đã đăng: A = 3, B = 6, C = 2, D = 3. Đây là số issue, không đồng nhất với số TC Fail hay số mọi biểu hiện lỗi. Các finding quantity bổ sung của B-DT-016–019/B-BV-001 được ghi trong report; chưa có issue riêng trong #1–#14. Ảnh #7/#8 là bản trình bày từ log API, không phải screenshot UI. Không kết luận câu hỏi oracle là bug.

## Hồ sơ nộp

- Báo cáo chính Domain + BVA: [Markdown](reports/main-report.md), [PDF](reports/main-report.pdf), [nguồn LaTeX](reports/reports/main.tex).
- Bug report và ảnh offline: [Markdown](reports/bug-report.md), [PDF](reports/bug-report.pdf), [ảnh GitHub](reports/github-evidence/).
- AI Critique đã được sinh viên xác nhận nội dung: [Markdown](reports/ai-critique.md), [PDF](reports/ai-critique.pdf).
- AI Audit gồm toàn văn snapshot output hiện có: [Markdown](reports/ai-audit.md), [PDF](reports/ai-audit.pdf); [log gốc](AI_AUDIT_REPORT.md).
- Git commit log: [git-commit-log.txt](git-commit-log.txt).
- Skill tái sử dụng: [SKILL.md](skills/domain-bva/SKILL.md). Demo YouTube được liên kết ở bảng video.
- Checklist cập nhật: [submission-checklist.md](reports/submission-checklist.md).
- ZIP cập nhật: `23120190_HW02_AI_DomainTesting_100.zip` ở gốc repo. Đã cập nhật điểm tự chấm 100; link video A-FR02 đã được cung cấp và ghi ở dưới.

## Video demo

| Chức năng | Link YouTube |
|---|---|
| A-FR02 — Domain/BVA Agent Skill | https://youtu.be/wwZilnPrbqU |

Video do sinh viên cung cấp; link đã được kiểm tra trả lời được và chuyển hướng tới video YouTube. Điểm tự chấm 25/25/25/15/10 đã được sinh viên xác nhận và điền đầy đủ (Tổng 100/100).
