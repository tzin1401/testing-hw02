# C-FR14 — Bug report và AI gaps

**SUT baseline:** `85af3ba875c88283615e22cb108f13e2fccaf0e9`.
**Run:** `20261015T055119Z-CFR14`.
**Nguồn expected:** [SRS `eshop-sut/README.md`](https://github.com/ttbhanh/eshop-sut/blob/85af3ba875c88283615e22cb108f13e2fccaf0e9/README.md), FR-12 dòng 174–179 và FR-14 dòng 186–189; API specification mục 3.4 xác nhận endpoint. FR-14 yêu cầu Admin thêm/xem/xóa và tên bắt buộc không rỗng. FR-12 yêu cầu JWT hợp lệ cùng role `admin` cho các API ghi `/api/categories`. Không dùng code SUT để quyết định expected.

## Bug đã tái hiện

### GitHub Issue #6 — Có thể tạo danh mục với tên rỗng

- **URL:** https://github.com/tzin1401/testing-hw02/issues/6

- **Title:** `[BUG][Admin] Hệ thống cho phép tạo danh mục khi tên để trống`
- **Mô tả:** FR-14 ghi tên danh mục là bắt buộc và không được để trống. Trên Admin UI, để trống trường tên và bấm **Thêm mới** vẫn tạo dòng danh mục có tên rỗng.
- **Môi trường:** Linux x86_64; Chrome Headless `154.0.8037.57`; Admin `http://127.0.0.1:5174`; backend `http://127.0.0.1:3000`; SUT commit `85af3ba875c88283615e22cb108f13e2fccaf0e9`; phiên đăng nhập admin fixture.
- **Body đề xuất:**

  ```markdown
  ## Mô tả lỗi
  Admin UI tạo được danh mục dù tên để trống, trái với FR-14: tên danh mục bắt buộc và không được để trống.

  ## Môi trường
  Linux x86_64; Chrome Headless 154.0.8037.57; Admin http://127.0.0.1:5174; backend http://127.0.0.1:3000; SUT commit 85af3ba875c88283615e22cb108f13e2fccaf0e9; tài khoản role admin.

  ## Steps to reproduce
  1. Đăng nhập Admin và mở Danh mục.
  2. Để ô tên danh mục rỗng.
  3. Bấm Thêm mới một lần.
  4. Quan sát danh sách và đối chiếu ID mới.

  ## Expected result
  Không tạo danh mục nếu tên rỗng (SRS FR-14). Không yêu cầu wording/status cụ thể.

  ## Actual result
  Danh mục rỗng được tạo; lần tái hiện bổ sung ghi nhận ID 26.

  ## Test cases
  C-DT-003, C-BV-001.

  ## Severity / Priority
  Minor / P2: sai validation và làm bẩn dữ liệu quản trị, nhưng cần phiên admin; lần chạy không làm thay đổi dữ liệu mẫu hoặc gây mất dữ liệu khác.

  ## Evidence
  Đính kèm ảnh trước/sau bên dưới và issue-empty-name-evidence.json (snapshot trước/sau, request/response và cleanup đúng ID test).
  ```

- **Steps to reproduce:**
  1. Đăng nhập Admin bằng role admin và mở **Danh mục**.
  2. Để ô tên danh mục rỗng.
  3. Bấm **Thêm mới** một lần.
  4. Quan sát danh sách; dòng mới có ID 26 nhưng tên rỗng.
- **Expected:** Không tạo danh mục tên rỗng, theo FR-14 “tên bắt buộc, không được để trống”. Không yêu cầu wording/status cụ thể.
- **Actual:** Danh mục tên rỗng được tạo; API `GET /api/categories` ghi nhận ID 26. Dòng test được xóa đúng ID 26 sau khi lưu bằng chứng.
- **TC liên quan:** C-DT-003, C-BV-001.
- **Severity / Priority:** `severity: minor`, `priority: P2`. Chức năng tạo danh mục sai validation nhưng cần quyền admin và không làm thay đổi dữ liệu mẫu; ảnh hưởng dữ liệu quản trị và vi phạm yêu cầu bắt buộc, chưa có bằng chứng mất dữ liệu khác.
- **Labels đề xuất:** `type: bug`, `severity: minor`, `priority: P2`, `status: new`, `module: admin`.
- **Evidence đã đính kèm:** [ảnh trước](https://github.com/user-attachments/assets/730f684f-cd6a-45e7-9095-1eb0ebf6940f) và [ảnh sau](https://github.com/user-attachments/assets/78372825-d465-4c90-aa75-5e3a892b8164). Ảnh sau cho thấy ID 26 với tên trống; snapshot trước/sau và cleanup đúng ID nằm trong `issue-empty-name-evidence.json`.

### GitHub Issue #7 — Role user thường ghi/xóa được danh mục qua API

- **URL:** https://github.com/tzin1401/testing-hw02/issues/7

- **Title:** `[BUG][API] API categories cho phép user thường POST và DELETE`
- **Mô tả:** FR-12 yêu cầu API ghi danh mục cần JWT hợp lệ và role admin. Hai request có JWT hợp lệ role `user` đã thay đổi dữ liệu: POST tạo category ID 6, DELETE xóa target test ID 10.
- **Môi trường:** Linux x86_64; backend `http://127.0.0.1:3000`; SUT commit `85af3ba875c88283615e22cb108f13e2fccaf0e9`; fixture `test@eshop.com` xác nhận role `user`; token không lưu trong artifact.
- **Body đề xuất:**

  ```markdown
  ## Mô tả lỗi
  API ghi danh mục chấp nhận JWT hợp lệ của tài khoản role user. FR-12 yêu cầu các API POST/DELETE ảnh hưởng dữ liệu phải có JWT hợp lệ và role admin.

  ## Môi trường
  Linux x86_64; backend http://127.0.0.1:3000; SUT commit 85af3ba875c88283615e22cb108f13e2fccaf0e9; fixture test@eshop.com có role user.

  ## Steps to reproduce
  1. Đăng nhập bằng fixture role user và giữ JWT trong bộ nhớ (không đưa token vào issue).
  2. Gửi POST /api/categories với body {"name":"C14-user-post-test"} và Bearer user token.
  3. Tạo một category khác riêng bằng admin; ghi ID trả về.
  4. Gửi DELETE /api/categories/<ID-test> bằng Bearer user token.
  5. Gọi GET /api/categories sau từng thao tác để đối chiếu state.

  ## Expected result
  FR-12 chỉ cho role admin thực hiện API ghi: POST không tạo category và DELETE không xóa target. Không yêu cầu status/body cụ thể.

  ## Actual result
  POST role user tạo category test ID 6; DELETE role user xóa category test ID 10. Request/response đã che token trong evidence.

  ## Test cases
  C-DT-014 (POST), C-DT-018 (DELETE).

  ## Severity / Priority
  Major / P1: tài khoản thường có thể thay đổi hoặc xóa dữ liệu danh mục, trái kiểm soát truy cập; target kiểm thử là dữ liệu test riêng.

  ## Evidence
  GitHub Issue #7 có đính kèm ảnh excerpt từ API log redacted và liên kết tới `api-evidence.json`, gồm request/response và snapshot state trước/sau cho hai TC. Đây là bằng chứng API-only, không phải ảnh UI.
  ```

- **Steps to reproduce:**
  1. Lấy JWT bằng fixture có role `user`.
  2. POST `/api/categories` với body `{"name":"<tên test mới>"}` và Bearer user token. Quan sát request tạo category ID 6.
  3. Tạo target category test riêng bằng admin và ghi ID; trong lần chạy ghi ID 10.
  4. Gọi DELETE `/api/categories/10` bằng chính Bearer user token.
  5. GET danh sách sau từng thao tác và đối chiếu state.
- **Expected:** Theo FR-12, chỉ role admin mới được phép gọi API ghi danh mục. Với role user, POST không tạo danh mục và DELETE không xóa target. Không đặt HTTP status/body cụ thể.
- **Actual:** POST role user trả HTTP 200 và tạo ID 6; DELETE role user trả HTTP 200 và xóa ID 10. Các thao tác thiếu token, token giả và token hết hạn bị từ chối; GET được kiểm tra riêng và không được xem là lỗi phân quyền.
- **TC liên quan:** C-DT-014, C-DT-018. Không dùng UI Admin để suy ra API permission.
- **Severity / Priority:** `severity: major`, `priority: P1`. Role user không được phép thay đổi danh mục; có thể làm sai dữ liệu quản trị hoặc xóa category. Target trong lần test là dữ liệu test riêng, không phải category mẫu.
- **Labels đề xuất:** `type: bug`, `severity: major`, `priority: P1`, `status: new`, `module: api`.
- **Evidence đã đăng trong body:** ảnh excerpt từ log và request/response/snapshot redacted cho `C-DT-014` và `C-DT-018`; [Issue #7](https://github.com/tzin1401/testing-hw02/issues/7). Ảnh excerpt chỉ minh họa log API, không phải screenshot UI; JSON gốc vẫn là nguồn chi tiết.

## Phân loại các ca chưa thành bug

- C-DT-004: ba dấu cách được nhận, nhưng trim/whitespace-only chưa có expected trong SRS; chỉ observation.
- C-DT-006: GET trả danh sách cho admin, user và không token; quyền GET chưa được đặc tả, không tạo bug.
- C-DT-008: UI không hiện dialog; FR-14 không bắt buộc dialog/Hủy, ca phụ thuộc dialog được ghi Blocked.
- C-BV-005: DELETE ID không tồn tại trả HTTP 200 nhưng SRS không nêu expected cho ID này; chỉ observation.
- Không kết luận uniqueness, giới hạn độ dài tên, policy trim, status/body cụ thể, hoặc xử lý category đang được sản phẩm tham chiếu.

## AI gaps và giới hạn coverage

- Lượt automation UI đầu nhắm vào dòng nằm ngoài viewport. Ảnh đầu cho thấy danh sách chưa cuộn tới target và state không đổi; không dùng lần click đó làm kết quả. Đã cuộn đúng target vào vùng nhìn thấy và chạy lại C-DT-007, thu được kết quả hợp lệ. Dấu vết trong `C-DT-007-retry.json` và ảnh retry.
- Ở các ca tên rỗng, automation ban đầu chỉ chụp viewport đầu danh sách, chưa làm dòng rỗng mới thấy rõ trên ảnh. Đã chạy capture bổ sung cho C-DT-003: ảnh cuộn tới dòng ID 26 và snapshot API trước/sau được lưu; kết quả chính không bị thay đổi.
- `api-evidence.json` của C-DT-018 chứa hai bản ghi giống hệt cho request POST setup cùng ID 10. Runner lưu cùng một response setup hai lần vào mảng evidence; đây là lỗi ghi log của AI, không phải hai POST độc lập lên SUT. DELETE và snapshot state vẫn được ghi riêng; không suy diễn thêm một lần chạy.

## Coverage gap (không phải AI gap)

- C-R01 về quyền truy cập **Admin UI** của user thường/khách chưa được kiểm tra trực tiếp. API POST/DELETE role user là phép thử riêng, không thay thế UI access test.
- Issues #6 và #7 OPEN, có labels và evidence; #7 hiện có ảnh trích từ API log đính kèm, bên cạnh JSON nguồn. C-R01 UI role-user được ghi riêng theo run xác minh; không nhập nhằng UI với API write. Không push code hoặc SUT trong thao tác issue.

## Đính chính checkpoint Admin UI bổ sung

Run `20261015T154202360Z-supp` có guest screenshot cho form Admin Login. Event user ghi fixture role `user` là `supp-20261015t154202360z-supp@example.com`, nhưng lần nhập ở trang Admin lại dùng `test@eshop.com`; actual chỉ là alert “Đăng nhập thất bại”, không lưu request/response login. Vì vậy đây chưa phải evidence đủ để kết luận credentials hợp lệ rồi bị từ chối do role. C-R01 UI role-user còn thiếu kiểm chứng; không lấy screenshot/log generic làm Pass.


## Kết quả C-R01 user UI sau khi xác minh fixture

Run `20261016T003500Z-CUI-user` dùng fixture role `user` ID 11 trong backend clone đã xác minh bằng SQLite read-only. Đăng nhập từ Admin UI có API login HTTP 200, sau đó giao diện hiện alert “Bạn không phải là admin!”, vẫn ở Login và `adminTokenPresent=false`. Đây là bằng chứng bổ sung rằng role user bị chặn ở Admin UI. Nó không mâu thuẫn với lỗi API write Issue #7: UI check và API POST/DELETE là các đường riêng. Record cũ dùng `test@eshop.com` với alert generic vẫn được xem là lần thử inconclusive.
